"""
Sidebar Common Module

Provides reusable sidebar component for all dashboard pages.
Features:
- Alphabetically sorted accounts
- Region selection (common/all/custom)
- Fetch button
- NO Clear Data button
- NO persistence between pages
"""

import streamlit as st
from modules.aws_helper import AWSRegions


def render_sidebar(page_key_prefix=""):
    """
    Render common sidebar configuration for dashboard pages.
    
    Args:
        page_key_prefix: Prefix for session state keys to avoid conflicts between pages
        
    Returns:
        tuple: (selected_account_ids: list, selected_regions: list)
    """
    
    st.sidebar.header("⚙️ Configuration")
    
    # Get all accounts from session state
    all_accounts = st.session_state.get('accounts', [])
    
    if not all_accounts:
        st.sidebar.error("No accounts loaded. Return to main page.")
        return [], []
    
    # Sort accounts alphabetically by name
    sorted_accounts = sorted(all_accounts, key=lambda x: x['Name'])
    
    # Account selection
    st.sidebar.subheader("📋 Select Accounts")
    
    account_options = {f"{acc['Name']} ({acc['Id']})": acc['Id'] for acc in sorted_accounts}
    
    selected_account_names = st.sidebar.multiselect(
        "Choose accounts:",
        options=list(account_options.keys()),
        default=list(account_options.keys()),
        key=f"{page_key_prefix}account_select"
    )
    
    selected_account_ids = [account_options[name] for name in selected_account_names]
    
    # Region selection
    st.sidebar.subheader("🌍 Select Regions")
    
    region_mode = st.sidebar.radio(
        "Region selection mode:",
        options=["Common Regions", "All Regions", "Custom"],
        index=0,
        key=f"{page_key_prefix}region_mode"
    )
    
    if region_mode == "Common Regions":
        common_regions = AWSRegions.get_common_regions()
        selected_regions = st.sidebar.multiselect(
            "Choose regions:",
            options=common_regions,
            default=common_regions,
            key=f"{page_key_prefix}region_select_common"
        )
    elif region_mode == "All Regions":
        all_regions = AWSRegions.list_all_regions()
        selected_regions = st.sidebar.multiselect(
            "Choose regions:",
            options=all_regions,
            default=AWSRegions.get_common_regions(),
            key=f"{page_key_prefix}region_select_all"
        )
    else:  # Custom
        custom_regions = st.sidebar.text_input(
            "Enter regions (comma-separated):",
            value="us-east-1,us-west-2",
            key=f"{page_key_prefix}region_custom"
        )
        selected_regions = [r.strip() for r in custom_regions.split(',') if r.strip()]
    
    # Fetch button
    st.sidebar.markdown("---")
    
    if st.sidebar.button("🔄 Fetch Data", type="primary", use_container_width=True, key=f"{page_key_prefix}fetch_btn"):
        st.session_state[f'{page_key_prefix}fetch_clicked'] = True
        st.rerun()
    
    return selected_account_ids, selected_regions
