"""
[SERVICE NAME] Dashboard Page Template

Replace [SERVICE NAME] with your service name (e.g., RDS, Lambda, CloudWatch)
Replace [service_key] with lowercase identifier (e.g., rds, lambda, cloudwatch)
Replace helper function placeholders with your actual service logic.

OPTIMIZED with parallel processing and debug mode built-in.
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

from modules.aws_helper import AWSConfig, AWSOrganizations, AWSSession
from modules.sidebar_common import render_sidebar
from botocore.exceptions import ClientError

# ============================================================================
# CONFIGURATION - UPDATE THESE
# ============================================================================

# Page configuration
PAGE_TITLE = "[SERVICE NAME]"  # e.g., "RDS Instances"
PAGE_ICON = "📊"  # Choose an appropriate emoji
PAGE_KEY_PREFIX = "[service_key]_"  # e.g., "rds_"

# Session state keys
DATA_KEY = f'{PAGE_KEY_PREFIX}data'
REFRESH_KEY = f'{PAGE_KEY_PREFIX}last_refresh'
ERRORS_KEY = f'{PAGE_KEY_PREFIX}errors'
FETCH_CLICKED_KEY = f'{PAGE_KEY_PREFIX}fetch_clicked'
REFRESH_BTN_KEY = f'{PAGE_KEY_PREFIX}refresh_btn'

# Set page config
st.set_page_config(page_title=PAGE_TITLE, page_icon=PAGE_ICON, layout="wide")

# Initialize session state
if DATA_KEY not in st.session_state:
    st.session_state[DATA_KEY] = None
if REFRESH_KEY not in st.session_state:
    st.session_state[REFRESH_KEY] = None
if ERRORS_KEY not in st.session_state:
    st.session_state[ERRORS_KEY] = []

# Header
st.title(f"{PAGE_ICON} {PAGE_TITLE} Dashboard")

# Get all accounts
all_accounts = st.session_state.get('accounts', [])
if not all_accounts:
    st.error("No accounts found. Please return to main page.")
    st.stop()

# ============================================================================
# SIDEBAR CONFIGURATION
# ============================================================================

selected_account_ids, selected_regions = render_sidebar(page_key_prefix=PAGE_KEY_PREFIX)

# Optional: Add service-specific sidebar options here
# Example:
# st.sidebar.markdown("---")
# st.sidebar.subheader("🔧 Service Options")
# option_value = st.sidebar.selectbox("Select option:", ["Option1", "Option2"])

# Debug mode
st.sidebar.markdown("---")
debug_mode = st.sidebar.checkbox("Show Debug Info", value=False)

# ============================================================================
# HELPER FUNCTIONS - IMPLEMENT YOUR SERVICE LOGIC HERE
# ============================================================================

def get_service_data_in_region(region, account_id, account_name, role_name):
    """
    Get service data for a specific region in a target account.
    
    TODO: Implement your service-specific logic here.
    
    Args:
        region: AWS region
        account_id: Target account ID
        account_name: Target account name
        role_name: IAM role to assume
        
    Returns:
        tuple: (data_list, errors_list)
            - data_list: List of dictionaries with service data
            - errors_list: List of error/info messages
    """
    data_items = []
    errors = []
    
    try:
        # TODO: Get service client
        # Example: service_client = AWSSession.get_client_for_account('rds', account_id, role_name, region)
        service_client = AWSSession.get_client_for_account('[service_name]', account_id, role_name, region)
        
        # TODO: Check if service is available/enabled (optional)
        # try:
        #     service_client.describe_[something]()
        # except ClientError as e:
        #     error_code = e.response.get('Error', {}).get('Code', '')
        #     if error_code == '[SpecificException]':
        #         errors.append(f"ℹ️ {account_name}/{region}: Service not enabled")
        #         return data_items, errors
        
        # TODO: Fetch service data with pagination
        # Example:
        # paginator = service_client.get_paginator('describe_db_instances')
        # for page in paginator.paginate():
        #     for item in page['[ItemsKey]']:
        #         data_item = {
        #             'Account ID': account_id,
        #             'Account Name': account_name,
        #             'Region': region,
        #             'Item ID': item['[IdKey]'],
        #             'Item Name': item.get('[NameKey]', 'N/A'),
        #             # Add more fields...
        #         }
        #         data_items.append(data_item)
        
        # Placeholder - Replace with actual implementation
        errors.append(f"ℹ️ {account_name}/{region}: TODO - Implement service data fetching")
                    
    except ClientError as e:
        errors.append(f"⚠️ {account_name}/{region}: Cannot access service - {str(e)}")
    except Exception as e:
        errors.append(f"❌ {account_name}/{region}: Unexpected error - {str(e)}")
    
    return data_items, errors


def fetch_service_data(selected_account_ids, all_accounts, role_name, regions):
    """
    Fetch service data - OPTIMIZED (parallel processing).
    
    This function is already optimized. No changes needed.
    """
    all_data = []
    all_errors = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    # Submit ALL account+region combinations at once
    with ThreadPoolExecutor(max_workers=AWSConfig.MAX_WORKERS) as executor:
        futures = {}
        
        for account_id in selected_account_ids:
            account_name = AWSOrganizations.get_account_name_by_id(account_id, all_accounts)
            for region in regions:
                future = executor.submit(get_service_data_in_region, region, account_id, account_name, role_name)
                futures[future] = (account_id, account_name, region)
        
        total_tasks = len(futures)
        completed = 0
        
        # Process as they complete
        for future in as_completed(futures):
            account_id, account_name, region = futures[future]
            completed += 1
            
            status_text.text(f"📡 {account_name} / {region} ({completed}/{total_tasks})")
            progress_bar.progress(completed / total_tasks)
            
            try:
                data, errors = future.result()
                all_data.extend(data)
                all_errors.extend(errors)
            except Exception as e:
                all_errors.append(f"❌ {account_name}/{region}: Failed - {str(e)}")
    
    progress_bar.empty()
    status_text.empty()
    
    return all_data, all_errors


# ============================================================================
# ALTERNATIVE: For services without regions (like IAM)
# ============================================================================

def get_service_data_for_account(account_id, account_name, role_name):
    """
    Get service data for an account (global service without regions).
    
    Use this instead of get_service_data_in_region for global services like IAM.
    
    TODO: Implement your service-specific logic here.
    """
    data_items = []
    errors = []
    
    try:
        # TODO: Get service client (always use 'us-east-1' for global services)
        service_client = AWSSession.get_client_for_account('[service_name]', account_id, role_name, 'us-east-1')
        
        # TODO: Test connection (optional)
        # try:
        #     service_client.[test_method]()
        # except ClientError as e:
        #     errors.append(f"❌ {account_name}: Cannot access service - {str(e)}")
        #     return data_items, errors
        
        # TODO: Fetch service data
        # Placeholder - Replace with actual implementation
        errors.append(f"ℹ️ {account_name}: TODO - Implement service data fetching")
                    
    except ClientError as e:
        errors.append(f"❌ {account_name}: Cannot assume role - {str(e)}")
    except Exception as e:
        errors.append(f"❌ {account_name}: Unexpected error - {str(e)}")
    
    return data_items, errors


def fetch_service_data_no_regions(selected_account_ids, all_accounts, role_name):
    """
    Fetch service data for global services (no regions).
    
    Use this instead of fetch_service_data for global services.
    """
    all_data = []
    all_errors = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    total_accounts = len(selected_account_ids)
    completed = 0
    
    # Process all accounts in parallel
    with ThreadPoolExecutor(max_workers=AWSConfig.MAX_WORKERS) as executor:
        future_to_account = {
            executor.submit(get_service_data_for_account, account_id,
                          AWSOrganizations.get_account_name_by_id(account_id, all_accounts),
                          role_name): account_id
            for account_id in selected_account_ids
        }
        
        # Process as they complete
        for future in as_completed(future_to_account):
            account_id = future_to_account[future]
            account_name = AWSOrganizations.get_account_name_by_id(account_id, all_accounts)
            completed += 1
            
            status_text.text(f"📡 Scanning: {account_name} ({completed}/{total_accounts})")
            progress_bar.progress(completed / total_accounts)
            
            try:
                data, errors = future.result()
                all_data.extend(data)
                all_errors.extend(errors)
            except Exception as e:
                all_errors.append(f"❌ {account_name}: Failed - {str(e)}")
    
    progress_bar.empty()
    status_text.empty()
    
    return all_data, all_errors


# ============================================================================
# BUTTON HANDLERS - No changes needed
# ============================================================================

# Check if fetch button was clicked
if st.session_state.get(FETCH_CLICKED_KEY, False):
    if not selected_account_ids:
        st.warning("⚠️ Please select at least one account.")
        st.session_state[FETCH_CLICKED_KEY] = False
    elif not selected_regions:
        st.warning("⚠️ Please select at least one region.")
        st.session_state[FETCH_CLICKED_KEY] = False
    else:
        start_time = time.time()
        
        with st.spinner(f"🔍 Scanning {PAGE_TITLE} in {len(selected_account_ids)} account(s) across {len(selected_regions)} region(s)..."):
            # TODO: Choose the appropriate fetch function:
            # For regional services:
            service_data, errors = fetch_service_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, selected_regions)
            # For global services (uncomment and comment above):
            # service_data, errors = fetch_service_data_no_regions(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME)
            
            st.session_state[DATA_KEY] = service_data
            st.session_state[ERRORS_KEY] = errors
            st.session_state[REFRESH_KEY] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        elapsed_time = time.time() - start_time
        
        if service_data:
            st.success(f"✅ Successfully fetched {len(service_data)} items in {elapsed_time:.2f} seconds")
        else:
            st.warning(f"⚠️ No {PAGE_TITLE} data found in {elapsed_time:.2f} seconds. Check messages below.")
        
        if errors:
            with st.expander(f"⚠️ Messages ({len(errors)})", expanded=True):
                for error in errors:
                    st.write(error)
        
        st.session_state[FETCH_CLICKED_KEY] = False

# ============================================================================
# DISPLAY RESULTS - Customize as needed
# ============================================================================

# Show debug info if enabled
if debug_mode and st.session_state[ERRORS_KEY]:
    with st.expander("🐛 Debug Information", expanded=False):
        st.write(f"**Total Messages:** {len(st.session_state[ERRORS_KEY])}")
        for error in st.session_state[ERRORS_KEY]:
            st.write(error)

if st.session_state[DATA_KEY] is not None:
    df = pd.DataFrame(st.session_state[DATA_KEY])
    
    # Refresh button on main page
    col_title, col_refresh = st.columns([5, 1])
    with col_title:
        if st.session_state[REFRESH_KEY]:
            st.caption(f"Last refreshed: {st.session_state[REFRESH_KEY]}")
    with col_refresh:
        if st.button("🔁 Refresh", type="secondary", use_container_width=True, key=REFRESH_BTN_KEY):
            if not selected_account_ids:
                st.warning("⚠️ Please select at least one account.")
            elif not selected_regions:
                st.warning("⚠️ Please select at least one region.")
            else:
                start_time = time.time()
                
                with st.spinner(f"🔍 Refreshing data..."):
                    # TODO: Choose the appropriate fetch function (same as above)
                    service_data, errors = fetch_service_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, selected_regions)
                    
                    st.session_state[DATA_KEY] = service_data
                    st.session_state[ERRORS_KEY] = errors
                    st.session_state[REFRESH_KEY] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                
                elapsed_time = time.time() - start_time
                st.success(f"✅ Data refreshed ({len(service_data)} items in {elapsed_time:.2f} seconds)")
                
                if errors:
                    with st.expander(f"⚠️ Messages ({len(errors)})", expanded=False):
                        for error in errors:
                            st.write(error)
                
                st.rerun()
    
    if df.empty:
        st.info(f"ℹ️ No {PAGE_TITLE} data found in the selected accounts and regions.")
        
        # TODO: Customize troubleshooting tips
        with st.expander("🔍 Troubleshooting Tips"):
            st.markdown(f"""
            **Possible reasons for no {PAGE_TITLE} data:**
            
            1. **Service not enabled** - Enable the service in AWS Console
            2. **No resources exist** - The selected accounts may not have any resources
            3. **Permission issues** - The assumed role may not have required permissions
            
            **Required permissions:**
            - `[service]:[ListAction]`
            - `[service]:[DescribeAction]`
            
            **Enable Debug Mode** in sidebar to see detailed error messages.
            """)
    else:
        # TODO: Customize summary metrics
        st.subheader("📊 Summary Metrics")
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("Total Items", len(df))
        
        with col2:
            unique_accounts = df['Account ID'].nunique()
            st.metric("Accounts", unique_accounts)
        
        with col3:
            unique_regions = df['Region'].nunique() if 'Region' in df.columns else 1
            st.metric("Regions", unique_regions)
        
        # TODO: Add service-specific metrics in col4 and col5
        # with col4:
        #     specific_count = len(df[df['Status'] == 'Active'])
        #     st.metric("Active Items", specific_count)
        
        # with col5:
        #     specific_count2 = len(df[df['Type'] == 'TypeA'])
        #     st.metric("Type A", specific_count2)
        
        st.markdown("---")
        
        # TODO: Customize filters
        st.subheader("🔍 Filters")
        
        filter_col1, filter_col2, filter_col3 = st.columns(3)
        
        with filter_col1:
            # TODO: Add service-specific filter
            # Example:
            # status_filter = st.multiselect(
            #     "Status:",
            #     options=sorted(df['Status'].unique().tolist()),
            #     default=sorted(df['Status'].unique().tolist())
            # )
            pass
        
        with filter_col2:
            if 'Region' in df.columns:
                region_filter = st.multiselect(
                    "Region:",
                    options=sorted(df['Region'].unique().tolist()),
                    default=sorted(df['Region'].unique().tolist())
                )
        
        with filter_col3:
            account_filter = st.multiselect(
                "Account:",
                options=sorted(df['Account Name'].unique().tolist()),
                default=sorted(df['Account Name'].unique().tolist())
            )
        
        # TODO: Apply filters
        # filtered_df = df[
        #     (df['Status'].isin(status_filter)) &
        #     (df['Region'].isin(region_filter)) &
        #     (df['Account Name'].isin(account_filter))
        # ]
        filtered_df = df[df['Account Name'].isin(account_filter)]
        if 'Region' in df.columns:
            filtered_df = filtered_df[filtered_df['Region'].isin(region_filter)]
        
        st.markdown("---")
        
        # Display data
        st.subheader(f"📋 {PAGE_TITLE} Data ({len(filtered_df)} items)")
        
        # TODO: Customize default columns
        available_columns = filtered_df.columns.tolist()
        default_columns = [
            'Account Name', 'Region', 'Item ID', 'Item Name'
        ] if 'Region' in filtered_df.columns else [
            'Account Name', 'Item ID', 'Item Name'
        ]
        
        selected_columns = st.multiselect(
            "Select columns to display:",
            options=available_columns,
            default=[col for col in default_columns if col in available_columns]
        )
        
        if selected_columns:
            display_df = filtered_df[selected_columns]
        else:
            display_df = filtered_df
        
        st.dataframe(display_df, use_container_width=True, height=500, hide_index=True)
        
        # Download button
        st.markdown("---")
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label=f"📥 Download {PAGE_TITLE} Data (CSV)",
            data=csv,
            file_name=f"{PAGE_KEY_PREFIX}data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
        
        # TODO: Customize statistics
        with st.expander("📈 Additional Statistics"):
            stat_col1, stat_col2 = st.columns(2)
            
            with stat_col1:
                st.write("**Items by Account:**")
                account_counts = filtered_df['Account Name'].value_counts()
                st.dataframe(account_counts, use_container_width=True)
            
            with stat_col2:
                if 'Region' in filtered_df.columns:
                    st.write("**Items by Region:**")
                    region_counts = filtered_df['Region'].value_counts()
                    st.dataframe(region_counts, use_container_width=True)

else:
    st.info("👈 Configure options in the sidebar and click 'Fetch Data' to begin.")
