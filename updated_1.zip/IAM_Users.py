"""
IAM Users Dashboard Page

Displays IAM users and their access key details including age and MFA status.
OPTIMIZED with parallel processing and debug mode.
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

from modules.aws_helper import AWSConfig, AWSOrganizations, AWSSession
from modules.sidebar_common import render_sidebar
from botocore.exceptions import ClientError

# Page configuration
st.set_page_config(page_title="IAM Users", page_icon="👥", layout="wide")

# Initialize session state
if 'iam_users_data' not in st.session_state:
    st.session_state.iam_users_data = None
if 'iam_users_last_refresh' not in st.session_state:
    st.session_state.iam_users_last_refresh = None
if 'iam_users_errors' not in st.session_state:
    st.session_state.iam_users_errors = []

# Header
st.title("👥 IAM Users Dashboard")

# Get all accounts
all_accounts = st.session_state.get('accounts', [])
if not all_accounts:
    st.error("No accounts found. Please return to main page.")
    st.stop()

# ============================================================================
# SIDEBAR CONFIGURATION
# ============================================================================

selected_account_ids, selected_regions = render_sidebar(page_key_prefix="iam_users_")

# Age threshold for highlighting old keys
st.sidebar.markdown("---")
st.sidebar.subheader("⏰ Key Age Threshold")
age_threshold = st.sidebar.number_input(
    "Alert if key age exceeds (days):",
    min_value=1,
    max_value=365,
    value=90,
    help="Keys older than this will be highlighted"
)

# Debug mode
st.sidebar.markdown("---")
debug_mode = st.sidebar.checkbox("Show Debug Info", value=False)

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_iam_users_for_account(account_id, account_name, role_name, age_threshold):
    """Get IAM users and their details for an account"""
    users_data = []
    errors = []
    
    try:
        # IAM is global - always use us-east-1
        iam_client = AWSSession.get_client_for_account('iam', account_id, role_name, 'us-east-1')
        
        # Test the connection first
        try:
            iam_client.get_account_summary()
        except ClientError as e:
            error_msg = f"❌ {account_name}: Cannot access IAM - {str(e)}"
            errors.append(error_msg)
            return users_data, errors
        
        # List all users with pagination
        paginator = iam_client.get_paginator('list_users')
        user_count = 0
        
        try:
            for page in paginator.paginate():
                for user in page['Users']:
                    user_count += 1
                    username = user['UserName']
                    user_arn = user['Arn']
                    create_date = user['CreateDate']
                    user_age_days = (datetime.now(create_date.tzinfo) - create_date).days
                    
                    password_last_used = 'Never'
                    if 'PasswordLastUsed' in user:
                        password_last_used = user['PasswordLastUsed'].strftime('%Y-%m-%d %H:%M:%S')
                    
                    # Check MFA
                    mfa_enabled = "❌ No"
                    try:
                        mfa_response = iam_client.list_mfa_devices(UserName=username)
                        if len(mfa_response['MFADevices']) > 0:
                            mfa_enabled = "✅ Yes"
                    except ClientError as e:
                        errors.append(f"⚠️ {account_name}/{username}: Cannot check MFA - {str(e)}")
                    
                    # Get access keys
                    try:
                        keys_response = iam_client.list_access_keys(UserName=username)
                        access_keys = keys_response['AccessKeyMetadata']
                        
                        if access_keys:
                            for key in access_keys:
                                access_key_id = key['AccessKeyId']
                                key_create_date = key['CreateDate']
                                key_status = key['Status']
                                key_age_days = (datetime.now(key_create_date.tzinfo) - key_create_date).days
                                
                                if key_age_days > age_threshold:
                                    rotation_status = "⚠️ Overdue"
                                elif key_age_days > (age_threshold * 0.8):
                                    rotation_status = "⚡ Soon"
                                else:
                                    rotation_status = "✅ OK"
                                
                                last_used = "Never"
                                last_used_service = "N/A"
                                days_since_used = "N/A"
                                
                                try:
                                    last_used_response = iam_client.get_access_key_last_used(AccessKeyId=access_key_id)
                                    if 'LastUsedDate' in last_used_response.get('AccessKeyLastUsed', {}):
                                        last_used_date = last_used_response['AccessKeyLastUsed']['LastUsedDate']
                                        last_used = last_used_date.strftime('%Y-%m-%d %H:%M:%S')
                                        last_used_service = last_used_response['AccessKeyLastUsed'].get('ServiceName', 'N/A')
                                        days_since_used = (datetime.now(last_used_date.tzinfo) - last_used_date).days
                                except ClientError:
                                    pass
                                
                                user_data = {
                                    'Account ID': account_id,
                                    'Account Name': account_name,
                                    'User Name': username,
                                    'User ARN': user_arn,
                                    'User Age (Days)': user_age_days,
                                    'Password Last Used': password_last_used,
                                    'MFA Enabled': mfa_enabled,
                                    'Access Key ID': access_key_id,
                                    'Key Status': key_status,
                                    'Key Age (Days)': key_age_days,
                                    'Key Rotation Status': rotation_status,
                                    'Key Last Used': last_used,
                                    'Days Since Key Used': days_since_used,
                                    'Last Used Service': last_used_service
                                }
                                users_data.append(user_data)
                        else:
                            # User has no access keys
                            user_data = {
                                'Account ID': account_id,
                                'Account Name': account_name,
                                'User Name': username,
                                'User ARN': user_arn,
                                'User Age (Days)': user_age_days,
                                'Password Last Used': password_last_used,
                                'MFA Enabled': mfa_enabled,
                                'Access Key ID': 'No Keys',
                                'Key Status': 'N/A',
                                'Key Age (Days)': 0,
                                'Key Rotation Status': 'N/A',
                                'Key Last Used': 'N/A',
                                'Days Since Key Used': 'N/A',
                                'Last Used Service': 'N/A'
                            }
                            users_data.append(user_data)
                            
                    except ClientError as e:
                        error_msg = f"⚠️ {account_name}/{username}: Cannot list keys - {str(e)}"
                        errors.append(error_msg)
            
            if user_count == 0:
                errors.append(f"ℹ️ {account_name}: No IAM users found")
                    
        except ClientError as e:
            error_msg = f"❌ {account_name}: Error listing users - {str(e)}"
            errors.append(error_msg)
            
    except ClientError as e:
        error_msg = f"❌ {account_name}: Cannot assume role - {str(e)}"
        errors.append(error_msg)
    except Exception as e:
        error_msg = f"❌ {account_name}: Unexpected error - {str(e)}"
        errors.append(error_msg)
    
    return users_data, errors

def fetch_iam_users_data(selected_account_ids, all_accounts, role_name, age_threshold):
    """Fetch IAM users data - OPTIMIZED (parallel processing)"""
    all_users = []
    all_errors = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    total_accounts = len(selected_account_ids)
    completed = 0
    
    # Process all accounts in parallel
    with ThreadPoolExecutor(max_workers=AWSConfig.MAX_WORKERS) as executor:
        future_to_account = {
            executor.submit(get_iam_users_for_account, account_id,
                          AWSOrganizations.get_account_name_by_id(account_id, all_accounts),
                          role_name, age_threshold): account_id
            for account_id in selected_account_ids
        }
        
        # Process as they complete
        for future in as_completed(future_to_account):
            account_id = future_to_account[future]
            account_name = AWSOrganizations.get_account_name_by_id(account_id, all_accounts)
            completed += 1
            
            status_text.text(f"📡 Scanning: {account_name} ({completed}/{total_accounts})")
            progress_bar.progress(completed / total_accounts)
            
            try:
                users, errors = future.result()
                all_users.extend(users)
                all_errors.extend(errors)
            except Exception as e:
                all_errors.append(f"❌ {account_name}: Failed - {str(e)}")
    
    progress_bar.empty()
    status_text.empty()
    
    return all_users, all_errors

# ============================================================================
# BUTTON HANDLERS
# ============================================================================

# Check if fetch button was clicked
if st.session_state.get('iam_users_fetch_clicked', False):
    if not selected_account_ids:
        st.warning("⚠️ Please select at least one account.")
        st.session_state.iam_users_fetch_clicked = False
    else:
        start_time = time.time()
        
        with st.spinner(f"🔍 Scanning IAM users in {len(selected_account_ids)} account(s)..."):
            users_data, errors = fetch_iam_users_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, age_threshold)
            st.session_state.iam_users_data = users_data
            st.session_state.iam_users_errors = errors
            st.session_state.iam_users_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        elapsed_time = time.time() - start_time
        
        if users_data:
            st.success(f"✅ Successfully fetched {len(users_data)} user records in {elapsed_time:.2f} seconds")
        else:
            st.warning(f"⚠️ No IAM users found in {elapsed_time:.2f} seconds. Check errors below.")
        
        # Show errors if any
        if errors:
            with st.expander(f"⚠️ Errors and Warnings ({len(errors)})", expanded=True):
                for error in errors:
                    st.write(error)
        
        st.session_state.iam_users_fetch_clicked = False

# ============================================================================
# DISPLAY RESULTS
# ============================================================================

# Show debug info if enabled
if debug_mode and st.session_state.iam_users_errors:
    with st.expander("🐛 Debug Information", expanded=False):
        st.write(f"**Total Errors:** {len(st.session_state.iam_users_errors)}")
        for error in st.session_state.iam_users_errors:
            st.write(error)

if st.session_state.iam_users_data is not None:
    df = pd.DataFrame(st.session_state.iam_users_data)
    
    # Refresh button on main page
    col_title, col_refresh = st.columns([5, 1])
    with col_title:
        if st.session_state.iam_users_last_refresh:
            st.caption(f"Last refreshed: {st.session_state.iam_users_last_refresh}")
    with col_refresh:
        if st.button("🔁 Refresh", type="secondary", use_container_width=True, key="iam_users_refresh_btn"):
            if not selected_account_ids:
                st.warning("⚠️ Please select at least one account.")
            else:
                start_time = time.time()
                
                with st.spinner(f"🔍 Refreshing data..."):
                    users_data, errors = fetch_iam_users_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, age_threshold)
                    st.session_state.iam_users_data = users_data
                    st.session_state.iam_users_errors = errors
                    st.session_state.iam_users_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                
                elapsed_time = time.time() - start_time
                
                if users_data:
                    st.success(f"✅ Data refreshed ({len(users_data)} records in {elapsed_time:.2f} seconds)")
                else:
                    st.warning(f"⚠️ No IAM users found in {elapsed_time:.2f} seconds")
                
                if errors:
                    with st.expander(f"⚠️ Errors and Warnings ({len(errors)})", expanded=True):
                        for error in errors:
                            st.write(error)
                
                st.rerun()
    
    if df.empty:
        st.info("ℹ️ No IAM users found in the selected accounts.")
        
        # Show troubleshooting tips
        with st.expander("🔍 Troubleshooting Tips"):
            st.markdown("""
            **Possible reasons for no IAM users:**
            
            1. **No users exist** - The selected accounts may not have any IAM users
            2. **Permission issues** - The assumed role may not have `iam:ListUsers` permission
            3. **Role trust issue** - The target role may not trust the base credentials
            
            **How to verify:**
            - Check the debug information above
            - Enable "Show Debug Info" in the sidebar
            - Verify IAM permissions for the ReadOnlyRole
            - Test with AWS CLI: `aws iam list-users --profile <account>`
            """)
    else:
        # Summary metrics
        st.subheader("📊 Summary Metrics")
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        unique_users = df['User Name'].nunique()
        total_keys = len(df[df['Access Key ID'] != 'No Keys'])
        users_no_mfa = len(df[df['MFA Enabled'] == '❌ No']['User Name'].unique())
        overdue_keys = len(df[df['Key Rotation Status'] == '⚠️ Overdue'])
        active_keys = len(df[df['Key Status'] == 'Active'])
        
        with col1:
            st.metric("Total Users", unique_users)
        
        with col2:
            st.metric("🔑 Total Keys", total_keys)
        
        with col3:
            st.metric("⚠️ Overdue Keys", overdue_keys)
        
        with col4:
            st.metric("🔓 Active Keys", active_keys)
        
        with col5:
            st.metric("❌ No MFA", users_no_mfa)
        
        st.markdown("---")
        
        # Filters
        st.subheader("🔍 Filters")
        
        filter_col1, filter_col2, filter_col3 = st.columns(3)
        
        with filter_col1:
            account_filter = st.multiselect(
                "Account:",
                options=sorted(df['Account Name'].unique().tolist()),
                default=sorted(df['Account Name'].unique().tolist())
            )
        
        with filter_col2:
            key_status_filter = st.multiselect(
                "Key Status:",
                options=sorted(df['Key Status'].unique().tolist()),
                default=sorted(df['Key Status'].unique().tolist())
            )
        
        with filter_col3:
            rotation_filter = st.multiselect(
                "Rotation Status:",
                options=sorted(df['Key Rotation Status'].unique().tolist()),
                default=sorted(df['Key Rotation Status'].unique().tolist())
            )
        
        # Apply filters
        filtered_df = df[
            (df['Account Name'].isin(account_filter)) &
            (df['Key Status'].isin(key_status_filter)) &
            (df['Key Rotation Status'].isin(rotation_filter))
        ]
        
        st.markdown("---")
        
        # Display data
        st.subheader(f"📋 IAM Users ({len(filtered_df)} records)")
        
        # Column selector
        available_columns = filtered_df.columns.tolist()
        default_columns = [
            'Account Name', 'User Name', 'User Age (Days)', 'MFA Enabled',
            'Access Key ID', 'Key Status', 'Key Age (Days)', 'Key Rotation Status'
        ]
        
        selected_columns = st.multiselect(
            "Select columns to display:",
            options=available_columns,
            default=[col for col in default_columns if col in available_columns]
        )
        
        if selected_columns:
            display_df = filtered_df[selected_columns]
        else:
            display_df = filtered_df
        
        st.dataframe(display_df, use_container_width=True, height=500, hide_index=True)
        
        # Download button
        st.markdown("---")
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Download IAM Users Report (CSV)",
            data=csv,
            file_name=f"iam_users_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
        
        # Statistics
        with st.expander("📈 Additional Statistics"):
            stat_col1, stat_col2 = st.columns(2)
            
            with stat_col1:
                st.write("**Keys by Rotation Status:**")
                rotation_counts = filtered_df['Key Rotation Status'].value_counts()
                st.dataframe(rotation_counts, use_container_width=True)
            
            with stat_col2:
                st.write("**MFA Status Distribution:**")
                mfa_counts = filtered_df.groupby('User Name')['MFA Enabled'].first().value_counts()
                st.dataframe(mfa_counts, use_container_width=True)

else:
    st.info("👈 Configure options in the sidebar and click 'Fetch Data' to begin.")
