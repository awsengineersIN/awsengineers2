"""
AWS Multi-Account Dashboard - Main Application

Landing page that validates credentials and lists all dashboards.
"""

import streamlit as st
from modules.aws_helper import validate_aws_config, AWSOrganizations

# Page configuration
st.set_page_config(
    page_title="AWS Multi-Account Dashboard",
    page_icon="☁️",
    layout="wide"
)

# Header
st.title("☁️ AWS Multi-Account Dashboard")
st.markdown("Centralized monitoring and management across multiple AWS accounts")

# ============================================================================
# VALIDATE AWS CONFIGURATION
# ============================================================================

with st.spinner("🔐 Validating AWS credentials..."):
    is_valid, message, account_id = validate_aws_config()

if not is_valid:
    st.error(message)
    st.stop()

st.success(message)

# ============================================================================
# LOAD ORGANIZATION ACCOUNTS
# ============================================================================

if 'accounts' not in st.session_state:
    with st.spinner("📡 Loading organization accounts..."):
        try:
            accounts = AWSOrganizations.list_accounts()
            st.session_state.accounts = accounts
            st.success(f"✅ Loaded {len(accounts)} accounts from AWS Organizations")
        except Exception as e:
            st.error(f"❌ Failed to load accounts: {str(e)}")
            st.stop()
else:
    st.info(f"📋 {len(st.session_state.accounts)} accounts loaded")

# ============================================================================
# DASHBOARD NAVIGATION
# ============================================================================

st.markdown("---")
st.subheader("📊 Available Dashboards")

col1, col2 = st.columns(2)

with col1:
    st.markdown("""
    ### 🖥️ Infrastructure
    - **EC2 Details** - View EC2 instances across accounts and regions
    - **Account Health** - Comprehensive account health scoring
    """)

with col2:
    st.markdown("""
    ### 🔒 Security & Compliance
    - **Security Hub** - Security findings and compliance status
    - **AWS Config** - Configuration compliance rules
    - **IAM Users** - User access keys and MFA status
    """)

st.markdown("---")

# Display account list
with st.expander("📋 View All Accounts", expanded=False):
    import pandas as pd
    
    accounts_df = pd.DataFrame(st.session_state.accounts)
    st.dataframe(
        accounts_df[['Name', 'Id', 'Email', 'Status']],
        use_container_width=True,
        hide_index=True
    )

# Footer
st.markdown("---")
st.caption("💡 Select a dashboard from the sidebar to begin")
