# Service Dashboard Template - Quick Start Guide

## 📋 Template Overview

The template [137] provides a complete, production-ready dashboard with:
- ✅ Parallel processing (5-10x faster)
- ✅ Debug mode built-in
- ✅ Error handling
- ✅ Progress tracking
- ✅ Filters and metrics
- ✅ CSV download
- ✅ Troubleshooting tips

**You only need to implement 1-2 helper functions!**

---

## 🚀 Quick Start (3 Steps)

### Step 1: Copy Template and Configure

1. Copy `service_dashboard_template.py` to `pages/Your_Service.py`
2. Update configuration section (lines 20-30):

```python
# BEFORE
PAGE_TITLE = "[SERVICE NAME]"
PAGE_ICON = "📊"
PAGE_KEY_PREFIX = "[service_key]_"

# AFTER (Example: RDS Dashboard)
PAGE_TITLE = "RDS Instances"
PAGE_ICON = "🗄️"
PAGE_KEY_PREFIX = "rds_"
```

### Step 2: Implement Helper Function

**Choose ONE based on your service:**

#### Option A: Regional Service (EC2, RDS, Lambda, etc.)

Implement `get_service_data_in_region()` function (starts at line 75):

```python
def get_service_data_in_region(region, account_id, account_name, role_name):
    """Get RDS instances for a specific region"""
    data_items = []
    errors = []
    
    try:
        # 1. Get service client
        rds_client = AWSSession.get_client_for_account('rds', account_id, role_name, region)
        
        # 2. Fetch data with pagination
        paginator = rds_client.get_paginator('describe_db_instances')
        
        for page in paginator.paginate():
            for db in page['DBInstances']:
                data_item = {
                    'Account ID': account_id,
                    'Account Name': account_name,
                    'Region': region,
                    'DB Instance ID': db['DBInstanceIdentifier'],
                    'DB Name': db.get('DBName', 'N/A'),
                    'Engine': db['Engine'],
                    'Status': db['DBInstanceStatus'],
                    'Instance Class': db['DBInstanceClass'],
                }
                data_items.append(data_item)
                    
    except ClientError as e:
        errors.append(f"⚠️ {account_name}/{region}: Cannot access RDS - {str(e)}")
    except Exception as e:
        errors.append(f"❌ {account_name}/{region}: Unexpected error - {str(e)}")
    
    return data_items, errors
```

#### Option B: Global Service (IAM, Route53, CloudFront, etc.)

Implement `get_service_data_for_account()` function (starts at line 151):

```python
def get_service_data_for_account(account_id, account_name, role_name):
    """Get CloudFront distributions for an account"""
    data_items = []
    errors = []
    
    try:
        # 1. Get service client (always use us-east-1 for global services)
        cf_client = AWSSession.get_client_for_account('cloudfront', account_id, role_name, 'us-east-1')
        
        # 2. Fetch data with pagination
        paginator = cf_client.get_paginator('list_distributions')
        
        for page in paginator.paginate():
            if 'Items' in page['DistributionList']:
                for dist in page['DistributionList']['Items']:
                    data_item = {
                        'Account ID': account_id,
                        'Account Name': account_name,
                        'Distribution ID': dist['Id'],
                        'Domain Name': dist['DomainName'],
                        'Status': dist['Status'],
                        'Enabled': dist['Enabled'],
                    }
                    data_items.append(data_item)
                    
    except ClientError as e:
        errors.append(f"❌ {account_name}: Cannot access CloudFront - {str(e)}")
    except Exception as e:
        errors.append(f"❌ {account_name}: Unexpected error - {str(e)}")
    
    return data_items, errors
```

### Step 3: Choose Fetch Function

In button handlers section (line 217 and 249), uncomment the appropriate line:

**For regional services:**
```python
# Use this line (default):
service_data, errors = fetch_service_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, selected_regions)
```

**For global services:**
```python
# Use this line instead:
service_data, errors = fetch_service_data_no_regions(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME)
```

**Done! Your dashboard is ready to use! 🎉**

---

## 📝 Optional Customizations

### Add Custom Filters (Line 305)

```python
with filter_col1:
    status_filter = st.multiselect(
        "Status:",
        options=sorted(df['Status'].unique().tolist()),
        default=sorted(df['Status'].unique().tolist())
    )

# Apply filter
filtered_df = df[
    (df['Status'].isin(status_filter)) &
    (df['Account Name'].isin(account_filter))
]
```

### Add Custom Metrics (Line 276)

```python
with col4:
    active_count = len(df[df['Status'] == 'available'])
    st.metric("🟢 Available", active_count)

with col5:
    stopped_count = len(df[df['Status'] == 'stopped'])
    st.metric("🔴 Stopped", stopped_count)
```

### Add Sidebar Options (Line 65)

```python
st.sidebar.markdown("---")
st.sidebar.subheader("🔧 RDS Options")
engine_filter = st.sidebar.multiselect(
    "Filter by engine:",
    options=['mysql', 'postgres', 'oracle', 'sqlserver'],
    default=['mysql', 'postgres']
)
```

### Customize Troubleshooting Tips (Line 259)

```python
st.markdown("""
**Possible reasons for no RDS data:**

1. **No DB instances** - No RDS instances exist in these accounts
2. **Permission issues** - Role needs `rds:DescribeDBInstances`
3. **Regional service** - Ensure you've selected the correct regions

**Required permissions:**
- `rds:DescribeDBInstances`

**Enable Debug Mode** in sidebar to see detailed error messages.
""")
```

### Customize Display Columns (Line 335)

```python
default_columns = [
    'Account Name', 'Region', 'DB Instance ID', 
    'Engine', 'Status', 'Instance Class'
]
```

---

## 🎯 Real-World Examples

### Example 1: Lambda Functions Dashboard

```python
# Configuration
PAGE_TITLE = "Lambda Functions"
PAGE_ICON = "⚡"
PAGE_KEY_PREFIX = "lambda_"

# Helper function
def get_service_data_in_region(region, account_id, account_name, role_name):
    data_items = []
    errors = []
    
    try:
        lambda_client = AWSSession.get_client_for_account('lambda', account_id, role_name, region)
        paginator = lambda_client.get_paginator('list_functions')
        
        for page in paginator.paginate():
            for func in page['Functions']:
                data_item = {
                    'Account ID': account_id,
                    'Account Name': account_name,
                    'Region': region,
                    'Function Name': func['FunctionName'],
                    'Runtime': func['Runtime'],
                    'Memory (MB)': func['MemorySize'],
                    'Timeout (s)': func['Timeout'],
                    'Last Modified': func['LastModified'],
                }
                data_items.append(data_item)
                    
    except ClientError as e:
        errors.append(f"⚠️ {account_name}/{region}: Cannot access Lambda - {str(e)}")
    
    return data_items, errors
```

### Example 2: S3 Buckets Dashboard

```python
# Configuration
PAGE_TITLE = "S3 Buckets"
PAGE_ICON = "🪣"
PAGE_KEY_PREFIX = "s3_"

# Helper function (S3 is global but buckets are region-specific)
def get_service_data_for_account(account_id, account_name, role_name):
    data_items = []
    errors = []
    
    try:
        s3_client = AWSSession.get_client_for_account('s3', account_id, role_name, 'us-east-1')
        
        response = s3_client.list_buckets()
        
        for bucket in response['Buckets']:
            bucket_name = bucket['Name']
            
            # Get bucket region
            try:
                location = s3_client.get_bucket_location(Bucket=bucket_name)
                region = location['LocationConstraint'] or 'us-east-1'
            except:
                region = 'unknown'
            
            data_item = {
                'Account ID': account_id,
                'Account Name': account_name,
                'Region': region,
                'Bucket Name': bucket_name,
                'Creation Date': bucket['CreationDate'].strftime('%Y-%m-%d %H:%M:%S'),
            }
            data_items.append(data_item)
                    
    except ClientError as e:
        errors.append(f"❌ {account_name}: Cannot access S3 - {str(e)}")
    
    return data_items, errors

# Use global service fetch function
service_data, errors = fetch_service_data_no_regions(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME)
```

### Example 3: CloudWatch Alarms Dashboard

```python
# Configuration
PAGE_TITLE = "CloudWatch Alarms"
PAGE_ICON = "🔔"
PAGE_KEY_PREFIX = "cw_alarms_"

# Helper function
def get_service_data_in_region(region, account_id, account_name, role_name):
    data_items = []
    errors = []
    
    try:
        cw_client = AWSSession.get_client_for_account('cloudwatch', account_id, role_name, region)
        paginator = cw_client.get_paginator('describe_alarms')
        
        for page in paginator.paginate():
            for alarm in page['MetricAlarms']:
                data_item = {
                    'Account ID': account_id,
                    'Account Name': account_name,
                    'Region': region,
                    'Alarm Name': alarm['AlarmName'],
                    'State': alarm['StateValue'],
                    'Metric Name': alarm['MetricName'],
                    'Namespace': alarm['Namespace'],
                    'Actions Enabled': alarm['ActionsEnabled'],
                }
                data_items.append(data_item)
                    
    except ClientError as e:
        errors.append(f"⚠️ {account_name}/{region}: Cannot access CloudWatch - {str(e)}")
    
    return data_items, errors
```

---

## 🔍 Testing Your Dashboard

1. **Save file** to `pages/Your_Service.py`
2. **Restart Streamlit** app
3. **Select account(s)** in sidebar
4. **Select region(s)** in sidebar
5. **Click "Fetch Data"**
6. **Enable "Show Debug Info"** to see error messages

---

## 📚 Key Points to Remember

1. **Only implement 1 helper function** - The rest is already optimized
2. **Regional vs Global** - Choose the right fetch function
3. **Error handling is built-in** - Just return (data, errors) tuple
4. **Parallel processing automatic** - Don't modify fetch functions
5. **All customizations are optional** - Default template works great

---

## 🎯 Template Features (No Implementation Needed)

✅ Parallel account/region processing
✅ Progress bars and status updates
✅ Debug mode with error tracking
✅ Refresh button
✅ Filters (account, region)
✅ Summary metrics
✅ CSV download
✅ Troubleshooting tips
✅ Column selector
✅ Statistics section

**Everything is ready - just add your helper function! 🚀**
