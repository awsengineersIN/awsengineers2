
# Create a requirements.txt file for the dashboard
requirements = """streamlit==1.32.0
boto3==1.34.0
pandas==2.2.0
botocore==1.34.0
"""

with open('requirements.txt', 'w') as f:
    f.write(requirements)

print("✓ requirements.txt created successfully")
print("\nRequired packages:")
print(requirements)
