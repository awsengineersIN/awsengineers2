
# Create a streamlit config file for running on port 8051
config_content = """# Streamlit Configuration for AWS Multi-Account EC2 Dashboard

[server]
# Port number for the dashboard
port = 8051

# Set to false to prevent browser from opening automatically
headless = false

# Enables CORS for cross-origin requests
enableCORS = false

# Maximum file upload size in MB
maxUploadSize = 200

[browser]
# Whether to gather usage statistics
gatherUsageStats = false

[theme]
# Primary color for the dashboard (AWS Orange)
primaryColor = "#FF9900"

# Background color
backgroundColor = "#FFFFFF"

# Secondary background color
secondaryBackgroundColor = "#F0F2F6"

# Text color
textColor = "#262730"

# Font
font = "sans serif"
"""

# Create .streamlit directory structure
import os

# Save config file
with open('config.toml', 'w') as f:
    f.write(config_content)

print("✓ config.toml created successfully")
print("\nConfiguration settings:")
print("- Port: 8051 (as requested)")
print("- CORS: Disabled")
print("- Theme: AWS Orange color scheme")
print("\nTo use this configuration:")
print("1. Create a .streamlit folder in your project directory")
print("2. Move config.toml to .streamlit/config.toml")
print("3. Or run: streamlit run ec2_dashboard.py --server.port 8051")
