
# Create a configuration file example
config_example = """# AWS Multi-Account EC2 Dashboard Configuration

## Configuration Steps

### 1. AWS Credentials Setup
Ensure your AWS credentials are configured in ~/.aws/credentials or environment variables.
Your management account credentials should have permissions to:
- Call AWS Organizations APIs (list_accounts, describe_organization)
- Assume roles via AWS STS (sts:AssumeRole)

### 2. IAM Role Configuration

#### In Each Member Account:
Create a read-only IAM role with the following configuration:

**Role Name:** ReadOnlyRole (or your preferred name)

**Trust Relationship:**
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::<MANAGEMENT_ACCOUNT_ID>:root"
      },
      "Action": "sts:AssumeRole",
      "Condition": {}
    }
  ]
}

**Permissions Policy:** Attach the AWS managed policy:
- ReadOnlyAccess
OR create a custom policy with minimum permissions:
- ec2:DescribeInstances
- ec2:DescribeRegions
- ec2:DescribeTags

#### In Management Account:
Ensure the user/role running the dashboard has permission to assume roles:

{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "sts:AssumeRole",
      "Resource": "arn:aws:iam::*:role/ReadOnlyRole"
    },
    {
      "Effect": "Allow",
      "Action": [
        "organizations:ListAccounts",
        "organizations:DescribeOrganization",
        "organizations:DescribeAccount"
      ],
      "Resource": "*"
    }
  ]
}

### 3. Dashboard Configuration

Edit the following variables in ec2_dashboard.py:

```python
MANAGEMENT_ACCOUNT_PROFILE = 'default'  # Your AWS CLI profile name
READONLY_ROLE_NAME = 'ReadOnlyRole'     # The role name in member accounts
```

### 4. Running the Dashboard

```bash
# Install dependencies
pip install -r requirements.txt

# Run the dashboard
streamlit run ec2_dashboard.py
```

The dashboard will be accessible at: http://localhost:8051

To change the port:
```bash
streamlit run ec2_dashboard.py --server.port 8051
```

### 5. Features

- **Multi-Account Support:** Select one or all accounts from your organization
- **Cross-Region Discovery:** Automatically scans all AWS regions
- **Real-time Filtering:** Filter by state, region, and account
- **Export Capability:** Download results as CSV
- **Session State:** Maintains selections across reruns

### 6. Troubleshooting

**Error: "Unable to locate credentials"**
- Ensure AWS credentials are properly configured
- Check that the profile name matches your configuration

**Error: "Error assuming role"**
- Verify the role name is correct in all member accounts
- Check trust relationships in IAM roles
- Ensure management account has sts:AssumeRole permission

**Error: "No accounts found"**
- Verify Organizations API permissions
- Ensure you're running from the management account

**Slow Performance:**
- Consider caching results using st.cache_data
- Implement region filtering to reduce API calls
- Use multi-threading for parallel account scanning
"""

with open('CONFIGURATION.md', 'w') as f:
    f.write(config_example)

print("✓ CONFIGURATION.md created successfully")
print("\nConfiguration guide has been created with:")
print("- AWS credentials setup")
print("- IAM role configuration")
print("- Trust relationships")
print("- Running instructions")
print("- Troubleshooting guide")
