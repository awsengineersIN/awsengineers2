# AWS Multi-Account EC2 Dashboard

A Streamlit-based dashboard for viewing and managing EC2 instances across multiple AWS accounts in your organization.

## 🌟 Features

- **Multi-Account Support**: Automatically discovers and lists all accounts in your AWS Organization
- **Cross-Region Discovery**: Scans all AWS regions for EC2 instances
- **Real-time Filtering**: Filter instances by state, region, account, and instance type
- **Parallel Processing**: Fast data retrieval using multi-threaded execution
- **Interactive UI**: Clean and intuitive Streamlit interface
- **Export Capability**: Download results as CSV files
- **Session State Management**: Maintains selections across page refreshes
- **Secure Access**: Uses AWS STS AssumeRole for secure cross-account access

## 📋 Prerequisites

### AWS Setup
1. **Management Account**: You need access to the AWS Organizations management account
2. **Read-Only Role**: A read-only IAM role must exist in all member accounts with the same name
3. **Trust Relationship**: Member accounts must trust the management account

### Software Requirements
- Python 3.8 or higher
- AWS CLI configured with management account credentials
- Required Python packages (see requirements.txt)

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure AWS Credentials

Ensure your AWS credentials are configured for the management account:

```bash
aws configure
```

Or use a named profile:

```bash
aws configure --profile my-management-account
```

### 3. Set Up IAM Roles

#### In Each Member Account:

Create an IAM role with the following configuration:

**Role Name**: `ReadOnlyRole` (or your preferred name)

**Trust Policy**:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::<MANAGEMENT_ACCOUNT_ID>:root"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

**Permissions**: Attach the AWS managed policy `ReadOnlyAccess` or create a custom policy:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ec2:DescribeInstances",
        "ec2:DescribeRegions",
        "ec2:DescribeTags"
      ],
      "Resource": "*"
    }
  ]
}
```

#### In Management Account:

Ensure your user/role has these permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "sts:AssumeRole",
      "Resource": "arn:aws:iam::*:role/ReadOnlyRole"
    },
    {
      "Effect": "Allow",
      "Action": [
        "organizations:ListAccounts",
        "organizations:DescribeOrganization",
        "organizations:DescribeAccount"
      ],
      "Resource": "*"
    }
  ]
}
```

### 4. Configure the Dashboard

Edit the configuration variables in `ec2_dashboard.py` or `ec2_dashboard_enhanced.py`:

```python
MANAGEMENT_ACCOUNT_PROFILE = 'default'  # Your AWS CLI profile name
READONLY_ROLE_NAME = 'ReadOnlyRole'     # Role name in member accounts
```

### 5. Run the Dashboard

**Basic Version**:
```bash
streamlit run ec2_dashboard.py --server.port 8051
```

**Enhanced Version** (recommended):
```bash
streamlit run ec2_dashboard_enhanced.py --server.port 8051
```

The dashboard will be accessible at: `http://localhost:8051`

## 📁 Project Structure

```
.
├── ec2_dashboard.py              # Basic version of the dashboard
├── ec2_dashboard_enhanced.py     # Enhanced version with caching and parallel processing
├── requirements.txt              # Python dependencies
├── config.toml                   # Streamlit configuration
├── CONFIGURATION.md              # Detailed configuration guide
└── README.md                     # This file
```

## 🎯 Usage

1. **Select Accounts**: Use the sidebar to select one or more AWS accounts
2. **Choose Regions**: Select all regions or specific regions to scan
3. **Fetch Data**: Click "Fetch EC2 Instances" to retrieve instance information
4. **Filter Results**: Use the filter dropdowns to narrow down the results
5. **Export Data**: Download the filtered or complete dataset as CSV

## 🔧 Advanced Configuration

### Custom Port Configuration

Create a `.streamlit/config.toml` file in your project directory:

```toml
[server]
port = 8051
headless = false
enableCORS = false

[theme]
primaryColor = "#FF9900"
backgroundColor = "#FFFFFF"
```

Or use command-line argument:
```bash
streamlit run ec2_dashboard.py --server.port 8051
```

### Environment Variables

You can also configure AWS credentials using environment variables:

```bash
export AWS_ACCESS_KEY_ID=your_access_key
export AWS_SECRET_ACCESS_KEY=your_secret_key
export AWS_DEFAULT_REGION=us-east-1
```

## 🆚 Version Comparison

| Feature | Basic Version | Enhanced Version |
|---------|--------------|------------------|
| Multi-account support | ✅ | ✅ |
| Cross-region scanning | ✅ | ✅ |
| Filtering | ✅ | ✅ |
| CSV export | ✅ | ✅ |
| Caching | ❌ | ✅ |
| Parallel processing | ❌ | ✅ |
| Custom CSS styling | ❌ | ✅ |
| Region selection | ❌ | ✅ |
| Column customization | ❌ | ✅ |
| Additional statistics | ❌ | ✅ |

## 🐛 Troubleshooting

### "Unable to locate credentials"
- Ensure AWS credentials are properly configured
- Check that the profile name matches your configuration
- Verify the profile in `~/.aws/credentials`

### "Error assuming role"
- Verify the role name is correct in all member accounts
- Check trust relationships in IAM roles
- Ensure management account has `sts:AssumeRole` permission
- Verify the role ARN format: `arn:aws:iam::<ACCOUNT_ID>:role/<ROLE_NAME>`

### "No accounts found"
- Verify Organizations API permissions in management account
- Ensure you're running from the management account
- Check that accounts are in ACTIVE status

### Slow Performance
- Use the enhanced version with caching and parallel processing
- Select specific regions instead of scanning all regions
- Consider filtering by account to reduce API calls

### Port Already in Use
```bash
# Check what's using port 8051
lsof -i :8051  # Mac/Linux
netstat -ano | findstr :8051  # Windows

# Use a different port
streamlit run ec2_dashboard.py --server.port 8052
```

## 🔒 Security Considerations

1. **Least Privilege**: Only grant necessary permissions to the read-only role
2. **Credential Management**: Never commit AWS credentials to version control
3. **Role Session Names**: Each session has a unique identifier for audit trails
4. **Trust Policies**: Use specific principal ARNs instead of account root when possible
5. **Temporary Credentials**: All cross-account access uses temporary STS credentials

## 🎨 Customization

### Adding More AWS Services

To add support for other AWS services (RDS, Lambda, etc.), follow this pattern:

```python
def get_service_resources_for_account(account_id, account_name, role_name):
    assumed_session = assume_role(account_id, role_name)
    if not assumed_session:
        return []

    client = assumed_session.client('service-name')
    # Implement service-specific logic
    return resources
```

### Custom Filters

Add custom filters by modifying the filter section:

```python
with filter_col5:
    custom_filter = st.multiselect(
        "Custom Field:",
        options=sorted(df['CustomField'].unique().tolist()),
        default=sorted(df['CustomField'].unique().tolist())
    )
```

## 📝 Best Practices

1. **Caching**: Use the enhanced version with `@st.cache_data` for better performance
2. **Error Handling**: Always check for `None` returns from `assume_role()`
3. **Pagination**: Use boto3 paginators for large result sets
4. **Region Selection**: Filter regions to reduce API calls and improve speed
5. **Session Management**: Clear old data before fetching new results

## 🤝 Contributing

Contributions are welcome! Please follow these guidelines:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is provided as-is for educational and operational purposes.

## 🆘 Support

For issues and questions:
1. Check the troubleshooting section above
2. Review the CONFIGURATION.md file
3. Consult AWS documentation for IAM and Organizations
4. Check Streamlit documentation for UI-related issues

## 🙏 Acknowledgments

- Built with [Streamlit](https://streamlit.io/)
- AWS SDK for Python ([Boto3](https://boto3.amazonaws.com/))
- AWS Organizations and IAM services

---

**Note**: This dashboard is designed for read-only operations. It does not perform any write operations on your AWS resources.
