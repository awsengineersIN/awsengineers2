
import streamlit as st
import boto3
from botocore.exceptions import ClientError
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# Set page configuration
st.set_page_config(
    page_title="AWS Multi-Account EC2 Dashboard", 
    layout="wide",
    page_icon="🌩️"
)

# Initialize session state
if 'selected_accounts' not in st.session_state:
    st.session_state.selected_accounts = []
if 'ec2_data' not in st.session_state:
    st.session_state.ec2_data = None
if 'last_refresh' not in st.session_state:
    st.session_state.last_refresh = None

# Configuration
MANAGEMENT_ACCOUNT_PROFILE = 'default'  # Change to your AWS profile
READONLY_ROLE_NAME = 'ReadOnlyRole'  # Change to your role name
MAX_WORKERS = 5  # Parallel threads for faster processing

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #FF9900;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 20px;
        border-radius: 10px;
        text-align: center;
    }
    .stProgress > div > div > div > div {
        background-color: #FF9900;
    }
</style>
""", unsafe_allow_html=True)

# Helper Functions
@st.cache_data(ttl=300)  # Cache for 5 minutes
def get_all_accounts():
    """List all accounts in the organization with caching"""
    try:
        session = boto3.Session(profile_name=MANAGEMENT_ACCOUNT_PROFILE)
        org_client = session.client('organizations')

        accounts = []
        paginator = org_client.get_paginator('list_accounts')

        for page in paginator.paginate():
            for account in page['Accounts']:
                if account['Status'] == 'ACTIVE':
                    accounts.append({
                        'Id': account['Id'],
                        'Name': account['Name'],
                        'Email': account['Email'],
                        'Status': account['Status']
                    })
        return accounts
    except ClientError as e:
        st.error(f"Error listing accounts: {str(e)}")
        return []

@st.cache_data(ttl=3600)  # Cache for 1 hour
def get_all_regions():
    """Get list of all AWS regions with caching"""
    try:
        ec2_client = boto3.client('ec2', region_name='us-east-1')
        regions = ec2_client.describe_regions(AllRegions=False)['Regions']
        return sorted([region['RegionName'] for region in regions])
    except ClientError as e:
        st.error(f"Error getting regions: {str(e)}")
        return []

def assume_role(account_id, role_name):
    """Assume role in the target account"""
    try:
        session = boto3.Session(profile_name=MANAGEMENT_ACCOUNT_PROFILE)
        sts_client = session.client('sts')

        role_arn = f"arn:aws:iam::{account_id}:role/{role_name}"

        response = sts_client.assume_role(
            RoleArn=role_arn,
            RoleSessionName=f"streamlit-ec2-{account_id}-{int(time.time())}"
        )

        credentials = response['Credentials']

        assumed_session = boto3.Session(
            aws_access_key_id=credentials['AccessKeyId'],
            aws_secret_access_key=credentials['SecretAccessKey'],
            aws_session_token=credentials['SessionToken']
        )

        return assumed_session
    except ClientError as e:
        return None

def get_ec2_instances_in_region(session, region, account_id, account_name):
    """Get EC2 instances for a specific region"""
    instances = []
    try:
        ec2_client = session.client('ec2', region_name=region)
        paginator = ec2_client.get_paginator('describe_instances')

        for page in paginator.paginate():
            for reservation in page['Reservations']:
                for instance in reservation['Instances']:
                    # Extract instance name from tags
                    instance_name = ''
                    tags_dict = {}
                    if 'Tags' in instance:
                        for tag in instance['Tags']:
                            tags_dict[tag['Key']] = tag['Value']
                            if tag['Key'] == 'Name':
                                instance_name = tag['Value']

                    # Get VPC name if available
                    vpc_id = instance.get('VpcId', 'N/A')

                    instance_data = {
                        'Account ID': account_id,
                        'Account Name': account_name,
                        'Region': region,
                        'Instance ID': instance['InstanceId'],
                        'Instance Name': instance_name,
                        'Instance Type': instance['InstanceType'],
                        'State': instance['State']['Name'],
                        'Private IP': instance.get('PrivateIpAddress', 'N/A'),
                        'Public IP': instance.get('PublicIpAddress', 'N/A'),
                        'VPC ID': vpc_id,
                        'Subnet ID': instance.get('SubnetId', 'N/A'),
                        'Availability Zone': instance['Placement']['AvailabilityZone'],
                        'Launch Time': instance['LaunchTime'].strftime('%Y-%m-%d %H:%M:%S'),
                        'Platform': instance.get('Platform', 'Linux/Unix'),
                        'Key Name': instance.get('KeyName', 'N/A'),
                        'Monitoring': instance['Monitoring']['State']
                    }
                    instances.append(instance_data)
    except ClientError as e:
        # Region might not be enabled or accessible
        pass

    return instances

def get_ec2_instances_for_account(account_id, account_name, role_name, regions):
    """Get all EC2 instances for a specific account across selected regions"""
    assumed_session = assume_role(account_id, role_name)
    if not assumed_session:
        return []

    all_instances = []

    # Use ThreadPoolExecutor for parallel region scanning
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(
                get_ec2_instances_in_region, 
                assumed_session, 
                region, 
                account_id, 
                account_name
            ): region 
            for region in regions
        }

        for future in as_completed(futures):
            try:
                instances = future.result()
                all_instances.extend(instances)
            except Exception as e:
                pass

    return all_instances

def fetch_all_ec2_data(selected_account_ids, all_accounts, role_name, regions):
    """Fetch EC2 data for all selected accounts"""
    all_ec2_data = []

    progress_bar = st.progress(0)
    status_text = st.empty()

    total_accounts = len(selected_account_ids)

    for idx, account_id in enumerate(selected_account_ids):
        account_name = next((acc['Name'] for acc in all_accounts if acc['Id'] == account_id), account_id)

        status_text.text(f"📡 Scanning: {account_name} ({idx + 1}/{total_accounts})")

        instances = get_ec2_instances_for_account(account_id, account_name, role_name, regions)
        all_ec2_data.extend(instances)

        progress_bar.progress((idx + 1) / total_accounts)

    progress_bar.empty()
    status_text.empty()

    return all_ec2_data

# Main App UI
st.markdown('<p class="main-header">🌩️ AWS Multi-Account EC2 Dashboard</p>', unsafe_allow_html=True)

if st.session_state.last_refresh:
    st.caption(f"Last refreshed: {st.session_state.last_refresh}")

st.markdown("---")

# Sidebar Configuration
st.sidebar.header("⚙️ Configuration")

# Load accounts
with st.spinner("Loading AWS Organization accounts..."):
    all_accounts = get_all_accounts()

if not all_accounts:
    st.error("❌ No accounts found or unable to access AWS Organizations.")
    st.info("Please check your AWS credentials and Organizations permissions.")
    st.stop()

# Display account summary
st.sidebar.success(f"✅ Found {len(all_accounts)} active accounts")

# Account Selection
st.sidebar.subheader("📋 Account Selection")
account_options = {f"{acc['Name']} ({acc['Id']})": acc['Id'] for acc in all_accounts}

select_all = st.sidebar.checkbox("Select All Accounts", value=False)

if select_all:
    selected_account_names = list(account_options.keys())
else:
    selected_account_names = st.sidebar.multiselect(
        "Choose Accounts:",
        options=list(account_options.keys()),
        default=st.session_state.selected_accounts if st.session_state.selected_accounts else [],
        help="Select one or more accounts to scan for EC2 instances"
    )

selected_account_ids = [account_options[name] for name in selected_account_names]
st.session_state.selected_accounts = selected_account_names

# Region Selection
st.sidebar.subheader("🌍 Region Selection")
all_regions = get_all_regions()

region_selection_mode = st.sidebar.radio(
    "Region Mode:",
    ["All Regions", "Specific Regions"],
    help="Choose to scan all regions or select specific ones"
)

if region_selection_mode == "All Regions":
    selected_regions = all_regions
    st.sidebar.info(f"Scanning all {len(all_regions)} regions")
else:
    selected_regions = st.sidebar.multiselect(
        "Choose Regions:",
        options=all_regions,
        default=['us-east-1', 'us-west-2'],
        help="Select specific regions to scan"
    )

# Fetch Button
st.sidebar.markdown("---")
if st.sidebar.button("🔄 Fetch EC2 Instances", type="primary", use_container_width=True):
    if not selected_account_ids:
        st.warning("⚠️ Please select at least one account.")
    elif not selected_regions:
        st.warning("⚠️ Please select at least one region.")
    else:
        start_time = time.time()

        with st.spinner(f"🔍 Scanning {len(selected_account_ids)} account(s) across {len(selected_regions)} region(s)..."):
            ec2_data = fetch_all_ec2_data(
                selected_account_ids, 
                all_accounts, 
                READONLY_ROLE_NAME, 
                selected_regions
            )
            st.session_state.ec2_data = ec2_data
            st.session_state.last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        elapsed_time = time.time() - start_time
        st.success(f"✅ Successfully fetched {len(ec2_data)} instances in {elapsed_time:.2f} seconds")

# Clear Data Button
if st.sidebar.button("🗑️ Clear Data", use_container_width=True):
    st.session_state.ec2_data = None
    st.session_state.last_refresh = None
    st.rerun()

# Main Content Area
if st.session_state.ec2_data is not None:
    df = pd.DataFrame(st.session_state.ec2_data)

    if df.empty:
        st.info("ℹ️ No EC2 instances found in the selected accounts and regions.")
    else:
        # Summary Metrics
        st.subheader("📊 Summary Metrics")

        col1, col2, col3, col4, col5 = st.columns(5)

        with col1:
            st.metric("Total Instances", len(df))

        with col2:
            running_count = len(df[df['State'] == 'running'])
            st.metric("🟢 Running", running_count)

        with col3:
            stopped_count = len(df[df['State'] == 'stopped'])
            st.metric("🔴 Stopped", stopped_count)

        with col4:
            unique_accounts = df['Account ID'].nunique()
            st.metric("Accounts", unique_accounts)

        with col5:
            unique_regions = df['Region'].nunique()
            st.metric("Regions", unique_regions)

        st.markdown("---")

        # Filters Section
        st.subheader("🔍 Filters")

        filter_col1, filter_col2, filter_col3, filter_col4 = st.columns(4)

        with filter_col1:
            state_filter = st.multiselect(
                "Instance State:",
                options=sorted(df['State'].unique().tolist()),
                default=sorted(df['State'].unique().tolist())
            )

        with filter_col2:
            region_filter = st.multiselect(
                "Region:",
                options=sorted(df['Region'].unique().tolist()),
                default=sorted(df['Region'].unique().tolist())
            )

        with filter_col3:
            account_filter = st.multiselect(
                "Account:",
                options=sorted(df['Account Name'].unique().tolist()),
                default=sorted(df['Account Name'].unique().tolist())
            )

        with filter_col4:
            instance_type_filter = st.multiselect(
                "Instance Type:",
                options=sorted(df['Instance Type'].unique().tolist()),
                default=sorted(df['Instance Type'].unique().tolist())
            )

        # Apply filters
        filtered_df = df[
            (df['State'].isin(state_filter)) &
            (df['Region'].isin(region_filter)) &
            (df['Account Name'].isin(account_filter)) &
            (df['Instance Type'].isin(instance_type_filter))
        ]

        st.markdown("---")

        # Instance Details
        st.subheader(f"📋 EC2 Instance Details ({len(filtered_df)} instances)")

        # Column selector
        available_columns = filtered_df.columns.tolist()
        default_columns = [
            'Account Name', 'Region', 'Instance ID', 'Instance Name', 
            'Instance Type', 'State', 'Private IP', 'Public IP'
        ]

        selected_columns = st.multiselect(
            "Select columns to display:",
            options=available_columns,
            default=[col for col in default_columns if col in available_columns]
        )

        if selected_columns:
            display_df = filtered_df[selected_columns]
        else:
            display_df = filtered_df

        # Display dataframe with conditional formatting
        st.dataframe(
            display_df,
            use_container_width=True,
            height=500,
            hide_index=True
        )

        # Download Section
        st.markdown("---")
        col_download1, col_download2 = st.columns(2)

        with col_download1:
            csv = filtered_df.to_csv(index=False)
            st.download_button(
                label="📥 Download Filtered Data (CSV)",
                data=csv,
                file_name=f"ec2_instances_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv",
                use_container_width=True
            )

        with col_download2:
            all_csv = df.to_csv(index=False)
            st.download_button(
                label="📥 Download All Data (CSV)",
                data=all_csv,
                file_name=f"ec2_instances_all_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv",
                use_container_width=True
            )

        # Additional Statistics
        with st.expander("📈 Additional Statistics"):
            stat_col1, stat_col2 = st.columns(2)

            with stat_col1:
                st.write("**Instances by State:**")
                state_counts = filtered_df['State'].value_counts()
                st.dataframe(state_counts, use_container_width=True)

            with stat_col2:
                st.write("**Instances by Type:**")
                type_counts = filtered_df['Instance Type'].value_counts().head(10)
                st.dataframe(type_counts, use_container_width=True)

            st.write("**Instances by Region:**")
            region_counts = filtered_df['Region'].value_counts()
            st.dataframe(region_counts, use_container_width=True)

else:
    # Welcome screen
    st.info("👈 **Get Started:** Select accounts and regions from the sidebar, then click 'Fetch EC2 Instances'")

    st.markdown("""
    ### 🚀 Features

    - **Multi-Account Support**: Scan EC2 instances across all accounts in your organization
    - **Cross-Region Discovery**: Automatically discover instances in all AWS regions
    - **Real-time Filtering**: Filter results by state, region, account, and instance type
    - **Parallel Processing**: Fast scanning with multi-threaded execution
    - **Export Capability**: Download results as CSV for further analysis
    - **Session Persistence**: Maintains your selections across page refreshes

    ### 📋 Prerequisites

    1. AWS credentials configured for your management account
    2. Read-only IAM role created in all member accounts
    3. Trust relationship established between accounts

    See **CONFIGURATION.md** for detailed setup instructions.
    """)

# Footer
st.markdown("---")
st.caption("AWS Multi-Account EC2 Dashboard | Powered by Streamlit & Boto3 | 🔒 Secure Multi-Account Access")
