
import streamlit as st
import boto3
from botocore.exceptions import ClientError
import pandas as pd
from datetime import datetime

# Set page configuration
st.set_page_config(page_title="AWS Multi-Account EC2 Dashboard", layout="wide")

# Initialize session state
if 'selected_accounts' not in st.session_state:
    st.session_state.selected_accounts = []
if 'ec2_data' not in st.session_state:
    st.session_state.ec2_data = None

# Configuration
MANAGEMENT_ACCOUNT_PROFILE = 'default'  # or your profile name
READONLY_ROLE_NAME = 'ReadOnlyRole'  # Replace with your actual role name

# Helper Functions
def get_organizations_client():
    """Create and return an Organizations client"""
    try:
        session = boto3.Session(profile_name=MANAGEMENT_ACCOUNT_PROFILE)
        org_client = session.client('organizations')
        return org_client
    except Exception as e:
        st.error(f"Error creating Organizations client: {str(e)}")
        return None

def list_all_accounts():
    """List all accounts in the organization"""
    org_client = get_organizations_client()
    if not org_client:
        return []

    accounts = []
    try:
        paginator = org_client.get_paginator('list_accounts')
        for page in paginator.paginate():
            for account in page['Accounts']:
                if account['Status'] == 'ACTIVE':
                    accounts.append({
                        'Id': account['Id'],
                        'Name': account['Name'],
                        'Email': account['Email']
                    })
        return accounts
    except ClientError as e:
        st.error(f"Error listing accounts: {str(e)}")
        return []

def assume_role(account_id, role_name):
    """Assume role in the target account"""
    try:
        session = boto3.Session(profile_name=MANAGEMENT_ACCOUNT_PROFILE)
        sts_client = session.client('sts')

        role_arn = f"arn:aws:iam::{account_id}:role/{role_name}"

        response = sts_client.assume_role(
            RoleArn=role_arn,
            RoleSessionName=f"streamlit-session-{account_id}"
        )

        credentials = response['Credentials']

        # Create a new session with assumed role credentials
        assumed_session = boto3.Session(
            aws_access_key_id=credentials['AccessKeyId'],
            aws_secret_access_key=credentials['SecretAccessKey'],
            aws_session_token=credentials['SessionToken']
        )

        return assumed_session
    except ClientError as e:
        st.error(f"Error assuming role in account {account_id}: {str(e)}")
        return None

def get_all_regions():
    """Get list of all AWS regions"""
    try:
        ec2_client = boto3.client('ec2', region_name='us-east-1')
        regions = ec2_client.describe_regions()['Regions']
        return [region['RegionName'] for region in regions]
    except ClientError as e:
        st.error(f"Error getting regions: {str(e)}")
        return []

def get_ec2_instances_for_account(account_id, account_name, role_name):
    """Get all EC2 instances across all regions for a specific account"""
    assumed_session = assume_role(account_id, role_name)
    if not assumed_session:
        return []

    all_instances = []
    regions = get_all_regions()

    for region in regions:
        try:
            ec2_client = assumed_session.client('ec2', region_name=region)
            response = ec2_client.describe_instances()

            for reservation in response['Reservations']:
                for instance in reservation['Instances']:
                    # Extract instance tags
                    instance_name = ''
                    if 'Tags' in instance:
                        for tag in instance['Tags']:
                            if tag['Key'] == 'Name':
                                instance_name = tag['Value']
                                break

                    instance_data = {
                        'Account ID': account_id,
                        'Account Name': account_name,
                        'Region': region,
                        'Instance ID': instance['InstanceId'],
                        'Instance Name': instance_name,
                        'Instance Type': instance['InstanceType'],
                        'State': instance['State']['Name'],
                        'Private IP': instance.get('PrivateIpAddress', 'N/A'),
                        'Public IP': instance.get('PublicIpAddress', 'N/A'),
                        'Launch Time': instance['LaunchTime'].strftime('%Y-%m-%d %H:%M:%S'),
                        'Platform': instance.get('Platform', 'Linux/Unix')
                    }
                    all_instances.append(instance_data)
        except ClientError as e:
            # Some regions might not be enabled
            continue

    return all_instances

def fetch_ec2_data(selected_account_ids, all_accounts, role_name):
    """Fetch EC2 data for selected accounts"""
    all_ec2_data = []

    # Create a progress bar
    progress_bar = st.progress(0)
    status_text = st.empty()

    total_accounts = len(selected_account_ids)

    for idx, account_id in enumerate(selected_account_ids):
        # Find account name
        account_name = next((acc['Name'] for acc in all_accounts if acc['Id'] == account_id), account_id)

        status_text.text(f"Fetching data from account: {account_name} ({idx + 1}/{total_accounts})")

        instances = get_ec2_instances_for_account(account_id, account_name, role_name)
        all_ec2_data.extend(instances)

        progress_bar.progress((idx + 1) / total_accounts)

    progress_bar.empty()
    status_text.empty()

    return all_ec2_data

# Main App UI
st.title("🌩️ AWS Multi-Account EC2 Dashboard")
st.markdown("---")

# Sidebar for account selection
st.sidebar.header("⚙️ Configuration")

# Fetch all accounts
with st.spinner("Loading accounts from AWS Organizations..."):
    all_accounts = list_all_accounts()

if not all_accounts:
    st.error("No accounts found or unable to access AWS Organizations.")
    st.stop()

# Account selection
st.sidebar.subheader("Account Selection")
account_options = {f"{acc['Name']} ({acc['Id']})": acc['Id'] for acc in all_accounts}

# Add "Select All" option
select_all = st.sidebar.checkbox("Select All Accounts")

if select_all:
    selected_account_names = list(account_options.keys())
else:
    selected_account_names = st.sidebar.multiselect(
        "Choose Accounts:",
        options=list(account_options.keys()),
        default=st.session_state.selected_accounts if st.session_state.selected_accounts else []
    )

# Convert selected names to IDs
selected_account_ids = [account_options[name] for name in selected_account_names]

# Update session state
st.session_state.selected_accounts = selected_account_names

# Fetch button
if st.sidebar.button("🔄 Fetch EC2 Instances", type="primary"):
    if not selected_account_ids:
        st.warning("Please select at least one account.")
    else:
        with st.spinner("Fetching EC2 instances across all regions..."):
            ec2_data = fetch_ec2_data(selected_account_ids, all_accounts, READONLY_ROLE_NAME)
            st.session_state.ec2_data = ec2_data
        st.success(f"Successfully fetched data from {len(selected_account_ids)} account(s)")

# Display results
if st.session_state.ec2_data is not None:
    df = pd.DataFrame(st.session_state.ec2_data)

    if df.empty:
        st.info("No EC2 instances found in the selected accounts.")
    else:
        # Summary metrics
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric("Total Instances", len(df))

        with col2:
            running_count = len(df[df['State'] == 'running'])
            st.metric("Running", running_count)

        with col3:
            stopped_count = len(df[df['State'] == 'stopped'])
            st.metric("Stopped", stopped_count)

        with col4:
            unique_accounts = df['Account ID'].nunique()
            st.metric("Accounts", unique_accounts)

        st.markdown("---")

        # Filters
        st.subheader("🔍 Filters")

        filter_col1, filter_col2, filter_col3 = st.columns(3)

        with filter_col1:
            state_filter = st.multiselect(
                "Instance State:",
                options=df['State'].unique().tolist(),
                default=df['State'].unique().tolist()
            )

        with filter_col2:
            region_filter = st.multiselect(
                "Region:",
                options=sorted(df['Region'].unique().tolist()),
                default=sorted(df['Region'].unique().tolist())
            )

        with filter_col3:
            account_filter = st.multiselect(
                "Account:",
                options=df['Account Name'].unique().tolist(),
                default=df['Account Name'].unique().tolist()
            )

        # Apply filters
        filtered_df = df[
            (df['State'].isin(state_filter)) &
            (df['Region'].isin(region_filter)) &
            (df['Account Name'].isin(account_filter))
        ]

        st.markdown("---")
        st.subheader("📊 EC2 Instances")

        # Display filtered dataframe
        st.dataframe(
            filtered_df,
            use_container_width=True,
            height=500
        )

        # Download button
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Download as CSV",
            data=csv,
            file_name=f"ec2_instances_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
else:
    st.info("👈 Select accounts from the sidebar and click 'Fetch EC2 Instances' to begin.")

# Footer
st.markdown("---")
st.caption("AWS Multi-Account EC2 Dashboard | Powered by Streamlit & Boto3")
