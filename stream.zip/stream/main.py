"""
AWS Multi-Account Dashboard - Main Entry Point

This is the main entry point for the Streamlit application.
It provides account selection and page navigation for all dashboards.

Run with:
    streamlit run main.py

For local testing with credentials:
    export AWS_ACCESS_KEY_ID=your_access_key
    export AWS_SECRET_ACCESS_KEY=your_secret_key
    export AWS_SESSION_TOKEN=your_session_token
    streamlit run main.py

For profile-based authentication:
    export AWS_PROFILE=your-profile-name
    streamlit run main.py
"""

import streamlit as st
import sys
from modules.config import AWSConfig, validate_aws_config
from modules.iam import AWSOrganizations

# Configure Streamlit page
st.set_page_config(
    page_title="AWS Multi-Account Dashboard",
    page_icon="🌩️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #FF9900;
        margin-bottom: 10px;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #666;
        margin-bottom: 20px;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 15px;
        border-radius: 10px;
        text-align: center;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'selected_account' not in st.session_state:
    st.session_state.selected_account = None
if 'all_accounts' not in st.session_state:
    st.session_state.all_accounts = []

# Header
st.markdown('<p class="main-header">🌩️ AWS Multi-Account Dashboard</p>', unsafe_allow_html=True)
st.markdown('<p class="sub-header">Centralized view for all AWS resources</p>', unsafe_allow_html=True)

# Validate credentials
is_valid, message, account_id = validate_aws_config()

if is_valid:
    st.success(message)
else:
    st.error(message)
    st.error("❌ Unable to authenticate with AWS. Please check your credentials.")
    st.info("""
    **For Profile-Based Authentication:**
    ```bash
    export AWS_PROFILE=your-profile-name
    streamlit run main.py
    ```

    **For Environment Variable Authentication (Local Testing):**
    ```bash
    export AWS_ACCESS_KEY_ID=your_access_key
    export AWS_SECRET_ACCESS_KEY=your_secret_key
    export AWS_SESSION_TOKEN=your_session_token  # Optional, for STS credentials
    streamlit run main.py
    ```
    """)
    st.stop()

# Sidebar
st.sidebar.header("⚙️ Configuration")

# Load accounts
try:
    if not st.session_state.all_accounts:
        with st.spinner("Loading AWS accounts from Organizations..."):
            st.session_state.all_accounts = AWSOrganizations.list_accounts()

    all_accounts = st.session_state.all_accounts

    if not all_accounts:
        st.error("❌ No active accounts found in AWS Organizations.")
        st.info("Ensure you have Organizations enabled and active accounts created.")
        st.stop()

    st.sidebar.success(f"✅ Found {len(all_accounts)} active account(s)")

except Exception as e:
    st.error(f"❌ Error loading accounts: {str(e)}")
    st.info("""
    Ensure your management account has Organizations permissions:
    - organizations:ListAccounts
    - organizations:DescribeOrganization
    """)
    st.stop()

# Account selection
st.sidebar.subheader("📋 Account Selection")

account_options = {f"{acc['Name']} ({acc['Id']})": acc['Id'] for acc in all_accounts}
selected_account_name = st.sidebar.selectbox(
    "Select Account:",
    options=list(account_options.keys()),
    index=0,
    help="Choose an AWS account to monitor"
)

selected_account_id = account_options[selected_account_name]
st.session_state.selected_account = {
    'id': selected_account_id,
    'name': selected_account_name.split(' (')[0],
    'full_name': selected_account_name
}

# Store selected account in session state for use in pages
st.session_state.accounts = all_accounts

# Display selected account info
st.sidebar.markdown("---")
st.sidebar.write("**Selected Account:**")
st.sidebar.info(f"🔹 {st.session_state.selected_account['full_name']}")

# Debug section
with st.sidebar.expander("🔧 Debug Info"):
    st.write("**Configuration:**")
    col1, col2 = st.columns(2)
    with col1:
        st.write(f"Profile: {AWSConfig.MANAGEMENT_ACCOUNT_PROFILE}")
        st.write(f"Role Name: {AWSConfig.READONLY_ROLE_NAME}")
    with col2:
        st.write(f"Max Workers: {AWSConfig.MAX_WORKERS}")
        st.write(f"Management Account: {account_id}")

    if st.button("🔍 Print Full Config"):
        AWSConfig.print_config()
        st.success("Config printed to console"

)

# Main content area
st.markdown("---")

col1, col2 = st.columns(2)

with col1:
    st.subheader("📊 Available Dashboards")
    st.markdown("""
    - **EC2 Details**: Monitor EC2 instances
    - **VPC Details**: View VPC configurations
    - **Backup Details**: Track backup status

    Select a dashboard from the navigation menu to get started.
    """)

with col2:
    st.subheader("🚀 Features")
    st.markdown("""
    - Multi-account support
    - Cross-region discovery
    - Real-time filtering
    - CSV export
    - Session persistence
    - Secure cross-account access
    """)

# Page Navigation
st.markdown("---")
st.subheader("📑 Pages")

st.markdown("""
Navigate to different dashboards using the sidebar:
- **EC2 Details**: EC2 instance management and monitoring
- **VPC Details**: Virtual Private Cloud configuration
- **Backup Details**: Backup and disaster recovery status
""")

# Footer
st.markdown("---")
st.caption("AWS Multi-Account Dashboard | Powered by Streamlit & Boto3 | 🔒 Secure Multi-Account Access")
