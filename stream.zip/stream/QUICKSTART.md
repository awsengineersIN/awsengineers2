# Quick Start Guide

## 1. Directory Setup (Already Done ✓)

```
aws-dashboard/
├── main.py
├── requirements.txt
├── README.md
├── MODULE_REFERENCE.md
├── .streamlit/
│   └── config.toml
├── modules/
│   ├── __init__.py
│   ├── config.py          # Credential management
│   └── iam.py             # Organizations, STS, Regions
└── pages/
    ├── __init__.py
    ├── EC2_details.py     # Implemented
    ├── VPC_details.py     # Template
    └── Backup_details.py  # Template
```

## 2. Install Dependencies

```bash
pip install -r requirements.txt
```

## 3. Run the Dashboard

### Option A: Using AWS CLI Profile (Recommended for Production)

```bash
# Configure credentials
aws configure --profile my-management-account

# Run dashboard
export AWS_PROFILE=my-management-account
streamlit run main.py
```

### Option B: Using Environment Variables (Recommended for Local Testing)

```bash
# Set your AWS credentials
export AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
export AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
export AWS_SESSION_TOKEN=AQoDYXdzEJr...  # Optional

# Run dashboard
streamlit run main.py
```

## 4. Access Dashboard

Open browser: http://localhost:8051

## Understanding MANAGEMENT_ACCOUNT_PROFILE

The `MANAGEMENT_ACCOUNT_PROFILE` is configured in `modules/config.py`:

```python
MANAGEMENT_ACCOUNT_PROFILE = os.getenv('AWS_PROFILE', 'default')
```

### When You Use Environment Variables for Credentials:

```bash
export AWS_ACCESS_KEY_ID=...
export AWS_SECRET_ACCESS_KEY=...
export AWS_SESSION_TOKEN=...  # Optional
```

→ **The profile name is ignored!** Environment variables take precedence.

**Why this works:**
- The `get_management_session()` function checks for environment variables first
- If `AWS_ACCESS_KEY_ID` is set, it uses environment variables directly
- The profile name only matters if environment variables are NOT set

### When You Use AWS CLI Profile:

```bash
export AWS_PROFILE=my-management-account
```

→ **The profile name is used** to look up credentials in `~/.aws/credentials`

### Priority Order (How Credentials Are Selected):

1. **Environment Variables** (highest priority)
   - `AWS_ACCESS_KEY_ID` + `AWS_SECRET_ACCESS_KEY`
   - Used for local testing with explicit credentials

2. **AWS CLI Profile** (medium priority)
   - Set via `AWS_PROFILE` environment variable
   - Looks up credentials from `~/.aws/credentials`

3. **Default AWS Profile** (low priority)
   - Uses `default` profile from `~/.aws/credentials`

4. **EC2 Instance Role** (lowest priority)
   - Used when running on EC2 instance

### Local Testing Flow:

```
┌─────────────────────────────────────┐
│ Local Machine Terminal              │
│ $ export AWS_ACCESS_KEY_ID=...      │
│ $ export AWS_SECRET_ACCESS_KEY=...  │
│ $ streamlit run main.py             │
└────────────────┬────────────────────┘
                 │
                 ▼
      ┌──────────────────────────┐
      │ modules/config.py        │
      │ get_management_session()│
      │                          │
      │ Check env vars? ✓        │
      │ Use env vars directly    │
      └────────────┬─────────────┘
                   │
                   ▼
      ┌──────────────────────────┐
      │ boto3.Session created    │
      │ with your credentials    │
      └────────────┬─────────────┘
                   │
                   ▼
      ┌──────────────────────────┐
      │ Access AWS APIs          │
      │ • Organizations          │
      │ • STS (AssumeRole)       │
      │ • EC2, RDS, etc.         │
      └──────────────────────────┘
```

## Adding New Dashboard Pages

### Step 1: Create new file in `pages/`

```bash
touch pages/Lambda_details.py
```

### Step 2: Use template structure

```python
import streamlit as st
from modules.config import AWSConfig
from modules.iam import AWSOrganizations, AWSRegions, AWSSession

st.set_page_config(page_title="Lambda Details", page_icon="⚡", layout="wide")
st.title("⚡ Lambda Dashboard")

# Get accounts from session state
all_accounts = st.session_state.get('accounts', [])

# Select account
account_id = st.sidebar.selectbox(
    "Select Account",
    [acc['Id'] for acc in all_accounts],
    format_func=lambda x: next((a['Name'] for a in all_accounts if a['Id'] == x), x)
)

# Fetch data
lambda_client = AWSSession.get_client_for_account(
    'lambda',
    account_id,
    AWSConfig.READONLY_ROLE_NAME,
    'us-east-1'
)

functions = lambda_client.list_functions()

# Display
st.dataframe(functions['Functions'])
```

### Step 3: Streamlit automatically adds it to sidebar!

Restart streamlit, and the new page appears in the sidebar navigation.

## Module Usage Quick Reference

### Get All Accounts

```python
from modules.iam import AWSOrganizations

accounts = AWSOrganizations.list_accounts()
# Returns: [{'Id': '123456789012', 'Name': 'Production', ...}, ...]
```

### Get All Regions

```python
from modules.iam import AWSRegions

regions = AWSRegions.list_all_regions()
# Returns: ['us-east-1', 'us-west-2', 'eu-west-1', ...]
```

### Assume Role and Get Client

```python
from modules.iam import AWSSession
from modules.config import AWSConfig

ec2_client = AWSSession.get_client_for_account(
    'ec2',
    account_id='123456789012',
    role_name=AWSConfig.READONLY_ROLE_NAME,
    region='us-east-1'
)

instances = ec2_client.describe_instances()
```

### Test Role Access

```python
from modules.iam import AWSAssumeRole

success, message = AWSAssumeRole.test_role_access('123456789012', 'ReadOnlyRole')
if success:
    print("✓ Can access account")
else:
    print(f"✗ {message}")
```

## Environment Variables Cheat Sheet

```bash
# AWS Credentials (for local testing)
export AWS_ACCESS_KEY_ID=your_access_key_id
export AWS_SECRET_ACCESS_KEY=your_secret_access_key
export AWS_SESSION_TOKEN=your_session_token        # Optional, for STS credentials

# AWS Configuration
export AWS_DEFAULT_REGION=us-east-1                 # Region for management account
export AWS_PROFILE=my-profile-name                  # Profile to use (if not using env vars above)

# Dashboard Configuration
export AWS_READONLY_ROLE=ReadOnlyRole              # Role name in member accounts
export MAX_WORKERS=5                               # Parallel threads for scanning
```

## Troubleshooting Checklist

- [ ] AWS credentials configured (profile or env vars)
- [ ] IAM roles created in member accounts
- [ ] Trust policies set up correctly
- [ ] Management account has Organizations permissions
- [ ] Role names match between config and member accounts
- [ ] Running `pip install -r requirements.txt`
- [ ] Restarted streamlit after adding new pages

## File Location Map

```
Need to change role name?
→ Modify: modules/config.py → READONLY_ROLE_NAME

Need to change credentials source?
→ Modify: modules/config.py → get_management_session()

Need to change parallel worker count?
→ Set env var: MAX_WORKERS=10

Need to disable caching?
→ Remove @st.cache_data decorators from modules/iam.py

Need to add new page?
→ Create: pages/ServiceName_details.py

Need to modify main dashboard?
→ Edit: main.py
```

## Next Steps

1. ✅ Install dependencies: `pip install -r requirements.txt`
2. ✅ Set AWS credentials (profile or env vars)
3. ✅ Create IAM roles in member accounts
4. ✅ Run: `streamlit run main.py`
5. 📖 Read: README.md for detailed documentation
6. 📚 Reference: MODULE_REFERENCE.md for API docs
7. 🚀 Extend: Add new pages following the template structure

## Support Resources

- **AWS Documentation**: https://docs.aws.amazon.com/
- **Streamlit Documentation**: https://docs.streamlit.io/
- **Boto3 Documentation**: https://boto3.amazonaws.com/
- **Module Reference**: See MODULE_REFERENCE.md in this directory

---

**Ready to get started?**

```bash
pip install -r requirements.txt
export AWS_ACCESS_KEY_ID=...
export AWS_SECRET_ACCESS_KEY=...
streamlit run main.py
```

Then open http://localhost:8051 in your browser!
