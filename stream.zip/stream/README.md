# AWS Multi-Account Dashboard - Modular Architecture

A modular, scalable Streamlit application for monitoring AWS resources across multiple accounts using centralized management account credentials.

## 📁 Directory Structure

```
aws-dashboard/
├── main.py                          # Main entry point
├── requirements.txt                 # Python dependencies
├── README.md                        # This file
│
├── .streamlit/
│   └── config.toml                  # Streamlit configuration
│
├── modules/                         # Reusable modules
│   ├── __init__.py
│   ├── config.py                    # Configuration & credential management
│   └── iam.py                       # IAM, Organizations, and role assumption
│
├── pages/                           # Dashboard pages
│   ├── __init__.py
│   ├── EC2_details.py              # EC2 instance dashboard
│   ├── VPC_details.py              # VPC configuration dashboard (template)
│   └── Backup_details.py           # Backup status dashboard (template)
│
└── docs/                            # Documentation (optional)
    ├── SETUP_GUIDE.md
    ├── ARCHITECTURE.md
    └── EXAMPLES.md
```

## 🚀 Quick Start

### 1. Clone/Setup the Project

```bash
cd aws-dashboard
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure AWS Credentials

#### Option A: Profile-Based Authentication (Recommended for Production)

```bash
# Configure AWS CLI
aws configure --profile my-management-account

# Run dashboard
export AWS_PROFILE=my-management-account
streamlit run main.py
```

#### Option B: Environment Variables (Recommended for Local Testing)

```bash
# Set credentials via environment variables
export AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
export AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
export AWS_SESSION_TOKEN=AQoDYXdzEJr...  # Optional, for STS credentials
export AWS_DEFAULT_REGION=us-east-1

# Run dashboard
streamlit run main.py
```

#### Option C: EC2 Instance Role (For Production Deployment)

```bash
# When running on an EC2 instance with proper IAM role
streamlit run main.py
```

### 4. Set Up IAM Roles in Member Accounts

In each member account, create an IAM role:

**Role Name**: `ReadOnlyRole` (or your preferred name)

**Trust Policy**:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::<MANAGEMENT_ACCOUNT_ID>:root"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

**Permissions**:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ec2:Describe*",
        "organizations:ListAccounts",
        "organizations:DescribeOrganization"
      ],
      "Resource": "*"
    }
  ]
}
```

### 5. Access the Dashboard

```bash
streamlit run main.py
```

Dashboard will be available at: `http://localhost:8051`

## 📦 Module Overview

### `modules/config.py`

Handles AWS credential configuration and management.

**Key Classes:**
- `AWSConfig`: Configuration management
  - `get_management_session()`: Get boto3 session (supports profiles and env vars)
  - `validate_credentials()`: Verify AWS credentials are working
  - `print_config()`: Print configuration for debugging

**Usage:**
```python
from modules.config import AWSConfig

# Get management account session
session = AWSConfig.get_management_session()

# Validate credentials
is_valid, message, account_id = AWSConfig.validate_credentials()

# Access configuration
profile = AWSConfig.MANAGEMENT_ACCOUNT_PROFILE
role_name = AWSConfig.READONLY_ROLE_NAME
```

### `modules/iam.py`

Handles IAM operations, Organizations, and cross-account role assumption.

**Key Classes:**
- `AWSOrganizations`: AWS Organizations operations
  - `list_accounts()`: Get all active accounts (cached for 5 min)
  - `get_account_id_by_name()`: Find account ID by name
  - `get_account_name_by_id()`: Find account name by ID

- `AWSRegions`: AWS region management
  - `list_all_regions()`: Get all enabled regions (cached for 1 hour)
  - `get_common_regions()`: Get commonly used regions (no API call)

- `AWSAssumeRole`: Cross-account role assumption
  - `assume_role()`: Assume role in target account
  - `test_role_access()`: Test if role can be assumed

- `AWSSession`: Session management utilities
  - `get_client_for_account()`: Get service client for target account
  - `get_client_for_management_account()`: Get client for management account

**Usage:**
```python
from modules.iam import (
    AWSOrganizations,
    AWSRegions,
    AWSSession
)

# List all accounts
accounts = AWSOrganizations.list_accounts()

# Get common regions
regions = AWSRegions.get_common_regions()

# Get EC2 client for another account
ec2_client = AWSSession.get_client_for_account(
    'ec2', '123456789012', 'ReadOnlyRole', 'us-east-1'
)

# Fetch EC2 instances
response = ec2_client.describe_instances()
```

## 🏗️ Application Flow

```
┌─────────────────────────────────────────┐
│         main.py (Entry Point)           │
│   - Credential validation               │
│   - Account discovery                   │
│   - Page navigation                     │
└──────────────┬──────────────────────────┘
               │
    ┌──────────┼──────────┐
    ▼          ▼          ▼
┌─────────┐ ┌──────────┐ ┌──────────────┐
│  EC2    │ │   VPC    │ │   Backup     │
│Details  │ │ Details  │ │   Details    │
└──┬──────┘ └────┬─────┘ └──────┬───────┘
   │             │              │
   └─────────┬───┴──────────────┘
             ▼
    ┌─────────────────────────┐
    │   modules/iam.py        │
    │ - Organizations API     │
    │ - Role Assumption       │
    │ - Region Discovery      │
    └────────┬────────────────┘
             │
    ┌────────▼────────────────┐
    │  modules/config.py      │
    │ - Credential Mgmt       │
    │ - Session Creation      │
    └─────────────────────────┘
             │
             ▼
    ┌─────────────────────────┐
    │   AWS APIs (Boto3)      │
    │ - Organizations         │
    │ - STS (AssumeRole)      │
    │ - EC2, RDS, etc.        │
    └─────────────────────────┘
```

## 🔐 Authentication Methods Explained

### Profile-Based (AWS CLI Profiles)

When `AWS_ACCESS_KEY_ID` is not set, credentials are fetched from AWS CLI profiles.

**Example:**
```bash
# ~/.aws/credentials
[my-management-account]
aws_access_key_id = AKIAIOSFODNN7EXAMPLE
aws_secret_access_key = wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
```

**Usage:**
```bash
export AWS_PROFILE=my-management-account
streamlit run main.py
```

### Environment Variables (For Local Testing)

When `AWS_ACCESS_KEY_ID` environment variable is set, it takes precedence.

**Example:**
```bash
export AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
export AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
export AWS_SESSION_TOKEN=AQoDYXdzEJr...  # Optional
streamlit run main.py
```

### MANAGEMENT_ACCOUNT_PROFILE Usage

In `modules/config.py`, `MANAGEMENT_ACCOUNT_PROFILE` is read from the environment variable:

```python
MANAGEMENT_ACCOUNT_PROFILE = os.getenv('AWS_PROFILE', 'default')
```

**When using environment variables for credentials:**
- The profile name is ignored
- Environment variables take precedence
- This allows local testing with explicit credentials

**When using profiles:**
- The profile name is used to look up credentials
- Environment variables override the profile

**Priority Order:**
1. Environment Variables (`AWS_ACCESS_KEY_ID` + `AWS_SECRET_ACCESS_KEY`)
2. AWS CLI Profile (`AWS_PROFILE`)
3. Default Profile (`~/.aws/credentials`)
4. EC2 Instance Role (if running on EC2)

## 📝 Adding New Dashboard Pages

### 1. Create a new page file

```bash
touch pages/RDS_details.py
```

### 2. Use the template structure

```python
import streamlit as st
from modules.config import AWSConfig
from modules.iam import AWSOrganizations, AWSRegions, AWSSession

st.set_page_config(page_title="RDS Details", page_icon="🗄️", layout="wide")
st.title("🗄️ RDS Dashboard")

# Get accounts from session state
all_accounts = st.session_state.get('accounts', [])

# Get RDS client for account
rds_client = AWSSession.get_client_for_account(
    'rds', account_id, role_name, region
)

# Fetch and display RDS data
# ...
```

### 3. The page will automatically appear in Streamlit's sidebar navigation

## 🔧 Configuration

Edit `modules/config.py` to change:

```python
# AWS CLI profile name (or use AWS_PROFILE env var)
MANAGEMENT_ACCOUNT_PROFILE = os.getenv('AWS_PROFILE', 'default')

# IAM role name in member accounts
READONLY_ROLE_NAME = os.getenv('AWS_READONLY_ROLE', 'ReadOnlyRole')

# Number of parallel threads for multi-region scanning
MAX_WORKERS = int(os.getenv('MAX_WORKERS', '5'))
```

## 🐛 Troubleshooting

### "Unable to locate credentials"

**Solution:**
```bash
# Option 1: Configure AWS CLI
aws configure

# Option 2: Set environment variables
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret

# Option 3: Use EC2 instance role
```

### "Error assuming role in account X"

**Solution:**
1. Verify role name matches in member accounts
2. Check trust relationship allows management account
3. Verify member account ID is correct
4. Test with: `aws sts assume-role --role-arn arn:aws:iam::ACCOUNT_ID:role/ReadOnlyRole --role-session-name test`

### "No accounts found"

**Solution:**
1. Ensure running from management account
2. Verify Organizations API permissions
3. Check organization has active accounts

### Pages not appearing

**Solution:**
1. Ensure page file is in `pages/` directory
2. Filename must end with `.py`
3. File must contain at least one `st.` command
4. Restart streamlit after adding new files

## 🚀 Performance Tips

1. **Cache Results**: Use `@st.cache_data` decorator for expensive operations
2. **Limit Regions**: Use "Common Regions" mode instead of scanning all regions
3. **Filter Accounts**: Select specific accounts instead of all accounts
4. **Parallel Processing**: Increase `MAX_WORKERS` for faster scanning (default: 5)
5. **Session Tokens**: Reuse existing sessions instead of creating new ones

## 📊 Example: Adding EC2 Cost Analysis

```python
# In pages/EC2_cost_analysis.py
from modules.iam import AWSSession
import pandas as pd

# Get CE client
ce_client = AWSSession.get_client_for_account(
    'ce', account_id, role_name, 'us-east-1'
)

# Query cost and usage
response = ce_client.get_cost_and_usage(
    TimePeriod={'Start': '2024-01-01', 'End': '2024-01-31'},
    Granularity='DAILY',
    Filter={'Dimensions': {'Key': 'SERVICE', 'Values': ['Amazon Elastic Compute Cloud']}},
    Metrics=['UnblendedCost']
)
```

## 🔒 Security Best Practices

1. **Least Privilege**: Use read-only roles with minimal permissions
2. **Temporary Credentials**: All cross-account access uses STS temporary credentials
3. **No Secrets in Code**: Never hardcode AWS credentials
4. **Environment Variables**: Use environment variables or AWS profiles
5. **Audit Logging**: Each session has unique ID for audit trails
6. **MFA**: Consider enabling MFA for management account
7. **Service Control Policies**: Restrict what roles can do in member accounts

## 📚 Additional Resources

- [AWS Boto3 Documentation](https://boto3.amazonaws.com/)
- [AWS Organizations Guide](https://docs.aws.amazon.com/organizations/)
- [Streamlit Documentation](https://docs.streamlit.io/)
- [AWS IAM Best Practices](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)
- [AWS Security Best Practices](https://aws.amazon.com/security/best-practices/)

## 🤝 Contributing

When adding new modules or pages:

1. Follow the existing code structure
2. Add docstrings to functions
3. Use type hints where applicable
4. Add error handling with meaningful messages
5. Cache expensive operations
6. Test with multiple accounts

## 📄 License

This project is provided as-is for educational and operational purposes.

---

**Questions or Issues?** Check the troubleshooting section or review the inline documentation in the module files.
