"""
IAM and AWS Organizations Management Module

Provides reusable functions for:
- AWS Organizations account listing
- Cross-account role assumption
- AWS region discovery
- Session management with caching
"""

import boto3
from botocore.exceptions import ClientError
import streamlit as st
import time
from modules.config import AWSConfig


class AWSOrganizations:
    """Handles AWS Organizations operations"""

    @staticmethod
    @st.cache_data(ttl=300)  # Cache for 5 minutes
    def list_accounts():
        """
        List all active accounts in the AWS Organization.

        Uses AWS Organizations API from management account.
        Results are cached for 5 minutes to reduce API calls.

        Returns:
            list: List of dicts with 'Id', 'Name', 'Email', 'Status' keys

        Example:
            accounts = AWSOrganizations.list_accounts()
            for account in accounts:
                print(f"{account['Name']} ({account['Id']})")
        """
        try:
            session = AWSConfig.get_management_session()
            org_client = session.client('organizations')

            accounts = []
            paginator = org_client.get_paginator('list_accounts')

            for page in paginator.paginate():
                for account in page['Accounts']:
                    if account['Status'] == 'ACTIVE':
                        accounts.append({
                            'Id': account['Id'],
                            'Name': account['Name'],
                            'Email': account['Email'],
                            'Status': account['Status']
                        })

            return sorted(accounts, key=lambda x: x['Name'])

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            raise Exception(f"Error listing accounts: {error_code}")

    @staticmethod
    def get_account_id_by_name(account_name, accounts=None):
        """
        Get account ID by account name.

        Args:
            account_name (str): Name of the account
            accounts (list): Optional pre-fetched accounts list

        Returns:
            str: Account ID or None if not found
        """
        if accounts is None:
            accounts = AWSOrganizations.list_accounts()

        for account in accounts:
            if account['Name'] == account_name:
                return account['Id']

        return None

    @staticmethod
    def get_account_name_by_id(account_id, accounts=None):
        """
        Get account name by account ID.

        Args:
            account_id (str): ID of the account
            accounts (list): Optional pre-fetched accounts list

        Returns:
            str: Account name or account_id if not found
        """
        if accounts is None:
            accounts = AWSOrganizations.list_accounts()

        for account in accounts:
            if account['Id'] == account_id:
                return account['Name']

        return account_id


class AWSRegions:
    """Handles AWS region operations"""

    @staticmethod
    @st.cache_data(ttl=3600)  # Cache for 1 hour
    def list_all_regions():
        """
        Get list of all enabled AWS regions.

        Results are cached for 1 hour.

        Returns:
            list: Sorted list of region names (e.g., ['us-east-1', 'us-west-2'])

        Example:
            regions = AWSRegions.list_all_regions()
            print(f"Found {len(regions)} regions")
        """
        try:
            session = AWSConfig.get_management_session()
            ec2_client = session.client('ec2', region_name='us-east-1')

            response = ec2_client.describe_regions(AllRegions=False)
            regions = sorted([region['RegionName'] for region in response['Regions']])

            return regions

        except ClientError as e:
            raise Exception(f"Error getting regions: {str(e)}")

    @staticmethod
    def get_common_regions():
        """
        Get a list of commonly used AWS regions.
        Useful for faster testing without scanning all regions.

        Returns:
            list: List of common region names
        """
        return [
            'us-east-1',
            'us-east-2',
            'us-west-1',
            'us-west-2',
            'eu-west-1',
            'eu-central-1',
            'ap-southeast-1',
            'ap-northeast-1',
            'ap-south-1'
        ]


class AWSAssumeRole:
    """Handles cross-account role assumption"""

    @staticmethod
    def assume_role(account_id, role_name, session_name=None):
        """
        Assume a role in a different AWS account using STS.

        Prerequisite: The role in the target account must trust the
        management account (principal in trust policy).

        Args:
            account_id (str): Target AWS account ID
            role_name (str): Name of the role to assume in target account
            session_name (str): Optional session name for audit trails

        Returns:
            boto3.Session: Authenticated session with assumed role credentials

        Raises:
            ClientError: If role assumption fails

        Example:
            # Assume role in another account
            assumed_session = AWSAssumeRole.assume_role('123456789012', 'ReadOnlyRole')
            ec2_client = assumed_session.client('ec2', region_name='us-east-1')
            instances = ec2_client.describe_instances()
        """
        try:
            if session_name is None:
                session_name = f"streamlit-{int(time.time())}"

            # Get management account session
            management_session = AWSConfig.get_management_session()
            sts_client = management_session.client('sts')

            # Construct role ARN
            role_arn = f"arn:aws:iam::{account_id}:role/{role_name}"

            # Assume the role
            response = sts_client.assume_role(
                RoleArn=role_arn,
                RoleSessionName=session_name,
                DurationSeconds=3600  # 1 hour
            )

            # Extract temporary credentials
            credentials = response['Credentials']

            # Create new session with assumed role credentials
            assumed_session = boto3.Session(
                aws_access_key_id=credentials['AccessKeyId'],
                aws_secret_access_key=credentials['SecretAccessKey'],
                aws_session_token=credentials['SessionToken'],
                region_name=AWSConfig.get_management_session().region_name
            )

            return assumed_session

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_msg = e.response.get('Error', {}).get('Message', '')
            raise Exception(
                f"Failed to assume role {role_name} in account {account_id}: "
                f"{error_code} - {error_msg}"
            )

    @staticmethod
    def test_role_access(account_id, role_name):
        """
        Test if a role in a target account can be assumed.
        Useful for validation before fetching resources.

        Args:
            account_id (str): Target account ID
            role_name (str): Role name to test

        Returns:
            tuple: (success: bool, message: str)
        """
        try:
            AWSAssumeRole.assume_role(account_id, role_name)
            return True, f"✓ Successfully assumed {role_name} in account {account_id}"
        except Exception as e:
            return False, f"✗ Failed to assume role: {str(e)}"


class AWSSession:
    """Utility class for session management"""

    @staticmethod
    def get_client_for_account(service, account_id, role_name, region):
        """
        Get an AWS service client for a specific account using role assumption.

        Args:
            service (str): AWS service name (e.g., 'ec2', 'rds', 's3')
            account_id (str): Target account ID
            role_name (str): Role name in target account
            region (str): AWS region

        Returns:
            boto3.client: Service client for the specified account

        Example:
            ec2_client = AWSSession.get_client_for_account('ec2', '123456789012', 'ReadOnlyRole', 'us-east-1')
            instances = ec2_client.describe_instances()
        """
        try:
            assumed_session = AWSAssumeRole.assume_role(account_id, role_name)
            client = assumed_session.client(service, region_name=region)
            return client
        except Exception as e:
            raise Exception(f"Error creating {service} client: {str(e)}")

    @staticmethod
    def get_client_for_management_account(service, region):
        """
        Get a service client for the management account (no role assumption needed).

        Args:
            service (str): AWS service name
            region (str): AWS region

        Returns:
            boto3.client: Service client for management account
        """
        session = AWSConfig.get_management_session()
        client = session.client(service, region_name=region)
        return client
