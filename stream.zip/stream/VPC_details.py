"""
VPC Details Dashboard Page

Displays VPC configurations across selected accounts and regions.

Run: streamlit run main.py
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from modules.config import AWSConfig
from modules.iam import AWSOrganizations, AWSRegions, AWSSession
from botocore.exceptions import ClientError

st.set_page_config(page_title="VPC Details", page_icon="🌐", layout="wide")

st.title("🌐 VPC Dashboard")

# Initialize session state
if 'vpc_data' not in st.session_state:
    st.session_state.vpc_data = None

# Sidebar Configuration
st.sidebar.header("⚙️ Configuration")

# Get all accounts
all_accounts = st.session_state.get('accounts', [])
if not all_accounts:
    st.error("No accounts found. Please return to main page.")
    st.stop()

# Account selection
st.sidebar.subheader("📋 Account Selection")
account_options = {f"{acc['Name']} ({acc['Id']})": acc['Id'] for acc in all_accounts}

default_account = st.session_state.get('selected_account', {}).get('full_name')
default_idx = 0
if default_account and default_account in account_options:
    default_idx = list(account_options.keys()).index(default_account)

selected_account_name = st.sidebar.selectbox(
    "Choose Account:",
    options=list(account_options.keys()),
    index=default_idx
)

selected_account_id = account_options[selected_account_name]

# Region selection
st.sidebar.subheader("🌍 Region Selection")
try:
    all_regions = AWSRegions.list_all_regions()
    selected_regions = st.sidebar.multiselect(
        "Select Regions:",
        options=all_regions,
        default=['us-east-1']
    )
except Exception as e:
    st.sidebar.error(f"Error loading regions: {str(e)}")
    st.stop()

# Fetch button
st.sidebar.markdown("---")
if st.sidebar.button("🔄 Fetch VPC Data", type="primary", use_container_width=True):
    if not selected_regions:
        st.warning("⚠️ Please select at least one region.")
    else:
        # TODO: Implement VPC data fetching
        st.info("VPC dashboard - Implementation in progress")
        st.info("To implement:")
        st.write("""
        1. Use AWSSession.get_client_for_account('ec2', account_id, role_name, region)
        2. Call ec2_client.describe_vpcs()
        3. Aggregate and display VPC data
        4. Show subnets, route tables, security groups
        """)

st.info("👈 Configure options in the sidebar and click 'Fetch VPC Data' to begin.")

st.markdown("---")
st.subheader("📝 Implementation Guide")
st.markdown("""
This is a template page for VPC details dashboard.

**Key functions to implement:**
- `get_vpcs_for_account()`: Fetch VPC configurations
- `get_subnets_for_vpc()`: Get subnets in each VPC
- `get_route_tables()`: Retrieve route table configurations
- `get_security_groups()`: List security groups

**Use the modules:**
```python
from modules.iam import AWSSession

# Get EC2 client for target account
ec2_client = AWSSession.get_client_for_account(
    'ec2', account_id, role_name, region
)

# Fetch VPCs
vpcs_response = ec2_client.describe_vpcs()
```
""")
