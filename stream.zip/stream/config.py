"""
Configuration Management Module

Handles AWS credentials configuration for both:
1. Profile-based authentication (AWS CLI profiles)
2. Environment variable-based authentication (for local testing)
"""

import os
import boto3
from botocore.exceptions import ClientError
import streamlit as st


class AWSConfig:
    """Manages AWS configuration and credential handling"""

    # Configuration variables
    MANAGEMENT_ACCOUNT_PROFILE = os.getenv('AWS_PROFILE', 'default')
    READONLY_ROLE_NAME = os.getenv('AWS_READONLY_ROLE', 'ReadOnlyRole')
    MAX_WORKERS = int(os.getenv('MAX_WORKERS', '5'))

    @staticmethod
    def get_management_session():
        """
        Create and return a boto3 session for the management account.

        Supports two authentication methods:
        1. Profile-based: Uses AWS_PROFILE env var or 'default' profile
        2. Environment variables: Uses AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN

        Returns:
            boto3.Session: Authenticated session for management account

        Raises:
            ClientError: If unable to authenticate

        Example:
            # Method 1: Using profile
            $ export AWS_PROFILE=my-management-account
            $ streamlit run main.py

            # Method 2: Using environment variables (for local testing)
            $ export AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
            $ export AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
            $ export AWS_SESSION_TOKEN=AQoDYXdzEJr...
            $ streamlit run main.py
        """
        try:
            # Check if environment variables are set
            access_key = os.getenv('AWS_ACCESS_KEY_ID')
            secret_key = os.getenv('AWS_SECRET_ACCESS_KEY')
            session_token = os.getenv('AWS_SESSION_TOKEN')
            region = os.getenv('AWS_DEFAULT_REGION', 'us-east-1')

            if access_key and secret_key:
                # Method 1: Use environment variables
                session = boto3.Session(
                    aws_access_key_id=access_key,
                    aws_secret_access_key=secret_key,
                    aws_session_token=session_token,  # Optional, can be None
                    region_name=region
                )
                return session
            else:
                # Method 2: Use AWS profile
                session = boto3.Session(
                    profile_name=AWSConfig.MANAGEMENT_ACCOUNT_PROFILE,
                    region_name=region
                )
                return session

        except Exception as e:
            raise ClientError(
                {'Error': {'Code': 'InvalidConfiguration', 'Message': str(e)}},
                'GetSession'
            )

    @staticmethod
    def validate_credentials():
        """
        Validate that AWS credentials are properly configured.

        Returns:
            tuple: (is_valid, message, account_id)
        """
        try:
            session = AWSConfig.get_management_session()
            sts_client = session.client('sts')

            # Try to get caller identity
            identity = sts_client.get_caller_identity()

            account_id = identity['Account']
            arn = identity['Arn']

            return True, f"✓ Credentials valid (Account: {account_id})", account_id

        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_msg = e.response.get('Error', {}).get('Message', str(e))
            return False, f"✗ Credential error: {error_code} - {error_msg}", None
        except Exception as e:
            return False, f"✗ Configuration error: {str(e)}", None

    @staticmethod
    def print_config():
        """Print current configuration for debugging"""
        print("\n" + "="*60)
        print("AWS Configuration Summary")
        print("="*60)

        # Determine authentication method
        if os.getenv('AWS_ACCESS_KEY_ID'):
            print(f"Authentication Method: Environment Variables")
            print(f"  AWS_ACCESS_KEY_ID: {'*' * 10}***")
            print(f"  AWS_SECRET_ACCESS_KEY: {'*' * 10}***")
            if os.getenv('AWS_SESSION_TOKEN'):
                print(f"  AWS_SESSION_TOKEN: {'*' * 10}*** (STS Credentials)")
        else:
            print(f"Authentication Method: AWS Profile")
            print(f"  Profile Name: {AWSConfig.MANAGEMENT_ACCOUNT_PROFILE}")

        print(f"\nRole Configuration:")
        print(f"  ReadOnly Role Name: {AWSConfig.READONLY_ROLE_NAME}")
        print(f"  Max Workers: {AWSConfig.MAX_WORKERS}")

        print(f"\nRegion: {os.getenv('AWS_DEFAULT_REGION', 'us-east-1')}")
        print("="*60 + "\n")


# Streamlit cached config validation
@st.cache_data(ttl=3600)
def validate_aws_config():
    """Validate AWS configuration once per session (cached for 1 hour)"""
    is_valid, message, account_id = AWSConfig.validate_credentials()
    return is_valid, message, account_id
