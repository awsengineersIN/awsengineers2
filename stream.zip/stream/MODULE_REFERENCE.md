# AWS Dashboard Modules - Developer Reference

This guide explains how to use the reusable modules in your dashboard pages.

## Table of Contents

1. [modules/config.py](#modulesconfigpy)
2. [modules/iam.py](#modulesiampy)
3. [Common Patterns](#common-patterns)
4. [Examples](#examples)

---

## modules/config.py

### Purpose
Handles AWS credential configuration and management for both profile-based and environment variable authentication.

### Classes

#### AWSConfig

Static class for configuration management.

**Attributes:**
```python
MANAGEMENT_ACCOUNT_PROFILE = os.getenv('AWS_PROFILE', 'default')
READONLY_ROLE_NAME = os.getenv('AWS_READONLY_ROLE', 'ReadOnlyRole')
MAX_WORKERS = int(os.getenv('MAX_WORKERS', '5'))
```

**Methods:**

##### `get_management_session()`

Get a boto3 session for the management account.

```python
from modules.config import AWSConfig

session = AWSConfig.get_management_session()

# Works with:
# 1. Environment variables: AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY
# 2. AWS CLI profiles: AWS_PROFILE environment variable
# 3. EC2 instance role: When running on EC2
```

**Priority Order:**
1. Environment variables (`AWS_ACCESS_KEY_ID` + `AWS_SECRET_ACCESS_KEY`)
2. AWS CLI Profile (`AWS_PROFILE`)
3. Default profile (`~/.aws/credentials`)
4. EC2 Instance Role

**Returns:** `boto3.Session`

**Raises:** `ClientError` if unable to authenticate

---

##### `validate_credentials()`

Verify AWS credentials are working.

```python
from modules.config import AWSConfig

is_valid, message, account_id = AWSConfig.validate_credentials()

if is_valid:
    print(f"✓ Authenticated to account {account_id}")
else:
    print(f"✗ Error: {message}")
```

**Returns:** Tuple of `(bool, str, str)` - (is_valid, message, account_id)

---

##### `print_config()`

Print configuration to console for debugging.

```python
AWSConfig.print_config()

# Output:
# ============================================================
# AWS Configuration Summary
# ============================================================
# Authentication Method: Environment Variables
#   AWS_ACCESS_KEY_ID: **********
#   AWS_SECRET_ACCESS_KEY: **********
# 
# Role Configuration:
#   ReadOnly Role Name: ReadOnlyRole
#   Max Workers: 5
# ============================================================
```

---

## modules/iam.py

### Purpose
Handles AWS Organizations, region management, and cross-account role assumption.

### Classes

#### AWSOrganizations

Manages AWS Organizations operations.

**Methods:**

##### `list_accounts()`

Get all active accounts in AWS Organization.

```python
from modules.iam import AWSOrganizations

# Returns cached results (5 minute TTL)
accounts = AWSOrganizations.list_accounts()

for account in accounts:
    print(f"{account['Name']} ({account['Id']})")
    # Output: Production (123456789012)
```

**Returns:** List of dicts with keys: `Id`, `Name`, `Email`, `Status`

**Caching:** Results cached for 5 minutes using `@st.cache_data`

---

##### `get_account_id_by_name(account_name, accounts=None)`

Find account ID by account name.

```python
from modules.iam import AWSOrganizations

# Method 1: Without passing accounts (will fetch)
account_id = AWSOrganizations.get_account_id_by_name('Production')

# Method 2: With pre-fetched accounts (faster)
accounts = AWSOrganizations.list_accounts()
account_id = AWSOrganizations.get_account_id_by_name('Production', accounts)
```

**Parameters:**
- `account_name` (str): Name of the account
- `accounts` (list, optional): Pre-fetched accounts list

**Returns:** Account ID (str) or None if not found

---

##### `get_account_name_by_id(account_id, accounts=None)`

Find account name by account ID.

```python
from modules.iam import AWSOrganizations

# Method 1: Without passing accounts
name = AWSOrganizations.get_account_name_by_id('123456789012')

# Method 2: With pre-fetched accounts
accounts = AWSOrganizations.list_accounts()
name = AWSOrganizations.get_account_name_by_id('123456789012', accounts)
```

**Parameters:**
- `account_id` (str): AWS account ID
- `accounts` (list, optional): Pre-fetched accounts list

**Returns:** Account name (str) or account_id if not found

---

#### AWSRegions

Manages AWS region discovery.

**Methods:**

##### `list_all_regions()`

Get all enabled AWS regions.

```python
from modules.iam import AWSRegions

# Returns cached results (1 hour TTL)
regions = AWSRegions.list_all_regions()

print(f"Found {len(regions)} regions")
# Output: Found 30 regions

for region in regions:
    print(region)
    # us-east-1, us-east-2, us-west-1, ...
```

**Returns:** Sorted list of region names

**Caching:** Results cached for 1 hour using `@st.cache_data`

---

##### `get_common_regions()`

Get commonly used AWS regions without API call.

```python
from modules.iam import AWSRegions

# No API call, instant result
regions = AWSRegions.get_common_regions()

print(regions)
# ['us-east-1', 'us-east-2', 'us-west-1', 'us-west-2', 'eu-west-1', ...]
```

**Returns:** Hardcoded list of ~9 common regions

**Use Case:** For faster testing without scanning all 30+ regions

---

#### AWSAssumeRole

Handles cross-account role assumption via STS.

**Methods:**

##### `assume_role(account_id, role_name, session_name=None)`

Assume a role in a different AWS account.

```python
from modules.iam import AWSAssumeRole

# Assume ReadOnlyRole in account 123456789012
assumed_session = AWSAssumeRole.assume_role(
    '123456789012',
    'ReadOnlyRole',
    session_name='my-custom-session'  # Optional
)

# Use the session
ec2_client = assumed_session.client('ec2', region_name='us-east-1')
instances = ec2_client.describe_instances()
```

**Parameters:**
- `account_id` (str): Target AWS account ID
- `role_name` (str): Role name in target account
- `session_name` (str, optional): Session identifier for audit trails

**Returns:** `boto3.Session` with assumed role credentials

**Raises:** Exception if role assumption fails

**Duration:** 1 hour (3600 seconds)

**Prerequisite:** The target role must have a trust policy allowing the management account

---

##### `test_role_access(account_id, role_name)`

Test if a role can be assumed without using it.

```python
from modules.iam import AWSAssumeRole

success, message = AWSAssumeRole.test_role_access('123456789012', 'ReadOnlyRole')

if success:
    print(message)
    # ✓ Successfully assumed ReadOnlyRole in account 123456789012
else:
    print(f"Failed: {message}")
    # ✗ Failed to assume role: ...
```

**Returns:** Tuple of (success: bool, message: str)

---

#### AWSSession

Utility class for session management.

**Methods:**

##### `get_client_for_account(service, account_id, role_name, region)`

Get a service client for a target account using role assumption.

```python
from modules.iam import AWSSession

# Get EC2 client for another account
ec2_client = AWSSession.get_client_for_account(
    'ec2',
    '123456789012',
    'ReadOnlyRole',
    'us-east-1'
)

# Use the client
response = ec2_client.describe_instances()
```

**Parameters:**
- `service` (str): AWS service name ('ec2', 'rds', 's3', 'backup', etc.)
- `account_id` (str): Target account ID
- `role_name` (str): Role name in target account
- `region` (str): AWS region

**Returns:** Boto3 service client

**Raises:** Exception if unable to create client

**Example Services:**
- `ec2`: EC2 instances
- `rds`: RDS databases
- `s3`: S3 buckets
- `backup`: AWS Backup
- `organizations`: AWS Organizations
- `ce`: Cost Explorer

---

##### `get_client_for_management_account(service, region)`

Get a service client for the management account (no role assumption).

```python
from modules.iam import AWSSession

# Get Organizations client for management account
org_client = AWSSession.get_client_for_management_account(
    'organizations',
    'us-east-1'
)

accounts = org_client.list_accounts()
```

**Parameters:**
- `service` (str): AWS service name
- `region` (str): AWS region

**Returns:** Boto3 service client

---

## Common Patterns

### Pattern 1: Fetching Data from Multiple Accounts

```python
from modules.iam import AWSOrganizations, AWSSession

accounts = AWSOrganizations.list_accounts()

all_instances = []

for account in accounts:
    account_id = account['Id']
    account_name = account['Name']

    try:
        ec2_client = AWSSession.get_client_for_account(
            'ec2', account_id, 'ReadOnlyRole', 'us-east-1'
        )

        response = ec2_client.describe_instances()

        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                all_instances.append({
                    'Account': account_name,
                    'InstanceId': instance['InstanceId'],
                    'State': instance['State']['Name']
                })
    except Exception as e:
        print(f"Error in account {account_name}: {e}")
```

---

### Pattern 2: Parallel Multi-Region Scanning

```python
from concurrent.futures import ThreadPoolExecutor, as_completed
from modules.iam import AWSRegions, AWSSession
from modules.config import AWSConfig

def get_data_in_region(service, account_id, role_name, region, api_call):
    """Generic function to get data from a region"""
    try:
        client = AWSSession.get_client_for_account(
            service, account_id, role_name, region
        )
        return api_call(client, region)
    except:
        return None

# Usage
regions = AWSRegions.list_all_regions()

with ThreadPoolExecutor(max_workers=AWSConfig.MAX_WORKERS) as executor:
    futures = {
        executor.submit(
            get_data_in_region,
            'ec2',
            '123456789012',
            'ReadOnlyRole',
            region,
            lambda client, r: client.describe_instances()
        ): region
        for region in regions
    }

    all_data = []
    for future in as_completed(futures):
        result = future.result()
        if result:
            all_data.append(result)
```

---

### Pattern 3: Caching Expensive Operations

```python
import streamlit as st
from modules.iam import AWSSession

@st.cache_data(ttl=300)  # Cache for 5 minutes
def get_account_ec2_count(account_id, role_name):
    """Get count of EC2 instances (cached)"""
    ec2_client = AWSSession.get_client_for_account(
        'ec2', account_id, role_name, 'us-east-1'
    )

    response = ec2_client.describe_instances()

    total = sum(
        len(r['Instances'])
        for r in response['Reservations']
    )

    return total

# Call will be cached
count = get_account_ec2_count('123456789012', 'ReadOnlyRole')
```

---

### Pattern 4: Error Handling

```python
from modules.iam import AWSAssumeRole, AWSSession

account_id = '123456789012'
role_name = 'ReadOnlyRole'

# Test access first
success, message = AWSAssumeRole.test_role_access(account_id, role_name)

if not success:
    print(f"Cannot access account: {message}")
else:
    try:
        client = AWSSession.get_client_for_account(
            'ec2', account_id, role_name, 'us-east-1'
        )
        # Use client
    except Exception as e:
        print(f"Error: {e}")
```

---

## Examples

### Example 1: EC2 Instance Counter

```python
import streamlit as st
from modules.iam import AWSOrganizations, AWSSession

accounts = AWSOrganizations.list_accounts()

st.title("EC2 Instance Count by Account")

for account in accounts:
    try:
        ec2_client = AWSSession.get_client_for_account(
            'ec2',
            account['Id'],
            'ReadOnlyRole',
            'us-east-1'
        )

        response = ec2_client.describe_instances()
        count = sum(len(r['Instances']) for r in response['Reservations'])

        st.metric(account['Name'], count)
    except Exception as e:
        st.error(f"Error in {account['Name']}: {e}")
```

---

### Example 2: Multi-Region RDS Listing

```python
from modules.iam import AWSRegions, AWSSession
import pandas as pd

regions = AWSRegions.get_common_regions()
all_instances = []

for region in regions:
    try:
        rds_client = AWSSession.get_client_for_account(
            'rds',
            '123456789012',
            'ReadOnlyRole',
            region
        )

        response = rds_client.describe_db_instances()

        for db in response['DBInstances']:
            all_instances.append({
                'Region': region,
                'Identifier': db['DBInstanceIdentifier'],
                'Engine': db['Engine'],
                'Status': db['DBInstanceStatus']
            })
    except:
        pass

df = pd.DataFrame(all_instances)
st.dataframe(df)
```

---

### Example 3: Organizations Account Selector

```python
import streamlit as st
from modules.iam import AWSOrganizations

accounts = AWSOrganizations.list_accounts()

account_names = [acc['Name'] for acc in accounts]

selected_name = st.selectbox("Select Account", account_names)

selected_account = next(
    acc for acc in accounts if acc['Name'] == selected_name
)

st.write(f"Account ID: {selected_account['Id']}")
st.write(f"Email: {selected_account['Email']}")
```

---

## Tips & Best Practices

1. **Cache Account Lists**: Accounts rarely change; cache them for 5 minutes
2. **Pre-fetch Accounts**: Pass fetched accounts to helper functions to avoid re-fetching
3. **Handle Errors Gracefully**: Wrap assume_role calls in try-except
4. **Use Common Regions**: For testing, use get_common_regions() instead of list_all_regions()
5. **Parallel Processing**: Use ThreadPoolExecutor for multi-region operations
6. **Log Errors**: Print/log errors but don't stop the entire application
7. **Session Names**: Use descriptive session names for audit trails
8. **Resource Cleanup**: Boto3 clients don't need explicit cleanup

---

For more examples, check the `pages/` directory!
