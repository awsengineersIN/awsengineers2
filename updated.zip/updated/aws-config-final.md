# Complete pages/AWS_Config.py

Save this as: `pages/AWS_Config.py`

```python
"""
AWS Config Dashboard Page

Displays AWS Config compliance status across selected accounts and regions.
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

from modules.aws_helper import AWSConfig, AWSOrganizations, AWSSession
from modules.sidebar_common import render_sidebar
from botocore.exceptions import ClientError

# Page configuration
st.set_page_config(page_title="AWS Config", page_icon="⚙️", layout="wide")

# Initialize session state
if 'config_data' not in st.session_state:
    st.session_state.config_data = None
if 'config_last_refresh' not in st.session_state:
    st.session_state.config_last_refresh = None

# Header
st.title("⚙️ AWS Config Dashboard")

# Get all accounts
all_accounts = st.session_state.get('accounts', [])
if not all_accounts:
    st.error("No accounts found. Please return to main page.")
    st.stop()

# ============================================================================
# SIDEBAR CONFIGURATION
# ============================================================================

selected_account_ids, selected_regions = render_sidebar(page_key_prefix="config_")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_config_rules(region, account_id, account_name, role_name):
    """Get AWS Config rules compliance for a specific region"""
    rules_data = []
    try:
        config_client = AWSSession.get_client_for_account('config', account_id, role_name, region)
        
        # Get all config rules
        paginator = config_client.get_paginator('describe_config_rules')
        
        for page in paginator.paginate():
            for rule in page['ConfigRules']:
                rule_name = rule['ConfigRuleName']
                
                # Get compliance status
                try:
                    compliance = config_client.describe_compliance_by_config_rule(
                        ConfigRuleNames=[rule_name]
                    )
                    
                    if compliance['ComplianceByConfigRules']:
                        compliance_info = compliance['ComplianceByConfigRules'][0]['Compliance']
                        compliance_type = compliance_info.get('ComplianceType', 'INSUFFICIENT_DATA')
                    else:
                        compliance_type = 'INSUFFICIENT_DATA'
                        
                except ClientError:
                    compliance_type = 'INSUFFICIENT_DATA'
                
                rule_data = {
                    'Account ID': account_id,
                    'Account Name': account_name,
                    'Region': region,
                    'Rule Name': rule_name,
                    'Compliance': compliance_type,
                    'Source': rule.get('Source', {}).get('Owner', 'N/A'),
                    'Description': rule.get('Description', 'N/A')[:200]
                }
                rules_data.append(rule_data)
                
    except ClientError:
        pass
    except Exception:
        pass
    
    return rules_data

def fetch_config_data(selected_account_ids, all_accounts, role_name, regions):
    """Fetch AWS Config data for all selected accounts"""
    all_rules = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    total_accounts = len(selected_account_ids)
    
    for idx, account_id in enumerate(selected_account_ids):
        account_name = AWSOrganizations.get_account_name_by_id(account_id, all_accounts)
        status_text.text(f"📡 Scanning: {account_name} ({idx + 1}/{total_accounts})")
        
        with ThreadPoolExecutor(max_workers=AWSConfig.MAX_WORKERS) as executor:
            futures = {
                executor.submit(get_config_rules, region, account_id, account_name, role_name): region
                for region in regions
            }
            
            for future in as_completed(futures):
                try:
                    rules = future.result()
                    all_rules.extend(rules)
                except Exception:
                    pass
        
        progress_bar.progress((idx + 1) / total_accounts)
    
    progress_bar.empty()
    status_text.empty()
    
    return all_rules

# ============================================================================
# BUTTON HANDLERS
# ============================================================================

# Check if fetch button was clicked
if st.session_state.get('config_fetch_clicked', False):
    if not selected_account_ids:
        st.warning("⚠️ Please select at least one account.")
        st.session_state.config_fetch_clicked = False
    elif not selected_regions:
        st.warning("⚠️ Please select at least one region.")
        st.session_state.config_fetch_clicked = False
    else:
        start_time = time.time()
        
        with st.spinner(f"🔍 Scanning AWS Config in {len(selected_account_ids)} account(s)..."):
            config_data = fetch_config_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, selected_regions)
            st.session_state.config_data = config_data
            st.session_state.config_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        elapsed_time = time.time() - start_time
        st.success(f"✅ Successfully fetched {len(config_data)} config rules in {elapsed_time:.2f} seconds")
        st.session_state.config_fetch_clicked = False

# ============================================================================
# DISPLAY RESULTS
# ============================================================================

if st.session_state.config_data is not None:
    df = pd.DataFrame(st.session_state.config_data)
    
    # Refresh button on main page
    col_title, col_refresh = st.columns([5, 1])
    with col_title:
        if st.session_state.config_last_refresh:
            st.caption(f"Last refreshed: {st.session_state.config_last_refresh}")
    with col_refresh:
        if st.button("🔁 Refresh", type="secondary", use_container_width=True, key="config_refresh_btn"):
            if not selected_account_ids:
                st.warning("⚠️ Please select at least one account.")
            elif not selected_regions:
                st.warning("⚠️ Please select at least one region.")
            else:
                start_time = time.time()
                
                with st.spinner(f"🔍 Refreshing data..."):
                    config_data = fetch_config_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, selected_regions)
                    st.session_state.config_data = config_data
                    st.session_state.config_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                
                elapsed_time = time.time() - start_time
                st.success(f"✅ Data refreshed ({len(config_data)} rules in {elapsed_time:.2f} seconds)")
                st.rerun()
    
    if df.empty:
        st.info("ℹ️ No AWS Config rules found in the selected accounts and regions.")
    else:
        # Summary metrics
        st.subheader("📊 Summary Metrics")
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("Total Rules", len(df))
        
        with col2:
            compliant_count = len(df[df['Compliance'] == 'COMPLIANT'])
            st.metric("✅ Compliant", compliant_count)
        
        with col3:
            non_compliant_count = len(df[df['Compliance'] == 'NON_COMPLIANT'])
            st.metric("❌ Non-Compliant", non_compliant_count)
        
        with col4:
            insufficient_count = len(df[df['Compliance'] == 'INSUFFICIENT_DATA'])
            st.metric("⚠️ Insufficient Data", insufficient_count)
        
        with col5:
            unique_accounts = df['Account ID'].nunique()
            st.metric("Accounts", unique_accounts)
        
        st.markdown("---")
        
        # Filters
        st.subheader("🔍 Filters")
        
        filter_col1, filter_col2, filter_col3 = st.columns(3)
        
        with filter_col1:
            compliance_filter = st.multiselect(
                "Compliance Status:",
                options=sorted(df['Compliance'].unique().tolist()),
                default=sorted(df['Compliance'].unique().tolist())
            )
        
        with filter_col2:
            region_filter = st.multiselect(
                "Region:",
                options=sorted(df['Region'].unique().tolist()),
                default=sorted(df['Region'].unique().tolist())
            )
        
        with filter_col3:
            account_filter = st.multiselect(
                "Account:",
                options=sorted(df['Account Name'].unique().tolist()),
                default=sorted(df['Account Name'].unique().tolist())
            )
        
        # Apply filters
        filtered_df = df[
            (df['Compliance'].isin(compliance_filter)) &
            (df['Region'].isin(region_filter)) &
            (df['Account Name'].isin(account_filter))
        ]
        
        st.markdown("---")
        
        # Display data
        st.subheader(f"📋 Config Rules ({len(filtered_df)} rules)")
        
        # Column selector
        available_columns = filtered_df.columns.tolist()
        default_columns = [
            'Account Name', 'Region', 'Rule Name', 'Compliance', 'Source'
        ]
        
        selected_columns = st.multiselect(
            "Select columns to display:",
            options=available_columns,
            default=[col for col in default_columns if col in available_columns]
        )
        
        if selected_columns:
            display_df = filtered_df[selected_columns]
        else:
            display_df = filtered_df
        
        st.dataframe(display_df, use_container_width=True, height=500, hide_index=True)
        
        # Download button
        st.markdown("---")
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Config Rules (CSV)",
            data=csv,
            file_name=f"aws_config_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
        
        # Statistics
        with st.expander("📈 Additional Statistics"):
            stat_col1, stat_col2 = st.columns(2)
            
            with stat_col1:
                st.write("**Rules by Compliance Status:**")
                compliance_counts = filtered_df['Compliance'].value_counts()
                st.dataframe(compliance_counts, use_container_width=True)
            
            with stat_col2:
                st.write("**Rules by Source:**")
                source_counts = filtered_df['Source'].value_counts()
                st.dataframe(source_counts, use_container_width=True)

else:
    st.info("👈 Configure options in the sidebar and click 'Fetch Data' to begin.")
```
