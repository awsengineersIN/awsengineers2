# Complete modules/aws_helper.py (Merged config.py + iam.py)

Save this as: `modules/aws_helper.py`

```python
"""
Unified AWS Helper Module

Handles all AWS operations:
- Authentication via AssumeRole ONLY
- Organizations (account listing)
- Session management
- Region utilities

Authentication: AssumeRole to READONLY_ROLE_NAME everywhere (local and AWS)
"""

import os
import boto3
from botocore.exceptions import ClientError

# ============================================================================
# CONFIGURATION
# ============================================================================

class AWSConfig:
    """Configuration for AWS operations"""
    
    # IAM role name to assume (same role everywhere)
    READONLY_ROLE_NAME = os.environ.get('READONLY_ROLE_NAME', 'ReadOnlyRole')
    
    # Management account ID (required)
    MANAGEMENT_ACCOUNT_ID = os.environ.get('MANAGEMENT_ACCOUNT_ID')
    
    # Performance settings
    MAX_WORKERS = int(os.environ.get('MAX_WORKERS', '10'))


# ============================================================================
# SESSION MANAGEMENT
# ============================================================================

class AWSSession:
    """Handles AWS session creation with AssumeRole"""
    
    @staticmethod
    def get_base_session():
        """
        Get base boto3 session (uses instance profile or environment credentials).
        """
        return boto3.Session()
    
    @staticmethod
    def assume_role(account_id, role_name, session_name='aws-dashboard'):
        """
        Assume role in target account.
        
        Args:
            account_id: Target AWS account ID
            role_name: IAM role name to assume
            session_name: Session name for CloudTrail
            
        Returns:
            boto3.Session: Session with assumed role credentials
        """
        base_session = AWSSession.get_base_session()
        sts_client = base_session.client('sts')
        
        role_arn = f"arn:aws:iam::{account_id}:role/{role_name}"
        
        try:
            response = sts_client.assume_role(
                RoleArn=role_arn,
                RoleSessionName=session_name
            )
            
            credentials = response['Credentials']
            
            return boto3.Session(
                aws_access_key_id=credentials['AccessKeyId'],
                aws_secret_access_key=credentials['SecretAccessKey'],
                aws_session_token=credentials['SessionToken']
            )
        except ClientError as e:
            raise Exception(f"Failed to assume role {role_arn}: {str(e)}")
    
    @staticmethod
    def get_client_for_account(service, account_id, role_name, region='us-east-1'):
        """
        Get boto3 client for specific account by assuming role.
        
        Args:
            service: AWS service name (e.g., 'ec2', 'iam')
            account_id: Target account ID
            role_name: IAM role to assume
            region: AWS region
            
        Returns:
            boto3.client: Client for the service
        """
        session = AWSSession.assume_role(account_id, role_name)
        return session.client(service, region_name=region)


# ============================================================================
# ORGANIZATIONS
# ============================================================================

class AWSOrganizations:
    """AWS Organizations operations"""
    
    @staticmethod
    def list_accounts():
        """
        List all active accounts in the organization.
        
        Returns:
            list: List of account dictionaries with Id, Name, Email, Status
        """
        session = AWSSession.get_base_session()
        org_client = session.client('organizations')
        
        accounts = []
        paginator = org_client.get_paginator('list_accounts')
        
        for page in paginator.paginate():
            for account in page['Accounts']:
                if account['Status'] == 'ACTIVE':
                    accounts.append({
                        'Id': account['Id'],
                        'Name': account['Name'],
                        'Email': account['Email'],
                        'Status': account['Status']
                    })
        
        return accounts
    
    @staticmethod
    def get_account_name_by_id(account_id, accounts_list):
        """
        Get account name from account ID.
        
        Args:
            account_id: AWS account ID
            accounts_list: List of account dictionaries
            
        Returns:
            str: Account name or account ID if not found
        """
        for account in accounts_list:
            if account['Id'] == account_id:
                return account['Name']
        return account_id


# ============================================================================
# REGIONS
# ============================================================================

class AWSRegions:
    """AWS region utilities"""
    
    @staticmethod
    def list_all_regions():
        """
        List all AWS regions.
        
        Returns:
            list: List of region names
        """
        session = AWSSession.get_base_session()
        ec2_client = session.client('ec2', region_name='us-east-1')
        
        response = ec2_client.describe_regions(AllRegions=False)
        regions = [region['RegionName'] for region in response['Regions']]
        
        return sorted(regions)
    
    @staticmethod
    def get_common_regions():
        """
        Get commonly used AWS regions.
        
        Returns:
            list: List of common region names
        """
        return [
            'us-east-1',
            'us-east-2',
            'us-west-1',
            'us-west-2',
            'eu-west-1',
            'eu-central-1',
            'ap-southeast-1',
            'ap-northeast-1',
        ]


# ============================================================================
# VALIDATION
# ============================================================================

def validate_aws_config():
    """
    Validate AWS configuration and credentials.
    
    Returns:
        tuple: (is_valid: bool, message: str, account_id: str)
    """
    try:
        session = AWSSession.get_base_session()
        sts_client = session.client('sts')
        
        identity = sts_client.get_caller_identity()
        account_id = identity['Account']
        
        message = f"✅ Authenticated (Account: {account_id})"
        
        return True, message, account_id
        
    except ClientError as e:
        return False, f"❌ AWS authentication failed: {str(e)}", None
    except Exception as e:
        return False, f"❌ Configuration error: {str(e)}", None
```
