# Complete pages/Security_Hub.py

Save this as: `pages/Security_Hub.py`

```python
"""
Security Hub Dashboard Page

Displays Security Hub findings across selected accounts and regions.
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

from modules.aws_helper import AWSConfig, AWSOrganizations, AWSSession
from modules.sidebar_common import render_sidebar
from botocore.exceptions import ClientError

# Page configuration
st.set_page_config(page_title="Security Hub", page_icon="🔒", layout="wide")

# Initialize session state
if 'security_hub_data' not in st.session_state:
    st.session_state.security_hub_data = None
if 'security_hub_last_refresh' not in st.session_state:
    st.session_state.security_hub_last_refresh = None

# Header
st.title("🔒 Security Hub Dashboard")

# Get all accounts
all_accounts = st.session_state.get('accounts', [])
if not all_accounts:
    st.error("No accounts found. Please return to main page.")
    st.stop()

# ============================================================================
# SIDEBAR CONFIGURATION
# ============================================================================

selected_account_ids, selected_regions = render_sidebar(page_key_prefix="security_hub_")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_security_hub_findings(region, account_id, account_name, role_name):
    """Get Security Hub findings for a specific region"""
    findings = []
    try:
        sh_client = AWSSession.get_client_for_account('securityhub', account_id, role_name, region)
        
        # Check if Security Hub is enabled
        try:
            sh_client.describe_hub()
        except ClientError:
            return findings  # Security Hub not enabled
        
        # Get active findings
        paginator = sh_client.get_paginator('get_findings')
        
        for page in paginator.paginate(
            Filters={
                'RecordState': [{'Value': 'ACTIVE', 'Comparison': 'EQUALS'}],
                'WorkflowStatus': [{'Value': 'NEW', 'Comparison': 'EQUALS'}]
            }
        ):
            for finding in page['Findings']:
                finding_data = {
                    'Account ID': account_id,
                    'Account Name': account_name,
                    'Region': region,
                    'Title': finding.get('Title', 'N/A'),
                    'Severity': finding.get('Severity', {}).get('Label', 'INFORMATIONAL'),
                    'Status': finding.get('Compliance', {}).get('Status', 'N/A'),
                    'Resource Type': finding.get('Resources', [{}])[0].get('Type', 'N/A'),
                    'Resource ID': finding.get('Resources', [{}])[0].get('Id', 'N/A'),
                    'Generator ID': finding.get('GeneratorId', 'N/A').split('/')[-1],
                    'Created At': finding.get('CreatedAt', 'N/A'),
                    'Updated At': finding.get('UpdatedAt', 'N/A'),
                    'Description': finding.get('Description', 'N/A')[:200],
                }
                findings.append(finding_data)
                
    except ClientError:
        pass
    except Exception:
        pass
    
    return findings

def fetch_security_hub_data(selected_account_ids, all_accounts, role_name, regions):
    """Fetch Security Hub findings for all selected accounts"""
    all_findings = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    total_accounts = len(selected_account_ids)
    
    for idx, account_id in enumerate(selected_account_ids):
        account_name = AWSOrganizations.get_account_name_by_id(account_id, all_accounts)
        status_text.text(f"📡 Scanning: {account_name} ({idx + 1}/{total_accounts})")
        
        with ThreadPoolExecutor(max_workers=AWSConfig.MAX_WORKERS) as executor:
            futures = {
                executor.submit(get_security_hub_findings, region, account_id, account_name, role_name): region
                for region in regions
            }
            
            for future in as_completed(futures):
                try:
                    findings = future.result()
                    all_findings.extend(findings)
                except Exception:
                    pass
        
        progress_bar.progress((idx + 1) / total_accounts)
    
    progress_bar.empty()
    status_text.empty()
    
    return all_findings

# ============================================================================
# BUTTON HANDLERS
# ============================================================================

# Check if fetch button was clicked
if st.session_state.get('security_hub_fetch_clicked', False):
    if not selected_account_ids:
        st.warning("⚠️ Please select at least one account.")
        st.session_state.security_hub_fetch_clicked = False
    elif not selected_regions:
        st.warning("⚠️ Please select at least one region.")
        st.session_state.security_hub_fetch_clicked = False
    else:
        start_time = time.time()
        
        with st.spinner(f"🔍 Scanning Security Hub in {len(selected_account_ids)} account(s)..."):
            findings_data = fetch_security_hub_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, selected_regions)
            st.session_state.security_hub_data = findings_data
            st.session_state.security_hub_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        elapsed_time = time.time() - start_time
        st.success(f"✅ Successfully fetched {len(findings_data)} findings in {elapsed_time:.2f} seconds")
        st.session_state.security_hub_fetch_clicked = False

# ============================================================================
# DISPLAY RESULTS
# ============================================================================

if st.session_state.security_hub_data is not None:
    df = pd.DataFrame(st.session_state.security_hub_data)
    
    # Refresh button on main page
    col_title, col_refresh = st.columns([5, 1])
    with col_title:
        if st.session_state.security_hub_last_refresh:
            st.caption(f"Last refreshed: {st.session_state.security_hub_last_refresh}")
    with col_refresh:
        if st.button("🔁 Refresh", type="secondary", use_container_width=True, key="security_hub_refresh_btn"):
            if not selected_account_ids:
                st.warning("⚠️ Please select at least one account.")
            elif not selected_regions:
                st.warning("⚠️ Please select at least one region.")
            else:
                start_time = time.time()
                
                with st.spinner(f"🔍 Refreshing data..."):
                    findings_data = fetch_security_hub_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, selected_regions)
                    st.session_state.security_hub_data = findings_data
                    st.session_state.security_hub_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                
                elapsed_time = time.time() - start_time
                st.success(f"✅ Data refreshed ({len(findings_data)} findings in {elapsed_time:.2f} seconds)")
                st.rerun()
    
    if df.empty:
        st.info("ℹ️ No Security Hub findings found in the selected accounts and regions.")
    else:
        # Summary metrics
        st.subheader("📊 Summary Metrics")
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("Total Findings", len(df))
        
        with col2:
            critical_count = len(df[df['Severity'] == 'CRITICAL'])
            st.metric("🔴 Critical", critical_count)
        
        with col3:
            high_count = len(df[df['Severity'] == 'HIGH'])
            st.metric("🟠 High", high_count)
        
        with col4:
            medium_count = len(df[df['Severity'] == 'MEDIUM'])
            st.metric("🟡 Medium", medium_count)
        
        with col5:
            unique_accounts = df['Account ID'].nunique()
            st.metric("Accounts", unique_accounts)
        
        st.markdown("---")
        
        # Filters
        st.subheader("🔍 Filters")
        
        filter_col1, filter_col2, filter_col3 = st.columns(3)
        
        with filter_col1:
            severity_filter = st.multiselect(
                "Severity:",
                options=sorted(df['Severity'].unique().tolist()),
                default=sorted(df['Severity'].unique().tolist())
            )
        
        with filter_col2:
            region_filter = st.multiselect(
                "Region:",
                options=sorted(df['Region'].unique().tolist()),
                default=sorted(df['Region'].unique().tolist())
            )
        
        with filter_col3:
            account_filter = st.multiselect(
                "Account:",
                options=sorted(df['Account Name'].unique().tolist()),
                default=sorted(df['Account Name'].unique().tolist())
            )
        
        # Apply filters
        filtered_df = df[
            (df['Severity'].isin(severity_filter)) &
            (df['Region'].isin(region_filter)) &
            (df['Account Name'].isin(account_filter))
        ]
        
        st.markdown("---")
        
        # Display data
        st.subheader(f"📋 Security Findings ({len(filtered_df)} findings)")
        
        # Column selector
        available_columns = filtered_df.columns.tolist()
        default_columns = [
            'Account Name', 'Region', 'Severity', 'Title',
            'Resource Type', 'Resource ID', 'Generator ID'
        ]
        
        selected_columns = st.multiselect(
            "Select columns to display:",
            options=available_columns,
            default=[col for col in default_columns if col in available_columns]
        )
        
        if selected_columns:
            display_df = filtered_df[selected_columns]
        else:
            display_df = filtered_df
        
        st.dataframe(display_df, use_container_width=True, height=500, hide_index=True)
        
        # Download button
        st.markdown("---")
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Security Findings (CSV)",
            data=csv,
            file_name=f"security_hub_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
        
        # Statistics
        with st.expander("📈 Additional Statistics"):
            stat_col1, stat_col2 = st.columns(2)
            
            with stat_col1:
                st.write("**Findings by Severity:**")
                severity_counts = filtered_df['Severity'].value_counts()
                st.dataframe(severity_counts, use_container_width=True)
            
            with stat_col2:
                st.write("**Top 10 Finding Types:**")
                generator_counts = filtered_df['Generator ID'].value_counts().head(10)
                st.dataframe(generator_counts, use_container_width=True)

else:
    st.info("👈 Configure options in the sidebar and click 'Fetch Data' to begin.")
```
