# Complete main.py

Save this as: `main.py`

```python
"""
AWS Multi-Account Dashboard - Main Entry Point

Architecture:
- AssumeRole authentication only (READONLY_ROLE_NAME)
- Merged aws_helper.py module
- Common sidebar across all pages
- No persistence between pages
"""

import streamlit as st
from modules.aws_helper import AWSConfig, AWSOrganizations, validate_aws_config

# Page configuration
st.set_page_config(
    page_title="AWS Multi-Account Dashboard",
    page_icon="🌩️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #FF9900;
        margin-bottom: 10px;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #666;
        margin-bottom: 20px;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'all_accounts' not in st.session_state:
    st.session_state.all_accounts = []

# Header
st.markdown('<p class="main-header">🌩️ AWS Multi-Account Dashboard</p>', unsafe_allow_html=True)
st.markdown('<p class="sub-header">Centralized view for all AWS resources</p>', unsafe_allow_html=True)

# Validate credentials
is_valid, message, account_id = validate_aws_config()

if is_valid:
    st.success(message)
else:
    st.error(message)
    st.error("❌ Unable to authenticate with AWS")
    st.info("""
    **Required Environment Variables:**
    - `READONLY_ROLE_NAME` - IAM role name to assume (default: ReadOnlyRole)
    
    **Required Permissions:**
    - Base credentials must have `sts:AssumeRole` permission
    - Base credentials must have `organizations:ListAccounts` permission
    - Target role must trust your base credentials
    """)
    st.stop()

# Load accounts
try:
    if not st.session_state.all_accounts:
        with st.spinner("Loading AWS accounts from Organizations..."):
            st.session_state.all_accounts = AWSOrganizations.list_accounts()
    
    all_accounts = st.session_state.all_accounts
    
    if not all_accounts:
        st.error("❌ No active accounts found in AWS Organizations")
        st.stop()
    
    st.info(f"✅ Found {len(all_accounts)} active account(s)")
    
except Exception as e:
    st.error(f"❌ Error loading accounts: {str(e)}")
    st.stop()

# Store accounts for use in pages
st.session_state.accounts = all_accounts

# ============================================================================
# MAIN CONTENT
# ============================================================================

st.markdown("---")

col1, col2 = st.columns(2)

with col1:
    st.subheader("📊 Available Dashboards")
    st.markdown("""
    - **Account Health**: Comprehensive account security and resource summary
    - **EC2 Details**: Monitor EC2 instances across accounts and regions
    - **Security Hub**: View security findings and compliance status
    - **AWS Config**: Track configuration compliance and rules
    - **IAM Users**: View IAM users, access keys, and MFA status
    - **IAM Key Rotation**: Monitor access key age and rotation status
    
    Select a dashboard from the navigation menu to get started.
    """)

with col2:
    st.subheader("🚀 Features")
    st.markdown("""
    - **Unified authentication**: AssumeRole to ReadOnlyRole everywhere
    - **Multi-account support**: Scan resources across all AWS accounts
    - **Cross-region discovery**: Find resources in all AWS regions
    - **Alphabetically sorted accounts**: Easy account selection
    - **CSV export**: Download results for further analysis
    - **Refresh functionality**: Update data without re-fetching
    """)

# Quick Stats
st.markdown("---")
st.subheader("📈 Organization Summary")

col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Total Accounts", len(all_accounts))

with col2:
    st.metric("Management Account", account_id)

with col3:
    st.metric("Dashboard Pages", "6")

# Getting Started Guide
st.markdown("---")
with st.expander("🎯 Getting Started Guide"):
    st.markdown(f"""
    ### How to Use This Dashboard
    
    1. **Navigate to a Dashboard** from the sidebar menu
    2. **Select Accounts and Regions** in the sidebar
    3. **Click "Fetch Data"** button in sidebar
    4. **View Results** - Data will be displayed on the page
    5. **Use "Refresh"** button on the page to update data
    6. **Download CSV** for offline analysis
    
    ### Configuration
    - **Role Name**: `{AWSConfig.READONLY_ROLE_NAME}`
    - **Max Workers**: `{AWSConfig.MAX_WORKERS}`
    
    ### Tips
    - Accounts are sorted alphabetically for easy selection
    - Use "Common Regions" for faster scans
    - Click "Refresh" on dashboard pages to update data
    - Each dashboard page has independent account/region selection
    - Use "Select All Accounts" checkbox for organization-wide scans
    """)

# Footer
st.markdown("---")
st.caption(f"""
AWS Multi-Account Dashboard | Role: {AWSConfig.READONLY_ROLE_NAME} | Workers: {AWSConfig.MAX_WORKERS}
""")
```
