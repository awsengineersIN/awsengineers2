# Complete pages/EC2_details.py (Reference Implementation)

Save this as: `pages/EC2_details.py`

```python
"""
EC2 Details Dashboard Page

Displays EC2 instances across selected accounts and regions.
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

from modules.aws_helper import AWSConfig, AWSOrganizations, AWSSession
from modules.sidebar_common import render_sidebar
from botocore.exceptions import ClientError

# Page configuration
st.set_page_config(page_title="EC2 Details", page_icon="📊", layout="wide")

# Initialize session state
if 'ec2_data' not in st.session_state:
    st.session_state.ec2_data = None
if 'ec2_last_refresh' not in st.session_state:
    st.session_state.ec2_last_refresh = None

# Header
st.title("📊 EC2 Instance Dashboard")

# Get all accounts
all_accounts = st.session_state.get('accounts', [])
if not all_accounts:
    st.error("No accounts found. Please return to main page.")
    st.stop()

# ============================================================================
# SIDEBAR CONFIGURATION
# ============================================================================

selected_account_ids, selected_regions = render_sidebar(page_key_prefix="ec2_")

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_ec2_instances_in_region(region, account_id, account_name, role_name):
    """Get EC2 instances for a specific region in a target account"""
    instances = []
    try:
        ec2_client = AWSSession.get_client_for_account('ec2', account_id, role_name, region)
        
        paginator = ec2_client.get_paginator('describe_instances')
        
        for page in paginator.paginate():
            for reservation in page['Reservations']:
                for instance in reservation['Instances']:
                    instance_name = ''
                    if 'Tags' in instance:
                        for tag in instance['Tags']:
                            if tag['Key'] == 'Name':
                                instance_name = tag['Value']
                                break
                    
                    instance_data = {
                        'Account ID': account_id,
                        'Account Name': account_name,
                        'Region': region,
                        'Instance ID': instance['InstanceId'],
                        'Instance Name': instance_name,
                        'Instance Type': instance['InstanceType'],
                        'State': instance['State']['Name'],
                        'Private IP': instance.get('PrivateIpAddress', 'N/A'),
                        'Public IP': instance.get('PublicIpAddress', 'N/A'),
                        'VPC ID': instance.get('VpcId', 'N/A'),
                        'Availability Zone': instance['Placement']['AvailabilityZone'],
                        'Launch Time': instance['LaunchTime'].strftime('%Y-%m-%d %H:%M:%S'),
                        'Platform': instance.get('Platform', 'Linux/Unix'),
                    }
                    instances.append(instance_data)
    except ClientError:
        pass
    except Exception:
        pass
    
    return instances

def fetch_ec2_data(selected_account_ids, all_accounts, role_name, regions):
    """Fetch EC2 data for all selected accounts"""
    all_ec2_data = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    total_accounts = len(selected_account_ids)
    
    for idx, account_id in enumerate(selected_account_ids):
        account_name = AWSOrganizations.get_account_name_by_id(account_id, all_accounts)
        status_text.text(f"📡 Scanning: {account_name} ({idx + 1}/{total_accounts})")
        
        with ThreadPoolExecutor(max_workers=AWSConfig.MAX_WORKERS) as executor:
            futures = {
                executor.submit(get_ec2_instances_in_region, region, account_id, account_name, role_name): region
                for region in regions
            }
            
            for future in as_completed(futures):
                try:
                    instances = future.result()
                    all_ec2_data.extend(instances)
                except Exception:
                    pass
        
        progress_bar.progress((idx + 1) / total_accounts)
    
    progress_bar.empty()
    status_text.empty()
    
    return all_ec2_data

# ============================================================================
# BUTTON HANDLERS
# ============================================================================

# Check if fetch button was clicked
if st.session_state.get('ec2_fetch_clicked', False):
    if not selected_account_ids:
        st.warning("⚠️ Please select at least one account.")
        st.session_state.ec2_fetch_clicked = False
    elif not selected_regions:
        st.warning("⚠️ Please select at least one region.")
        st.session_state.ec2_fetch_clicked = False
    else:
        start_time = time.time()
        
        with st.spinner(f"🔍 Scanning {len(selected_account_ids)} account(s) across {len(selected_regions)} region(s)..."):
            ec2_data = fetch_ec2_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, selected_regions)
            st.session_state.ec2_data = ec2_data
            st.session_state.ec2_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        elapsed_time = time.time() - start_time
        st.success(f"✅ Successfully fetched {len(ec2_data)} instances in {elapsed_time:.2f} seconds")
        st.session_state.ec2_fetch_clicked = False

# ============================================================================
# DISPLAY RESULTS
# ============================================================================

if st.session_state.ec2_data is not None:
    df = pd.DataFrame(st.session_state.ec2_data)
    
    # Refresh button on main page
    col_title, col_refresh = st.columns([5, 1])
    with col_title:
        if st.session_state.ec2_last_refresh:
            st.caption(f"Last refreshed: {st.session_state.ec2_last_refresh}")
    with col_refresh:
        if st.button("🔁 Refresh", type="secondary", use_container_width=True, key="ec2_refresh_btn"):
            if not selected_account_ids:
                st.warning("⚠️ Please select at least one account.")
            elif not selected_regions:
                st.warning("⚠️ Please select at least one region.")
            else:
                start_time = time.time()
                
                with st.spinner(f"🔍 Refreshing data..."):
                    ec2_data = fetch_ec2_data(selected_account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, selected_regions)
                    st.session_state.ec2_data = ec2_data
                    st.session_state.ec2_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                
                elapsed_time = time.time() - start_time
                st.success(f"✅ Data refreshed ({len(ec2_data)} instances in {elapsed_time:.2f} seconds)")
                st.rerun()
    
    if df.empty:
        st.info("ℹ️ No EC2 instances found in the selected accounts and regions.")
    else:
        # Summary metrics
        st.subheader("📊 Summary Metrics")
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("Total Instances", len(df))
        
        with col2:
            running_count = len(df[df['State'] == 'running'])
            st.metric("🟢 Running", running_count)
        
        with col3:
            stopped_count = len(df[df['State'] == 'stopped'])
            st.metric("🔴 Stopped", stopped_count)
        
        with col4:
            unique_accounts = df['Account ID'].nunique()
            st.metric("Accounts", unique_accounts)
        
        with col5:
            unique_regions = df['Region'].nunique()
            st.metric("Regions", unique_regions)
        
        st.markdown("---")
        
        # Filters
        st.subheader("🔍 Filters")
        
        filter_col1, filter_col2, filter_col3 = st.columns(3)
        
        with filter_col1:
            state_filter = st.multiselect(
                "Instance State:",
                options=sorted(df['State'].unique().tolist()),
                default=sorted(df['State'].unique().tolist())
            )
        
        with filter_col2:
            region_filter = st.multiselect(
                "Region:",
                options=sorted(df['Region'].unique().tolist()),
                default=sorted(df['Region'].unique().tolist())
            )
        
        with filter_col3:
            account_filter = st.multiselect(
                "Account:",
                options=sorted(df['Account Name'].unique().tolist()),
                default=sorted(df['Account Name'].unique().tolist())
            )
        
        # Apply filters
        filtered_df = df[
            (df['State'].isin(state_filter)) &
            (df['Region'].isin(region_filter)) &
            (df['Account Name'].isin(account_filter))
        ]
        
        st.markdown("---")
        
        # Display data
        st.subheader(f"📋 EC2 Instances ({len(filtered_df)} instances)")
        
        # Column selector
        available_columns = filtered_df.columns.tolist()
        default_columns = [
            'Account Name', 'Region', 'Instance ID', 'Instance Name',
            'Instance Type', 'State', 'Private IP', 'Public IP'
        ]
        
        selected_columns = st.multiselect(
            "Select columns to display:",
            options=available_columns,
            default=[col for col in default_columns if col in available_columns]
        )
        
        if selected_columns:
            display_df = filtered_df[selected_columns]
        else:
            display_df = filtered_df
        
        st.dataframe(display_df, use_container_width=True, height=500, hide_index=True)
        
        # Download button
        st.markdown("---")
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Download Data (CSV)",
            data=csv,
            file_name=f"ec2_instances_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )
        
        # Statistics
        with st.expander("📈 Additional Statistics"):
            stat_col1, stat_col2 = st.columns(2)
            
            with stat_col1:
                st.write("**Instances by State:**")
                state_counts = filtered_df['State'].value_counts()
                st.dataframe(state_counts, use_container_width=True)
            
            with stat_col2:
                st.write("**Instances by Type:**")
                type_counts = filtered_df['Instance Type'].value_counts().head(10)
                st.dataframe(type_counts, use_container_width=True)

else:
    st.info("👈 Configure options in the sidebar and click 'Fetch Data' to begin.")
```
