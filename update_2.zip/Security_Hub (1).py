"""
Security Hub Dashboard

Displays Security Hub findings with severity-based filtering.
Optimized with parallel processing and comprehensive error handling.
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

from modules.aws_helper import AWSConfig, AWSOrganizations, AWSSession
from modules.sidebar_simple import render_sidebar
from botocore.exceptions import ClientError

# Page configuration
st.set_page_config(page_title="Security Hub", page_icon="🔒", layout="wide")

# Initialize session state
if 'securityhub_data' not in st.session_state:
    st.session_state.securityhub_data = None
if 'securityhub_last_refresh' not in st.session_state:
    st.session_state.securityhub_last_refresh = None
if 'securityhub_errors' not in st.session_state:
    st.session_state.securityhub_errors = []

st.title("🔒 Security Hub Dashboard")

# Get accounts
all_accounts = st.session_state.get('accounts', [])
if not all_accounts:
    st.error("No accounts found. Please return to main page.")
    st.stop()

# Sidebar
account_ids, regions = render_sidebar(page_key="securityhub")

st.sidebar.markdown("---")
debug_mode = st.sidebar.checkbox("Show Debug Info", value=False)

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_security_hub_findings(region, account_id, account_name, role_name):
    """Get Security Hub findings for a specific region"""
    findings = []
    errors = []
    
    try:
        sh_client = AWSSession.get_client_for_account('securityhub', account_id, role_name, region)
        
        # Check if Security Hub is enabled
        try:
            sh_client.describe_hub()
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code == 'InvalidAccessException':
                errors.append(f"ℹ️ {account_name}/{region}: Security Hub not enabled")
            else:
                errors.append(f"⚠️ {account_name}/{region}: Cannot access Security Hub - {str(e)}")
            return findings, errors
        
        # Get active findings
        try:
            response = sh_client.get_findings(
                Filters={
                    'RecordState': [{'Value': 'ACTIVE', 'Comparison': 'EQUALS'}],
                    'WorkflowStatus': [{'Value': 'NEW', 'Comparison': 'EQUALS'}]
                },
                MaxResults=100
            )
            
            for finding in response.get('Findings', []):
                finding_data = {
                    'Account ID': account_id,
                    'Account Name': account_name,
                    'Region': region,
                    'Title': finding.get('Title', 'N/A'),
                    'Severity': finding.get('Severity', {}).get('Label', 'INFORMATIONAL'),
                    'Status': finding.get('Compliance', {}).get('Status', 'N/A'),
                    'Resource Type': finding.get('Resources', [{}])[0].get('Type', 'N/A'),
                    'Resource ID': finding.get('Resources', [{}])[0].get('Id', 'N/A'),
                    'Generator ID': finding.get('GeneratorId', 'N/A').split('/')[-1],
                    'Created At': finding.get('CreatedAt', 'N/A'),
                    'Updated At': finding.get('UpdatedAt', 'N/A'),
                    'Description': finding.get('Description', 'N/A')[:200],
                }
                findings.append(finding_data)
            
            if response.get('NextToken'):
                errors.append(f"ℹ️ {account_name}/{region}: Showing first 100 findings (more available)")
                
        except ClientError as e:
            errors.append(f"❌ {account_name}/{region}: Error fetching findings - {str(e)}")
            
    except Exception as e:
        errors.append(f"❌ {account_name}/{region}: Unexpected error - {str(e)}")
    
    return findings, errors

def fetch_data(account_ids, all_accounts, role_name, regions):
    """Fetch data with parallel processing"""
    all_data = []
    all_errors = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    with ThreadPoolExecutor(max_workers=AWSConfig.MAX_WORKERS) as executor:
        futures = {}
        
        for account_id in account_ids:
            account_name = AWSOrganizations.get_account_name_by_id(account_id, all_accounts)
            for region in regions:
                future = executor.submit(get_security_hub_findings, region, account_id, account_name, role_name)
                futures[future] = (account_id, account_name, region)
        
        total = len(futures)
        completed = 0
        
        for future in as_completed(futures):
            account_id, account_name, region = futures[future]
            completed += 1
            status_text.text(f"📡 {account_name} / {region} ({completed}/{total})")
            progress_bar.progress(completed / total)
            
            try:
                data, errors = future.result()
                all_data.extend(data)
                all_errors.extend(errors)
            except Exception as e:
                all_errors.append(f"❌ {account_name}/{region}: Failed - {str(e)}")
    
    progress_bar.empty()
    status_text.empty()
    
    return all_data, all_errors

# ============================================================================
# FETCH BUTTON
# ============================================================================

if st.session_state.get('securityhub_fetch_clicked', False):
    if not account_ids or not regions:
        st.warning("⚠️ Please select at least one account and region.")
        st.session_state.securityhub_fetch_clicked = False
    else:
        start_time = time.time()
        
        with st.spinner(f"🔍 Scanning Security Hub..."):
            data, errors = fetch_data(account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, regions)
            st.session_state.securityhub_data = data
            st.session_state.securityhub_errors = errors
            st.session_state.securityhub_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        elapsed = time.time() - start_time
        
        if data:
            st.success(f"✅ Found {len(data)} findings in {elapsed:.2f}s")
        else:
            st.warning(f"⚠️ No findings in {elapsed:.2f}s")
        
        if errors:
            with st.expander(f"⚠️ Messages ({len(errors)})", expanded=True):
                for error in errors:
                    st.write(error)
        
        st.session_state.securityhub_fetch_clicked = False

# ============================================================================
# DISPLAY
# ============================================================================

if debug_mode and st.session_state.securityhub_errors:
    with st.expander("🐛 Debug Info"):
        for error in st.session_state.securityhub_errors:
            st.write(error)

if st.session_state.securityhub_data is not None:
    df = pd.DataFrame(st.session_state.securityhub_data)
    
    # Refresh button
    col1, col2 = st.columns([5, 1])
    with col1:
        if st.session_state.securityhub_last_refresh:
            st.caption(f"Last refreshed: {st.session_state.securityhub_last_refresh}")
    with col2:
        if st.button("🔁 Refresh", type="secondary", use_container_width=True):
            start_time = time.time()
            with st.spinner("🔍 Refreshing..."):
                data, errors = fetch_data(account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, regions)
                st.session_state.securityhub_data = data
                st.session_state.securityhub_errors = errors
                st.session_state.securityhub_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            elapsed = time.time() - start_time
            st.success(f"✅ Refreshed ({len(data)} findings in {elapsed:.2f}s)")
            if errors:
                with st.expander(f"⚠️ Messages ({len(errors)})"):
                    for error in errors:
                        st.write(error)
            st.rerun()
    
    if df.empty:
        st.info("ℹ️ No Security Hub findings found.")
    else:
        # Metrics
        st.subheader("📊 Summary")
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("Total Findings", len(df))
        with col2:
            critical = len(df[df['Severity'] == 'CRITICAL'])
            st.metric("🔴 Critical", critical)
        with col3:
            high = len(df[df['Severity'] == 'HIGH'])
            st.metric("🟠 High", high)
        with col4:
            medium = len(df[df['Severity'] == 'MEDIUM'])
            st.metric("🟡 Medium", medium)
        with col5:
            st.metric("Accounts", df['Account ID'].nunique())
        
        st.markdown("---")
        
        # Filters
        st.subheader("🔍 Filters")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            severity = st.multiselect(
                "Severity:",
                options=sorted(df['Severity'].unique()),
                default=sorted(df['Severity'].unique())
            )
        
        with col2:
            regions_filter = st.multiselect(
                "Region:",
                options=sorted(df['Region'].unique()),
                default=sorted(df['Region'].unique())
            )
        
        with col3:
            accounts_filter = st.multiselect(
                "Account:",
                options=sorted(df['Account Name'].unique()),
                default=sorted(df['Account Name'].unique())
            )
        
        filtered = df[
            (df['Severity'].isin(severity)) &
            (df['Region'].isin(regions_filter)) &
            (df['Account Name'].isin(accounts_filter))
        ]
        
        st.markdown("---")
        
        # Data table
        st.subheader(f"📋 Findings ({len(filtered)} items)")
        st.dataframe(filtered, use_container_width=True, height=500, hide_index=True)
        
        # Download
        st.markdown("---")
        csv = filtered.to_csv(index=False)
        st.download_button(
            label="📥 Download CSV",
            data=csv,
            file_name=f"securityhub_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )

else:
    st.info("👈 Select accounts and regions, then click 'Fetch Data'")
