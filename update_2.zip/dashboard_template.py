"""
Dashboard Template - Ultra-Simplified

INSTRUCTIONS:
1. Save this file as: pages/Your_Service_Name.py
2. Replace [SERVICE_NAME] with display name (e.g., "RDS Instances")
3. Replace [service] with lowercase key (e.g., "rds")
4. Implement get_service_data_in_region() function
5. Done!

All features included:
✅ Parallel processing (5-10x faster)
✅ Progress tracking
✅ Error handling & debug mode
✅ Filters and metrics
✅ CSV download
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

from modules.aws_helper import AWSConfig, AWSOrganizations, AWSSession
from modules.sidebar_simple import render_sidebar
from botocore.exceptions import ClientError

# Configuration
st.set_page_config(page_title="[SERVICE_NAME]", page_icon="📊", layout="wide")

# Session state
if '[service]_data' not in st.session_state:
    st.session_state.[service]_data = None
if '[service]_last_refresh' not in st.session_state:
    st.session_state.[service]_last_refresh = None
if '[service]_errors' not in st.session_state:
    st.session_state.[service]_errors = []

st.title("📊 [SERVICE_NAME] Dashboard")

# Get accounts
all_accounts = st.session_state.get('accounts', [])
if not all_accounts:
    st.error("No accounts found. Please return to main page.")
    st.stop()

# Sidebar
account_ids, regions = render_sidebar(page_key="[service]")

st.sidebar.markdown("---")
debug_mode = st.sidebar.checkbox("Show Debug Info", value=False)

# ============================================================================
# TODO: IMPLEMENT THIS FUNCTION ONLY
# ============================================================================

def get_service_data_in_region(region, account_id, account_name, role_name):
    """
    TODO: Implement your service data fetching logic here.
    
    Example for RDS:
    
    data_items = []
    errors = []
    
    try:
        client = AWSSession.get_client_for_account('rds', account_id, role_name, region)
        paginator = client.get_paginator('describe_db_instances')
        
        for page in paginator.paginate():
            for db in page['DBInstances']:
                data_items.append({
                    'Account ID': account_id,
                    'Account Name': account_name,
                    'Region': region,
                    'DB ID': db['DBInstanceIdentifier'],
                    'Engine': db['Engine'],
                    'Status': db['DBInstanceStatus'],
                })
                    
    except ClientError as e:
        errors.append(f"⚠️ {account_name}/{region}: Cannot access service - {str(e)}")
    
    return data_items, errors
    """
    
    data_items = []
    errors = []
    
    try:
        # TODO: Replace '[service]' with your AWS service name
        client = AWSSession.get_client_for_account('[service]', account_id, role_name, region)
        
        # TODO: Implement data fetching with pagination
        # Example: paginator = client.get_paginator('describe_[resources]')
        
        # Placeholder - Remove this when implementing
        errors.append(f"ℹ️ {account_name}/{region}: TODO - Implement service data fetching")
                    
    except ClientError as e:
        errors.append(f"⚠️ {account_name}/{region}: Cannot access service - {str(e)}")
    except Exception as e:
        errors.append(f"❌ {account_name}/{region}: Unexpected error - {str(e)}")
    
    return data_items, errors

# ============================================================================
# PARALLEL PROCESSING (No changes needed)
# ============================================================================

def fetch_data(account_ids, all_accounts, role_name, regions):
    """Fetch data with parallel processing"""
    all_data = []
    all_errors = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    with ThreadPoolExecutor(max_workers=AWSConfig.MAX_WORKERS) as executor:
        futures = {}
        
        for account_id in account_ids:
            account_name = AWSOrganizations.get_account_name_by_id(account_id, all_accounts)
            for region in regions:
                future = executor.submit(get_service_data_in_region, region, account_id, account_name, role_name)
                futures[future] = (account_id, account_name, region)
        
        total = len(futures)
        completed = 0
        
        for future in as_completed(futures):
            account_id, account_name, region = futures[future]
            completed += 1
            status_text.text(f"📡 {account_name} / {region} ({completed}/{total})")
            progress_bar.progress(completed / total)
            
            try:
                data, errors = future.result()
                all_data.extend(data)
                all_errors.extend(errors)
            except Exception as e:
                all_errors.append(f"❌ {account_name}/{region}: Failed - {str(e)}")
    
    progress_bar.empty()
    status_text.empty()
    
    return all_data, all_errors

# ============================================================================
# FETCH BUTTON (No changes needed)
# ============================================================================

if st.session_state.get('[service]_fetch_clicked', False):
    if not account_ids or not regions:
        st.warning("⚠️ Please select at least one account and region.")
        st.session_state.[service]_fetch_clicked = False
    else:
        start_time = time.time()
        
        with st.spinner(f"🔍 Scanning [SERVICE_NAME]..."):
            data, errors = fetch_data(account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, regions)
            st.session_state.[service]_data = data
            st.session_state.[service]_errors = errors
            st.session_state.[service]_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        elapsed = time.time() - start_time
        
        if data:
            st.success(f"✅ Found {len(data)} items in {elapsed:.2f}s")
        else:
            st.warning(f"⚠️ No data in {elapsed:.2f}s")
        
        if errors:
            with st.expander(f"⚠️ Messages ({len(errors)})", expanded=True):
                for error in errors:
                    st.write(error)
        
        st.session_state.[service]_fetch_clicked = False

# ============================================================================
# DISPLAY (No changes needed)
# ============================================================================

if debug_mode and st.session_state.[service]_errors:
    with st.expander("🐛 Debug Info"):
        for error in st.session_state.[service]_errors:
            st.write(error)

if st.session_state.[service]_data is not None:
    df = pd.DataFrame(st.session_state.[service]_data)
    
    # Refresh button
    col1, col2 = st.columns([5, 1])
    with col1:
        if st.session_state.[service]_last_refresh:
            st.caption(f"Last refreshed: {st.session_state.[service]_last_refresh}")
    with col2:
        if st.button("🔁 Refresh", type="secondary", use_container_width=True):
            start_time = time.time()
            with st.spinner("🔍 Refreshing..."):
                data, errors = fetch_data(account_ids, all_accounts, AWSConfig.READONLY_ROLE_NAME, regions)
                st.session_state.[service]_data = data
                st.session_state.[service]_errors = errors
                st.session_state.[service]_last_refresh = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            elapsed = time.time() - start_time
            st.success(f"✅ Refreshed ({len(data)} items in {elapsed:.2f}s)")
            if errors:
                with st.expander(f"⚠️ Messages ({len(errors)})"):
                    for error in errors:
                        st.write(error)
            st.rerun()
    
    if df.empty:
        st.info("ℹ️ No data found.")
    else:
        # Metrics
        st.subheader("📊 Summary")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Items", len(df))
        with col2:
            st.metric("Accounts", df['Account ID'].nunique())
        with col3:
            st.metric("Regions", df['Region'].nunique())
        
        st.markdown("---")
        
        # Filters
        st.subheader("🔍 Filters")
        col1, col2 = st.columns(2)
        
        with col1:
            regions_filter = st.multiselect(
                "Region:",
                options=sorted(df['Region'].unique()),
                default=sorted(df['Region'].unique())
            )
        
        with col2:
            accounts_filter = st.multiselect(
                "Account:",
                options=sorted(df['Account Name'].unique()),
                default=sorted(df['Account Name'].unique())
            )
        
        filtered = df[(df['Region'].isin(regions_filter)) & (df['Account Name'].isin(accounts_filter))]
        
        st.markdown("---")
        
        # Data table
        st.subheader(f"📋 Data ({len(filtered)} items)")
        st.dataframe(filtered, use_container_width=True, height=500, hide_index=True)
        
        # Download
        st.markdown("---")
        csv = filtered.to_csv(index=False)
        st.download_button(
            label="📥 Download CSV",
            data=csv,
            file_name=f"[service]_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv"
        )

else:
    st.info("👈 Select accounts and regions, then click 'Fetch Data'")
