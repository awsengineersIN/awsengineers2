# Unified AWS Module (Merged config.py + iam.py)

Save this as: `modules/aws_helper.py`

```python
"""
Unified AWS Helper Module

Handles all AWS operations including:
- Authentication (AssumeRole only)
- Organizations (account listing)
- Session management
- Region utilities

Authentication: Uses AssumeRole to READONLY_ROLE_NAME in all environments
"""

import os
import boto3
from botocore.exceptions import ClientError

# ============================================================================
# CONFIGURATION
# ============================================================================

class AWSConfig:
    """Configuration for AWS operations"""
    
    # IAM role name to assume (same role everywhere)
    READONLY_ROLE_NAME = os.environ.get('READONLY_ROLE_NAME', 'ReadOnlyRole')
    
    # Management account ID (must be set)
    MANAGEMENT_ACCOUNT_ID = os.environ.get('MANAGEMENT_ACCOUNT_ID')
    
    # Performance settings
    MAX_WORKERS = int(os.environ.get('MAX_WORKERS', '10'))


# ============================================================================
# SESSION MANAGEMENT
# ============================================================================

class AWSSession:
    """Handles AWS session creation with AssumeRole"""
    
    @staticmethod
    def get_base_session():
        """
        Get base boto3 session (uses EC2/ECS instance profile or environment credentials).
        No profile needed.
        """
        return boto3.Session()
    
    @staticmethod
    def assume_role(account_id, role_name, session_name='streamlit-dashboard'):
        """
        Assume role in target account.
        
        Args:
            account_id: Target AWS account ID
            role_name: IAM role name to assume
            session_name: Session name for CloudTrail
            
        Returns:
            boto3.Session: Session with assumed role credentials
        """
        base_session = AWSSession.get_base_session()
        sts_client = base_session.client('sts')
        
        role_arn = f"arn:aws:iam::{account_id}:role/{role_name}"
        
        try:
            response = sts_client.assume_role(
                RoleArn=role_arn,
                RoleSessionName=session_name
            )
            
            credentials = response['Credentials']
            
            return boto3.Session(
                aws_access_key_id=credentials['AccessKeyId'],
                aws_secret_access_key=credentials['SecretAccessKey'],
                aws_session_token=credentials['SessionToken']
            )
        except ClientError as e:
            raise Exception(f"Failed to assume role {role_arn}: {str(e)}")
    
    @staticmethod
    def get_client_for_account(service, account_id, role_name, region='us-east-1'):
        """
        Get boto3 client for specific account by assuming role.
        
        Args:
            service: AWS service name (e.g., 'ec2', 'iam')
            account_id: Target account ID
            role_name: IAM role to assume
            region: AWS region
            
        Returns:
            boto3.client: Client for the service
        """
        session = AWSSession.assume_role(account_id, role_name)
        return session.client(service, region_name=region)


# ============================================================================
# ORGANIZATIONS
# ============================================================================

class AWSOrganizations:
    """AWS Organizations operations"""
    
    @staticmethod
    def list_accounts():
        """
        List all active accounts in the organization.
        
        Returns:
            list: List of account dictionaries with Id, Name, Email, Status
        """
        session = AWSSession.get_base_session()
        org_client = session.client('organizations')
        
        accounts = []
        paginator = org_client.get_paginator('list_accounts')
        
        for page in paginator.paginate():
            for account in page['Accounts']:
                if account['Status'] == 'ACTIVE':
                    accounts.append({
                        'Id': account['Id'],
                        'Name': account['Name'],
                        'Email': account['Email'],
                        'Status': account['Status']
                    })
        
        return accounts
    
    @staticmethod
    def get_account_name_by_id(account_id, accounts_list):
        """
        Get account name from account ID.
        
        Args:
            account_id: AWS account ID
            accounts_list: List of account dictionaries
            
        Returns:
            str: Account name or account ID if not found
        """
        for account in accounts_list:
            if account['Id'] == account_id:
                return account['Name']
        return account_id


# ============================================================================
# REGIONS
# ============================================================================

class AWSRegions:
    """AWS region utilities"""
    
    @staticmethod
    def list_all_regions():
        """
        List all AWS regions.
        
        Returns:
            list: List of region names
        """
        session = AWSSession.get_base_session()
        ec2_client = session.client('ec2', region_name='us-east-1')
        
        response = ec2_client.describe_regions(AllRegions=False)
        regions = [region['RegionName'] for region in response['Regions']]
        
        return sorted(regions)
    
    @staticmethod
    def get_common_regions():
        """
        Get commonly used AWS regions.
        
        Returns:
            list: List of common region names
        """
        return [
            'us-east-1',      # N. Virginia
            'us-east-2',      # Ohio
            'us-west-1',      # N. California
            'us-west-2',      # Oregon
            'eu-west-1',      # Ireland
            'eu-central-1',   # Frankfurt
            'ap-southeast-1', # Singapore
            'ap-northeast-1', # Tokyo
        ]


# ============================================================================
# VALIDATION
# ============================================================================

def validate_aws_config():
    """
    Validate AWS configuration and credentials.
    
    Returns:
        tuple: (is_valid: bool, message: str, account_id: str)
    """
    try:
        session = AWSSession.get_base_session()
        sts_client = session.client('sts')
        
        identity = sts_client.get_caller_identity()
        account_id = identity['Account']
        
        # Verify we can assume the readonly role
        if AWSConfig.MANAGEMENT_ACCOUNT_ID:
            try:
                AWSSession.assume_role(
                    AWSConfig.MANAGEMENT_ACCOUNT_ID,
                    AWSConfig.READONLY_ROLE_NAME
                )
                message = f"✅ Successfully authenticated and assumed {AWSConfig.READONLY_ROLE_NAME} (Account: {account_id})"
            except Exception as e:
                return False, f"❌ Failed to assume {AWSConfig.READONLY_ROLE_NAME}: {str(e)}", None
        else:
            message = f"✅ Authenticated (Account: {account_id})"
        
        return True, message, account_id
        
    except ClientError as e:
        return False, f"❌ AWS authentication failed: {str(e)}", None
    except Exception as e:
        return False, f"❌ Configuration error: {str(e)}", None
```
