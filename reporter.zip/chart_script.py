import plotly.graph_objects as go
import json

# Load the data
data = {
    "safety_metrics": [
        {"category": "API Operations", "status": "Read-Only", "safety_score": 100, "description": "Only uses describe and list operations"},
        {"category": "Data Collection", "status": "Non-Destructive", "safety_score": 100, "description": "No resources created or modified"},
        {"category": "Resource Impact", "status": "Zero Impact", "safety_score": 100, "description": "No changes to AWS infrastructure"},
        {"category": "Security Level", "status": "Safe for Production", "safety_score": 100, "description": "Minimal permissions required"},
        {"category": "Risk Level", "status": "No Risk", "safety_score": 100, "description": "Cannot damage or modify resources"}
    ]
}

# Extract data for the chart
categories = [item['category'] for item in data['safety_metrics']]
safety_scores = [item['safety_score'] for item in data['safety_metrics']]
statuses = [item['status'] for item in data['safety_metrics']]
descriptions = [item['description'] for item in data['safety_metrics']]

# Create horizontal bar chart with status labels
fig = go.Figure(data=go.Bar(
    x=safety_scores,
    y=categories,
    orientation='h',
    marker_color='#2E8B57',  # Sea green from the theme
    text=[f"✓ {status}" for status in statuses],  # Add checkmark and status
    textposition='inside',
    textfont=dict(color='white', size=11),
    hovertemplate='<b>%{y}</b><br>Status: %{customdata[0]}<br>Score: %{x}%<br>%{customdata[1]}<extra></extra>',
    customdata=list(zip(statuses, descriptions))
))

# Update layout
fig.update_layout(
    title='AWS Usage Reporter Safety',
    xaxis_title='Safety Score (%)',
    yaxis_title='Security Cat'
)

# Update axes
fig.update_xaxes(range=[0, 105], ticksuffix='%')
fig.update_yaxes(
    categoryorder='array', 
    categoryarray=['Risk Level', 'Security Level', 'Resource Impact', 'Data Collection', 'API Operations'],
    tickfont=dict(size=12)
)

# Apply cliponaxis=False for bar charts as instructed
fig.update_traces(cliponaxis=False)

# Save the chart as both PNG and SVG
fig.write_image('safety_chart.png')
fig.write_image('safety_chart.svg', format='svg')