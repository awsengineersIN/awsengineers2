import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

# Create the workflow diagram with hierarchical layout
fig = go.Figure()

# Define positions in a hierarchical/horizontal spread layout
positions = {
    # Main flow (center column)
    'start': (0, 10),
    'init': (0, 9),
    'get_accounts': (0, 8),
    'generate_summary': (0, 2),
    'create_email': (0, 1),
    'send_email': (0, 0),
    'success': (0, -1),
    
    # Account loop (left side)
    'account_loop': (-2, 7),
    'assume_role': (-2, 6),
    'role_decision': (-2, 5),
    'skip_account': (-4, 5),  # Error path
    'next_account': (-2, 3),
    
    # Region loop (right side)
    'region_loop': (2, 6),
    'get_ec2': (2, 5),
    'ec2_decision': (2, 4),
    'get_ssm': (2, 3),
    'get_patch': (2, 2),
    'aggregate': (2, 1),
    'next_region': (4, 3),  # Loop back
    
    # Error handling
    'email_error': (-2, 0),
    'retry_logic': (4, 5)  # For throttling
}

# Define nodes with better text sizing
nodes = [
    {'id': 'start', 'text': 'Lambda\nTriggered', 'type': 'start'},
    {'id': 'init', 'text': 'Initialize\nAWS Clients', 'type': 'process'},
    {'id': 'get_accounts', 'text': 'Get Org\nAccounts', 'type': 'process'},
    {'id': 'account_loop', 'text': 'For Each\nAccount', 'type': 'loop'},
    {'id': 'assume_role', 'text': 'Assume\nRole', 'type': 'process'},
    {'id': 'role_decision', 'text': 'Role\nSuccess?', 'type': 'decision'},
    {'id': 'skip_account', 'text': 'Skip\nAccount', 'type': 'error'},
    {'id': 'region_loop', 'text': 'For Each\nRegion', 'type': 'loop'},
    {'id': 'get_ec2', 'text': 'Get EC2\nInstances', 'type': 'process'},
    {'id': 'ec2_decision', 'text': 'EC2\nFound?', 'type': 'decision'},
    {'id': 'get_ssm', 'text': 'Get SSM\nManaged', 'type': 'process'},
    {'id': 'get_patch', 'text': 'Get Patch\nCompliance', 'type': 'process'},
    {'id': 'aggregate', 'text': 'Aggregate\nData', 'type': 'process'},
    {'id': 'next_region', 'text': 'Next\nRegion', 'type': 'loop'},
    {'id': 'next_account', 'text': 'Next\nAccount', 'type': 'loop'},
    {'id': 'generate_summary', 'text': 'Generate\nSummary', 'type': 'process'},
    {'id': 'create_email', 'text': 'Create HTML\nReport', 'type': 'process'},
    {'id': 'send_email', 'text': 'Send Email\nvia SES', 'type': 'process'},
    {'id': 'email_error', 'text': 'Log Email\nError', 'type': 'error'},
    {'id': 'success', 'text': 'Return\nSuccess', 'type': 'end'},
    {'id': 'retry_logic', 'text': 'Retry\nLogic', 'type': 'error'}
]

# Define colors and symbols with better sizing
type_config = {
    'start': {'color': '#1FB8CD', 'symbol': 'circle', 'size': 30},
    'end': {'color': '#DB4545', 'symbol': 'circle', 'size': 30},
    'process': {'color': '#2E8B57', 'symbol': 'square', 'size': 25},
    'decision': {'color': '#D2BA4C', 'symbol': 'diamond', 'size': 30},
    'loop': {'color': '#5D878F', 'symbol': 'hexagon', 'size': 25},
    'error': {'color': '#B4413C', 'symbol': 'x', 'size': 25}
}

# Add nodes by type with better text formatting
for node_type in type_config.keys():
    type_nodes = [n for n in nodes if n['type'] == node_type]
    if type_nodes:
        x_coords = [positions[n['id']][0] for n in type_nodes]
        y_coords = [positions[n['id']][1] for n in type_nodes]
        texts = [n['text'] for n in type_nodes]
        
        fig.add_trace(go.Scatter(
            x=x_coords,
            y=y_coords,
            mode='markers+text',
            marker=dict(
                symbol=type_config[node_type]['symbol'],
                size=type_config[node_type]['size'],
                color=type_config[node_type]['color'],
                line=dict(width=2, color='white')
            ),
            text=texts,
            textposition='middle center',
            textfont=dict(size=9, color='white', family='Arial Black'),
            name=node_type.title(),
            hovertemplate='<b>%{text}</b><extra></extra>',
            cliponaxis=False
        ))

# Define main flow connections
main_flows = [
    ('start', 'init'),
    ('init', 'get_accounts'),
    ('get_accounts', 'account_loop'),
    ('account_loop', 'assume_role'),
    ('assume_role', 'role_decision'),
    ('role_decision', 'region_loop'),
    ('region_loop', 'get_ec2'),
    ('get_ec2', 'ec2_decision'),
    ('ec2_decision', 'get_ssm'),
    ('get_ssm', 'get_patch'),
    ('get_patch', 'aggregate'),
    ('aggregate', 'next_region'),
    ('next_account', 'generate_summary'),
    ('generate_summary', 'create_email'),
    ('create_email', 'send_email'),
    ('send_email', 'success')
]

# Add main flow arrows
for start_id, end_id in main_flows:
    start_pos = positions[start_id]
    end_pos = positions[end_id]
    
    fig.add_trace(go.Scatter(
        x=[start_pos[0], end_pos[0]],
        y=[start_pos[1], end_pos[1]],
        mode='lines',
        line=dict(color='#13343B', width=3),
        showlegend=False,
        hoverinfo='skip'
    ))

# Add decision branches with labels
decision_flows = [
    ('role_decision', 'skip_account', 'NO', 'dash'),
    ('ec2_decision', 'next_region', 'NO', 'dash'),
    ('send_email', 'email_error', 'FAIL', 'dash'),
]

for start_id, end_id, label, line_style in decision_flows:
    start_pos = positions[start_id]
    end_pos = positions[end_id]
    
    fig.add_trace(go.Scatter(
        x=[start_pos[0], end_pos[0]],
        y=[start_pos[1], end_pos[1]],
        mode='lines',
        line=dict(color='#B4413C', width=3, dash=line_style),
        showlegend=False,
        hoverinfo='skip'
    ))
    
    # Add larger decision labels
    mid_x = (start_pos[0] + end_pos[0]) / 2
    mid_y = (start_pos[1] + end_pos[1]) / 2
    fig.add_annotation(
        x=mid_x,
        y=mid_y,
        text=f"<b>{label}</b>",
        showarrow=False,
        font=dict(size=12, color='#B4413C'),
        bgcolor='white',
        bordercolor='#B4413C',
        borderwidth=2
    )

# Add loop connections
loop_flows = [
    ('next_region', 'region_loop', '#5D878F'),
    ('skip_account', 'next_account', '#B4413C'),
    ('next_account', 'account_loop', '#5D878F')
]

for start_id, end_id, color in loop_flows:
    start_pos = positions[start_id]
    end_pos = positions[end_id]
    
    # Create curved arrow for loops
    if start_id == 'next_region':
        # Curve right and up
        curve_x = [start_pos[0], start_pos[0] + 1, end_pos[0] + 1, end_pos[0]]
        curve_y = [start_pos[1], start_pos[1] + 0.5, end_pos[1] - 0.5, end_pos[1]]
    elif start_id == 'next_account':
        # Curve left and up
        curve_x = [start_pos[0], start_pos[0] - 1, end_pos[0] - 1, end_pos[0]]
        curve_y = [start_pos[1], start_pos[1] + 1, end_pos[1] - 1, end_pos[1]]
    else:
        curve_x = [start_pos[0], end_pos[0]]
        curve_y = [start_pos[1], end_pos[1]]
    
    fig.add_trace(go.Scatter(
        x=curve_x,
        y=curve_y,
        mode='lines',
        line=dict(color=color, width=2, dash='dot'),
        showlegend=False,
        hoverinfo='skip'
    ))

# Add YES labels for main decision paths
yes_labels = [
    ('role_decision', 'region_loop', 'YES'),
    ('ec2_decision', 'get_ssm', 'YES'),
    ('send_email', 'success', 'SUCCESS')
]

for start_id, end_id, label in yes_labels:
    start_pos = positions[start_id]
    end_pos = positions[end_id]
    mid_x = (start_pos[0] + end_pos[0]) / 2
    mid_y = (start_pos[1] + end_pos[1]) / 2
    
    fig.add_annotation(
        x=mid_x,
        y=mid_y,
        text=f"<b>{label}</b>",
        showarrow=False,
        font=dict(size=12, color='#2E8B57'),
        bgcolor='white',
        bordercolor='#2E8B57',
        borderwidth=2
    )

# Update layout with better spacing
fig.update_layout(
    title='Patch Compliance Lambda Workflow',
    showlegend=True,
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.02,
        xanchor='center',
        x=0.5
    ),
    xaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[-5, 5]
    ),
    yaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[-2, 11]
    ),
    plot_bgcolor='white',
    paper_bgcolor='white'
)

# Save the chart
fig.write_image('patch_compliance_workflow.png')