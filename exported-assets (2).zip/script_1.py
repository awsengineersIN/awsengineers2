# Let's create CloudFormation/CDK templates for deploying the infrastructure

# CloudFormation template for the Lambda function and EventBridge rule
cloudformation_template = '''
AWSTemplateFormatVersion: '2010-09-09'
Description: 'AWS Patch Compliance Reporting Lambda with EventBridge Scheduled Rule'

Parameters:
  CrossAccountRoleName:
    Type: String
    Default: PatchComplianceRole
    Description: Name of the cross-account role in member accounts
  
  SenderEmail:
    Type: String
    Description: Email address for sending reports (must be verified in SES)
  
  RecipientEmails:
    Type: CommaDelimitedList
    Description: List of email addresses to receive the patch compliance report
  
  ScheduleExpression:
    Type: String
    Default: 'cron(0 9 * * MON ?)'
    Description: Schedule expression for when to run the report (default: Monday 9 AM UTC)

Resources:
  # IAM Role for Lambda function
  PatchComplianceLambdaRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: PatchComplianceLambdaRole
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
          - Effect: Allow
            Principal:
              Service: lambda.amazonaws.com
            Action: sts:AssumeRole
      ManagedPolicyArns:
        - arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole
      Policies:
        - PolicyName: PatchCompliancePolicy
          PolicyDocument:
            Version: '2012-10-17'
            Statement:
              - Effect: Allow
                Action:
                  - organizations:ListAccounts
                  - organizations:DescribeOrganization
                Resource: '*'
              - Effect: Allow
                Action:
                  - sts:AssumeRole
                Resource: 
                  - !Sub 'arn:aws:iam::*:role/${CrossAccountRoleName}'
              - Effect: Allow
                Action:
                  - ses:SendEmail
                  - ses:SendRawEmail
                Resource: '*'
              - Effect: Allow
                Action:
                  - logs:CreateLogGroup
                  - logs:CreateLogStream
                  - logs:PutLogEvents
                Resource: '*'

  # Lambda function
  PatchComplianceLambda:
    Type: AWS::Lambda::Function
    Properties:
      FunctionName: PatchComplianceReporter
      Runtime: python3.11
      Handler: index.lambda_handler
      Role: !GetAtt PatchComplianceLambdaRole.Arn
      Timeout: 900
      MemorySize: 1024
      Environment:
        Variables:
          CROSS_ACCOUNT_ROLE_NAME: !Ref CrossAccountRoleName
          SENDER_EMAIL: !Ref SenderEmail
          RECIPIENT_EMAILS: !Join [',', !Ref RecipientEmails]
      Code:
        ZipFile: |
          # Lambda function code will be deployed separately
          import json
          def lambda_handler(event, context):
              return {
                  'statusCode': 200,
                  'body': json.dumps('Function placeholder - deploy actual code')
              }

  # EventBridge Rule for scheduling
  PatchComplianceScheduleRule:
    Type: AWS::Events::Rule
    Properties:
      Name: PatchComplianceScheduleRule
      Description: 'Scheduled rule to trigger patch compliance reporting'
      ScheduleExpression: !Ref ScheduleExpression
      State: ENABLED
      Targets:
        - Arn: !GetAtt PatchComplianceLambda.Arn
          Id: PatchComplianceLambdaTarget

  # Permission for EventBridge to invoke Lambda
  LambdaInvokePermission:
    Type: AWS::Lambda::Permission
    Properties:
      FunctionName: !Ref PatchComplianceLambda
      Action: lambda:InvokeFunction
      Principal: events.amazonaws.com
      SourceArn: !GetAtt PatchComplianceScheduleRule.Arn

Outputs:
  LambdaFunctionArn:
    Description: 'ARN of the patch compliance Lambda function'
    Value: !GetAtt PatchComplianceLambda.Arn
    Export:
      Name: !Sub '${AWS::StackName}-LambdaArn'
  
  EventBridgeRuleArn:
    Description: 'ARN of the EventBridge rule'
    Value: !GetAtt PatchComplianceScheduleRule.Arn
    Export:
      Name: !Sub '${AWS::StackName}-RuleArn'
  
  CrossAccountRoleName:
    Description: 'Name of the cross-account role to create in member accounts'
    Value: !Ref CrossAccountRoleName
    Export:
      Name: !Sub '${AWS::StackName}-CrossAccountRole'
'''

# Save CloudFormation template
with open('patch-compliance-reporting-stack.yaml', 'w') as f:
    f.write(cloudformation_template)

print("CloudFormation template saved to 'patch-compliance-reporting-stack.yaml'")

# CDK template for TypeScript
cdk_template = '''
import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import { Construct } from 'constructs';

export interface PatchComplianceStackProps extends cdk.StackProps {
  crossAccountRoleName: string;
  senderEmail: string;
  recipientEmails: string[];
  scheduleExpression?: string;
}

export class PatchComplianceStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: PatchComplianceStackProps) {
    super(scope, id, props);

    // IAM Role for Lambda function
    const lambdaRole = new iam.Role(this, 'PatchComplianceLambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole')
      ],
      inlinePolicies: {
        PatchCompliancePolicy: new iam.PolicyDocument({
          statements: [
            new iam.PolicyStatement({
              effect: iam.Effect.ALLOW,
              actions: [
                'organizations:ListAccounts',
                'organizations:DescribeOrganization'
              ],
              resources: ['*']
            }),
            new iam.PolicyStatement({
              effect: iam.Effect.ALLOW,
              actions: ['sts:AssumeRole'],
              resources: [`arn:aws:iam::*:role/${props.crossAccountRoleName}`]
            }),
            new iam.PolicyStatement({
              effect: iam.Effect.ALLOW,
              actions: [
                'ses:SendEmail',
                'ses:SendRawEmail'
              ],
              resources: ['*']
            })
          ]
        })
      }
    });

    // Lambda function
    const patchComplianceLambda = new lambda.Function(this, 'PatchComplianceLambda', {
      functionName: 'PatchComplianceReporter',
      runtime: lambda.Runtime.PYTHON_3_11,
      handler: 'index.lambda_handler',
      role: lambdaRole,
      timeout: cdk.Duration.minutes(15),
      memorySize: 1024,
      environment: {
        CROSS_ACCOUNT_ROLE_NAME: props.crossAccountRoleName,
        SENDER_EMAIL: props.senderEmail,
        RECIPIENT_EMAILS: props.recipientEmails.join(',')
      },
      code: lambda.Code.fromAsset('lambda-code') // Directory containing your Lambda code
    });

    // EventBridge Rule for scheduling
    const scheduleRule = new events.Rule(this, 'PatchComplianceScheduleRule', {
      ruleName: 'PatchComplianceScheduleRule',
      description: 'Scheduled rule to trigger patch compliance reporting',
      schedule: events.Schedule.expression(props.scheduleExpression || 'cron(0 9 * * MON ?)'),
      enabled: true
    });

    // Add Lambda as target
    scheduleRule.addTarget(new targets.LambdaFunction(patchComplianceLambda));

    // Outputs
    new cdk.CfnOutput(this, 'LambdaFunctionArn', {
      value: patchComplianceLambda.functionArn,
      description: 'ARN of the patch compliance Lambda function',
      exportName: `${this.stackName}-LambdaArn`
    });

    new cdk.CfnOutput(this, 'EventBridgeRuleArn', {
      value: scheduleRule.ruleArn,
      description: 'ARN of the EventBridge rule',
      exportName: `${this.stackName}-RuleArn`
    });

    new cdk.CfnOutput(this, 'CrossAccountRoleName', {
      value: props.crossAccountRoleName,
      description: 'Name of the cross-account role to create in member accounts',
      exportName: `${this.stackName}-CrossAccountRole`
    });
  }
}

// Usage example
const app = new cdk.App();
new PatchComplianceStack(app, 'PatchComplianceStack', {
  crossAccountRoleName: 'PatchComplianceRole',
  senderEmail: 'reports@yourcompany.com',
  recipientEmails: ['admin@yourcompany.com', 'security@yourcompany.com'],
  scheduleExpression: 'cron(0 9 * * MON ?)', // Every Monday at 9 AM UTC
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION,
  },
});
'''

# Save CDK template
with open('patch-compliance-cdk-stack.ts', 'w') as f:
    f.write(cdk_template)

print("CDK template saved to 'patch-compliance-cdk-stack.ts'")

# Cross-account role template
cross_account_role_template = '''
AWSTemplateFormatVersion: '2010-09-09'
Description: 'Cross-account role for patch compliance reporting in member accounts'

Parameters:
  ManagementAccountId:
    Type: String
    Description: AWS Account ID of the management account
  
  CrossAccountRoleName:
    Type: String
    Default: PatchComplianceRole
    Description: Name of the cross-account role

Resources:
  PatchComplianceRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: !Ref CrossAccountRoleName
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
          - Effect: Allow
            Principal:
              AWS: !Sub 'arn:aws:iam::${ManagementAccountId}:role/PatchComplianceLambdaRole'
            Action: sts:AssumeRole
            Condition:
              StringEquals:
                'sts:ExternalId': 'PatchComplianceReporting'
      Policies:
        - PolicyName: PatchComplianceReadOnlyPolicy
          PolicyDocument:
            Version: '2012-10-17'
            Statement:
              - Effect: Allow
                Action:
                  - ec2:DescribeInstances
                  - ec2:DescribeInstanceStatus
                  - ec2:DescribeRegions
                Resource: '*'
              - Effect: Allow
                Action:
                  - ssm:DescribeInstanceInformation
                  - ssm:DescribeInstancePatchStates
                  - ssm:DescribeInstancePatches
                  - ssm:ListComplianceItems
                  - ssm:ListInventoryEntries
                  - ssm:GetInventory
                  - ssm:DescribePatchBaselines
                  - ssm:DescribePatchGroups
                Resource: '*'
              - Effect: Allow
                Action:
                  - tag:GetResources
                Resource: '*'

Outputs:
  CrossAccountRoleArn:
    Description: 'ARN of the cross-account role'
    Value: !GetAtt PatchComplianceRole.Arn
    Export:
      Name: !Sub '${AWS::StackName}-CrossAccountRoleArn'
'''

# Save cross-account role template
with open('cross-account-role-template.yaml', 'w') as f:
    f.write(cross_account_role_template)

print("Cross-account role template saved to 'cross-account-role-template.yaml'")

print("\\nAll infrastructure templates have been generated successfully!")
print("\\nFiles created:")
print("1. patch_compliance_lambda.py - Lambda function code")
print("2. patch-compliance-reporting-stack.yaml - CloudFormation template for management account")
print("3. patch-compliance-cdk-stack.ts - CDK template (TypeScript)")
print("4. cross-account-role-template.yaml - CloudFormation template for member accounts")