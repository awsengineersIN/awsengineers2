# Create deployment guide and best practices document

deployment_guide = '''# AWS Multi-Account Patch Compliance Reporting Solution

## Deployment Guide and Best Practices

### Overview
This solution provides automated patch compliance reporting across a multi-account, multi-region AWS Organization. The solution uses an event-driven Lambda function that iterates through all organization accounts, assumes cross-account roles, and collects patch compliance data from AWS Systems Manager.

### Architecture Components

1. **Management Account**: Central Lambda function that orchestrates the reporting
2. **Member Accounts**: Cross-account IAM roles for read-only access to EC2 and SSM data
3. **EventBridge Rule**: Scheduled trigger for the Lambda function
4. **SES**: Email service for sending HTML reports

### Prerequisites

#### Management Account Setup
1. **AWS Organizations**: Must be set up with all target accounts as members
2. **SES Configuration**: Verify sender email address in Amazon SES
3. **Lambda Execution Role**: Role with permissions to:
   - List organization accounts
   - Assume roles in member accounts
   - Send emails via SES

#### Member Account Setup
1. **Cross-Account Role**: Each member account needs the same named role
2. **Trust Relationship**: Role must trust the management account's Lambda execution role
3. **Read-Only Permissions**: Role needs permissions for EC2 and SSM read operations

### Deployment Steps

#### Step 1: Deploy Cross-Account Roles (All Member Accounts)
```bash
# Deploy to all member accounts using StackSets or individually
aws cloudformation create-stack \\
  --stack-name patch-compliance-cross-account-role \\
  --template-body file://cross-account-role-template.yaml \\
  --parameters ParameterKey=ManagementAccountId,ParameterValue=123456789012 \\
  --capabilities CAPABILITY_NAMED_IAM \\
  --region us-east-1
```

#### Step 2: Deploy Lambda Function (Management Account)
```bash
# Deploy the main reporting infrastructure
aws cloudformation create-stack \\
  --stack-name patch-compliance-reporting \\
  --template-body file://patch-compliance-reporting-stack.yaml \\
  --parameters \\
    ParameterKey=SenderEmail,ParameterValue=reports@yourcompany.com \\
    ParameterKey=RecipientEmails,ParameterValue="admin@yourcompany.com,security@yourcompany.com" \\
    ParameterKey=ScheduleExpression,ParameterValue="cron(0 9 * * MON ?)" \\
  --capabilities CAPABILITY_NAMED_IAM \\
  --region us-east-1
```

#### Step 3: Deploy Lambda Code
```bash
# Create deployment package
zip -r patch-compliance-lambda.zip patch_compliance_lambda.py

# Update Lambda function code
aws lambda update-function-code \\
  --function-name PatchComplianceReporter \\
  --zip-file fileb://patch-compliance-lambda.zip \\
  --region us-east-1
```

### Configuration Options

#### EventBridge Schedule Expressions
- **Daily**: `cron(0 9 * * ? *)` - Every day at 9 AM UTC
- **Weekly**: `cron(0 9 * * MON ?)` - Every Monday at 9 AM UTC
- **Monthly**: `cron(0 9 1 * ? *)` - First day of every month at 9 AM UTC

#### Email Configuration
```python
# Environment variables for Lambda function
CROSS_ACCOUNT_ROLE_NAME = "PatchComplianceRole"
SENDER_EMAIL = "reports@yourcompany.com"
RECIPIENT_EMAILS = "admin@yourcompany.com,security@yourcompany.com"
```

### Best Practices

#### Security
1. **Least Privilege**: Cross-account roles have only read permissions needed for reporting
2. **External ID**: Use external ID in trust relationships for additional security
3. **Role Naming**: Use consistent role naming across all accounts
4. **Session Names**: Use descriptive role session names for auditing

#### Performance
1. **Batch Processing**: Process EC2 instances in batches to avoid API throttling
2. **Parallel Execution**: Consider parallel processing for large organizations
3. **Timeout Configuration**: Set appropriate Lambda timeout (15 minutes max)
4. **Memory Allocation**: Allocate sufficient memory for large datasets

#### Monitoring
1. **CloudWatch Logs**: Monitor Lambda execution logs for errors
2. **CloudWatch Metrics**: Set up custom metrics for success/failure rates
3. **SNS Alerts**: Configure SNS notifications for Lambda failures
4. **Cost Monitoring**: Track Lambda execution costs and optimize

#### Error Handling
1. **Retry Logic**: Implement exponential backoff for API calls
2. **Partial Failures**: Continue processing other accounts if one fails
3. **Error Notifications**: Send alert emails for critical failures
4. **Graceful Degradation**: Handle accounts with insufficient permissions

### Troubleshooting

#### Common Issues
1. **AssumeRole Failures**:
   - Check trust relationships in member accounts
   - Verify role ARN format
   - Ensure external ID matches if used

2. **API Throttling**:
   - Implement exponential backoff
   - Reduce batch sizes
   - Add delays between API calls

3. **No Data Retrieved**:
   - Verify EC2 instances exist in target regions
   - Check SSM agent installation on instances
   - Ensure patch baselines are configured

4. **Email Delivery Issues**:
   - Verify SES email addresses are verified
   - Check SES sending limits
   - Review email bounce/complaint rates

### Customization

#### Adding New Regions
```python
# Update the regions list in Lambda function
self.regions = ['us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1']
```

#### Custom Metrics
```python
# Add custom compliance metrics
def calculate_custom_metrics(self, compliance_data):
    # Implement custom business logic
    return custom_metrics
```

#### Report Formatting
```python
# Customize HTML email template
def generate_html_report(self, compliance_data):
    # Modify HTML template with company branding
    # Add custom charts or visualizations
    return html_content
```

### Testing

#### Unit Testing
```bash
# Run unit tests for Lambda function
python -m pytest tests/test_patch_compliance.py
```

#### Integration Testing
```bash
# Test cross-account role assumption
aws sts assume-role \\
  --role-arn arn:aws:iam::ACCOUNT-ID:role/PatchComplianceRole \\
  --role-session-name testing
```

#### End-to-End Testing
1. Trigger Lambda function manually
2. Verify email delivery
3. Check report accuracy
4. Test error scenarios

### Maintenance

#### Regular Tasks
1. **Update Lambda runtime**: Keep Python runtime up to date
2. **Review IAM permissions**: Ensure least privilege access
3. **Monitor costs**: Track and optimize Lambda execution costs
4. **Update email lists**: Keep recipient lists current

#### Scaling Considerations
1. **Large Organizations**: Consider breaking into multiple Lambda functions
2. **Parallel Processing**: Use Step Functions for orchestration
3. **Data Storage**: Store historical data in S3 or DynamoDB
4. **Reporting Dashboard**: Build QuickSight dashboard for visualization

### Security Considerations

#### Data Protection
1. **Encryption**: Encrypt data in transit and at rest
2. **Access Logging**: Enable CloudTrail for all API calls
3. **Data Retention**: Define retention policies for reports
4. **Compliance**: Ensure solution meets regulatory requirements

#### Network Security
1. **VPC Endpoints**: Use VPC endpoints for AWS service calls
2. **Network ACLs**: Restrict network access where possible
3. **Security Groups**: Configure appropriate security group rules
4. **NAT Gateways**: Route Lambda traffic through NAT gateways if required

### Cost Optimization

#### Lambda Optimization
1. **Memory Allocation**: Right-size memory allocation
2. **Execution Time**: Optimize code for faster execution
3. **Scheduling**: Adjust schedule based on business needs
4. **Reserved Capacity**: Consider reserved capacity for high-frequency execution

#### AWS Service Costs
1. **API Calls**: Minimize unnecessary API calls
2. **Data Transfer**: Optimize data transfer costs
3. **SES Usage**: Monitor email sending costs
4. **CloudWatch Logs**: Set appropriate log retention periods

### Disaster Recovery

#### Backup Strategy
1. **Code Backup**: Store Lambda code in version control
2. **Configuration Backup**: Export CloudFormation templates
3. **Data Backup**: Backup historical reports if stored
4. **Cross-Region**: Consider cross-region deployment for HA

#### Recovery Procedures
1. **Lambda Function**: Redeploy from CloudFormation templates
2. **IAM Roles**: Recreate roles using stored templates
3. **Configuration**: Restore environment variables and settings
4. **Testing**: Validate recovery procedures regularly

This deployment guide provides a comprehensive approach to implementing the AWS multi-account patch compliance reporting solution. Follow these steps and best practices to ensure a successful deployment and ongoing operation.
'''

# Save deployment guide
with open('deployment-guide.md', 'w') as f:
    f.write(deployment_guide)

print("Deployment guide saved to 'deployment-guide.md'")

# Create a sample SES email template configuration
ses_template = '''# SES Email Template Configuration for Patch Compliance Reports

## HTML Template for Patch Compliance Report

This document shows how to create a reusable SES email template for patch compliance reports.

### Create SES Template (AWS CLI)

```bash
aws ses create-template --region us-east-1 --template '{
  "TemplateName": "PatchComplianceReport",
  "TemplateData": {
    "Subject": "AWS Patch Compliance Report - {{reportDate}}",
    "HtmlPart": "<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #232F3E; color: white; padding: 20px; }
        .summary { background-color: #f8f9fa; padding: 15px; margin: 20px 0; }
        .critical { color: #dc3545; font-weight: bold; }
        .compliant { color: #28a745; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class=\"header\">
        <h1>AWS Patch Compliance Report</h1>
        <p>Generated: {{reportDate}}</p>
        <p>Organization: {{organizationName}}</p>
    </div>
    
    <div class=\"summary\">
        <h2>Executive Summary</h2>
        <p><strong>Total Instances:</strong> {{totalInstances}}</p>
        <p><strong>Compliant:</strong> <span class=\"compliant\">{{compliantCount}} ({{compliantPercentage}}%)</span></p>
        <p><strong>Critical Non-compliant:</strong> <span class=\"critical\">{{criticalCount}} ({{criticalPercentage}}%)</span></p>
    </div>
    
    <h2>Account Details</h2>
    {{#accountData}}
    <h3>{{accountName}} ({{accountId}})</h3>
    <table>
        <tr>
            <th>Region</th>
            <th>EC2 Instances</th>
            <th>SSM Managed</th>
            <th>Compliant</th>
            <th>Critical Issues</th>
        </tr>
        {{#regions}}
        <tr>
            <td>{{regionName}}</td>
            <td>{{totalEc2}}</td>
            <td>{{ssmManaged}}</td>
            <td class=\"compliant\">{{compliantCount}}</td>
            <td class=\"critical\">{{criticalCount}}</td>
        </tr>
        {{/regions}}
    </table>
    {{/accountData}}
</body>
</html>",
    "TextPart": "AWS Patch Compliance Report - {{reportDate}}

Executive Summary:
- Total Instances: {{totalInstances}}
- Compliant: {{compliantCount}} ({{compliantPercentage}}%)
- Critical Non-compliant: {{criticalCount}} ({{criticalPercentage}}%)

{{#accountData}}
Account: {{accountName}} ({{accountId}})
{{#regions}}
- {{regionName}}: {{totalEc2}} instances, {{ssmManaged}} managed, {{compliantCount}} compliant
{{/regions}}
{{/accountData}}"
  }
}'
```

### Using the Template in Lambda

```python
import boto3
import json
from datetime import datetime

def send_templated_email(compliance_data):
    ses_client = boto3.client('ses', region_name='us-east-1')
    
    # Prepare template data
    template_data = {
        "reportDate": datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC"),
        "organizationName": "Your Organization",
        "totalInstances": str(compliance_data['organization_summary']['total_instances']),
        "compliantCount": str(compliance_data['organization_summary']['compliant_count']),
        "compliantPercentage": str(compliance_data['organization_summary']['compliance_percentage']),
        "criticalCount": str(compliance_data['organization_summary']['critical_noncompliant_count']),
        "criticalPercentage": str(compliance_data['organization_summary']['critical_noncompliant_percentage']),
        "accountData": []
    }
    
    # Add account data
    for account_id, account_data in compliance_data['accounts'].items():
        account_info = {
            "accountName": account_data['account_name'],
            "accountId": account_id,
            "regions": []
        }
        
        for region, region_data in account_data['regions'].items():
            region_info = {
                "regionName": region,
                "totalEc2": str(region_data['total_ec2_instances']),
                "ssmManaged": str(region_data['ssm_managed_count']),
                "compliantCount": str(region_data['compliance_summary']['compliant_count']),
                "criticalCount": str(region_data['compliance_summary']['critical_noncompliant_count'])
            }
            account_info['regions'].append(region_info)
        
        template_data['accountData'].append(account_info)
    
    # Send templated email
    response = ses_client.send_templated_email(
        Source='reports@yourcompany.com',
        Destination={
            'ToAddresses': ['admin@yourcompany.com', 'security@yourcompany.com']
        },
        Template='PatchComplianceReport',
        TemplateData=json.dumps(template_data)
    )
    
    return response
```

### Managing Templates

#### Update Template
```bash
aws ses update-template --region us-east-1 --template '{
  "TemplateName": "PatchComplianceReport",
  "TemplateData": {
    "Subject": "Updated AWS Patch Compliance Report - {{reportDate}}",
    "HtmlPart": "<!-- Updated HTML content -->",
    "TextPart": "<!-- Updated text content -->"
  }
}'
```

#### Delete Template
```bash
aws ses delete-template --region us-east-1 --template-name PatchComplianceReport
```

#### List Templates
```bash
aws ses list-templates --region us-east-1
```

This approach provides a cleaner separation between code and email formatting, making it easier to maintain and update email templates without modifying the Lambda function code.
'''

# Save SES template guide
with open('ses-email-template-guide.md', 'w') as f:
    f.write(ses_template)

print("SES email template guide saved to 'ses-email-template-guide.md'")

print("\\nAll documentation and templates have been created successfully!")
print("\\nFiles created:")
print("1. patch_compliance_lambda.py - Lambda function code")
print("2. patch-compliance-reporting-stack.yaml - CloudFormation template for management account")
print("3. patch-compliance-cdk-stack.ts - CDK template (TypeScript)")
print("4. cross-account-role-template.yaml - CloudFormation template for member accounts")
print("5. deployment-guide.md - Comprehensive deployment guide and best practices")
print("6. ses-email-template-guide.md - SES email template configuration guide")