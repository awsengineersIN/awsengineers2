
import * as cdk from 'aws-cdk-lib';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import { Construct } from 'constructs';

export interface PatchComplianceStackProps extends cdk.StackProps {
  crossAccountRoleName: string;
  senderEmail: string;
  recipientEmails: string[];
  scheduleExpression?: string;
}

export class PatchComplianceStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: PatchComplianceStackProps) {
    super(scope, id, props);

    // IAM Role for Lambda function
    const lambdaRole = new iam.Role(this, 'PatchComplianceLambdaRole', {
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole')
      ],
      inlinePolicies: {
        PatchCompliancePolicy: new iam.PolicyDocument({
          statements: [
            new iam.PolicyStatement({
              effect: iam.Effect.ALLOW,
              actions: [
                'organizations:ListAccounts',
                'organizations:DescribeOrganization'
              ],
              resources: ['*']
            }),
            new iam.PolicyStatement({
              effect: iam.Effect.ALLOW,
              actions: ['sts:AssumeRole'],
              resources: [`arn:aws:iam::*:role/${props.crossAccountRoleName}`]
            }),
            new iam.PolicyStatement({
              effect: iam.Effect.ALLOW,
              actions: [
                'ses:SendEmail',
                'ses:SendRawEmail'
              ],
              resources: ['*']
            })
          ]
        })
      }
    });

    // Lambda function
    const patchComplianceLambda = new lambda.Function(this, 'PatchComplianceLambda', {
      functionName: 'PatchComplianceReporter',
      runtime: lambda.Runtime.PYTHON_3_11,
      handler: 'index.lambda_handler',
      role: lambdaRole,
      timeout: cdk.Duration.minutes(15),
      memorySize: 1024,
      environment: {
        CROSS_ACCOUNT_ROLE_NAME: props.crossAccountRoleName,
        SENDER_EMAIL: props.senderEmail,
        RECIPIENT_EMAILS: props.recipientEmails.join(',')
      },
      code: lambda.Code.fromAsset('lambda-code') // Directory containing your Lambda code
    });

    // EventBridge Rule for scheduling
    const scheduleRule = new events.Rule(this, 'PatchComplianceScheduleRule', {
      ruleName: 'PatchComplianceScheduleRule',
      description: 'Scheduled rule to trigger patch compliance reporting',
      schedule: events.Schedule.expression(props.scheduleExpression || 'cron(0 9 * * MON ?)'),
      enabled: true
    });

    // Add Lambda as target
    scheduleRule.addTarget(new targets.LambdaFunction(patchComplianceLambda));

    // Outputs
    new cdk.CfnOutput(this, 'LambdaFunctionArn', {
      value: patchComplianceLambda.functionArn,
      description: 'ARN of the patch compliance Lambda function',
      exportName: `${this.stackName}-LambdaArn`
    });

    new cdk.CfnOutput(this, 'EventBridgeRuleArn', {
      value: scheduleRule.ruleArn,
      description: 'ARN of the EventBridge rule',
      exportName: `${this.stackName}-RuleArn`
    });

    new cdk.CfnOutput(this, 'CrossAccountRoleName', {
      value: props.crossAccountRoleName,
      description: 'Name of the cross-account role to create in member accounts',
      exportName: `${this.stackName}-CrossAccountRole`
    });
  }
}

// Usage example
const app = new cdk.App();
new PatchComplianceStack(app, 'PatchComplianceStack', {
  crossAccountRoleName: 'PatchComplianceRole',
  senderEmail: 'reports@yourcompany.com',
  recipientEmails: ['admin@yourcompany.com', 'security@yourcompany.com'],
  scheduleExpression: 'cron(0 9 * * MON ?)', // Every Monday at 9 AM UTC
  env: {
    account: process.env.CDK_DEFAULT_ACCOUNT,
    region: process.env.CDK_DEFAULT_REGION,
  },
});
