# AWS Multi-Account Patch Compliance Reporting Solution

## Deployment Guide and Best Practices

### Overview
This solution provides automated patch compliance reporting across a multi-account, multi-region AWS Organization. The solution uses an event-driven Lambda function that iterates through all organization accounts, assumes cross-account roles, and collects patch compliance data from AWS Systems Manager.

### Architecture Components

1. **Management Account**: Central Lambda function that orchestrates the reporting
2. **Member Accounts**: Cross-account IAM roles for read-only access to EC2 and SSM data
3. **EventBridge Rule**: Scheduled trigger for the Lambda function
4. **SES**: Email service for sending HTML reports

### Prerequisites

#### Management Account Setup
1. **AWS Organizations**: Must be set up with all target accounts as members
2. **SES Configuration**: Verify sender email address in Amazon SES
3. **Lambda Execution Role**: Role with permissions to:
   - List organization accounts
   - Assume roles in member accounts
   - Send emails via SES

#### Member Account Setup
1. **Cross-Account Role**: Each member account needs the same named role
2. **Trust Relationship**: Role must trust the management account's Lambda execution role
3. **Read-Only Permissions**: Role needs permissions for EC2 and SSM read operations

### Deployment Steps

#### Step 1: Deploy Cross-Account Roles (All Member Accounts)
```bash
# Deploy to all member accounts using StackSets or individually
aws cloudformation create-stack \
  --stack-name patch-compliance-cross-account-role \
  --template-body file://cross-account-role-template.yaml \
  --parameters ParameterKey=ManagementAccountId,ParameterValue=123456789012 \
  --capabilities CAPABILITY_NAMED_IAM \
  --region us-east-1
```

#### Step 2: Deploy Lambda Function (Management Account)
```bash
# Deploy the main reporting infrastructure
aws cloudformation create-stack \
  --stack-name patch-compliance-reporting \
  --template-body file://patch-compliance-reporting-stack.yaml \
  --parameters \
    ParameterKey=SenderEmail,ParameterValue=reports@yourcompany.com \
    ParameterKey=RecipientEmails,ParameterValue="admin@yourcompany.com,security@yourcompany.com" \
    ParameterKey=ScheduleExpression,ParameterValue="cron(0 9 * * MON ?)" \
  --capabilities CAPABILITY_NAMED_IAM \
  --region us-east-1
```

#### Step 3: Deploy Lambda Code
```bash
# Create deployment package
zip -r patch-compliance-lambda.zip patch_compliance_lambda.py

# Update Lambda function code
aws lambda update-function-code \
  --function-name PatchComplianceReporter \
  --zip-file fileb://patch-compliance-lambda.zip \
  --region us-east-1
```

### Configuration Options

#### EventBridge Schedule Expressions
- **Daily**: `cron(0 9 * * ? *)` - Every day at 9 AM UTC
- **Weekly**: `cron(0 9 * * MON ?)` - Every Monday at 9 AM UTC
- **Monthly**: `cron(0 9 1 * ? *)` - First day of every month at 9 AM UTC

#### Email Configuration
```python
# Environment variables for Lambda function
CROSS_ACCOUNT_ROLE_NAME = "PatchComplianceRole"
SENDER_EMAIL = "reports@yourcompany.com"
RECIPIENT_EMAILS = "admin@yourcompany.com,security@yourcompany.com"
```

### Best Practices

#### Security
1. **Least Privilege**: Cross-account roles have only read permissions needed for reporting
2. **External ID**: Use external ID in trust relationships for additional security
3. **Role Naming**: Use consistent role naming across all accounts
4. **Session Names**: Use descriptive role session names for auditing

#### Performance
1. **Batch Processing**: Process EC2 instances in batches to avoid API throttling
2. **Parallel Execution**: Consider parallel processing for large organizations
3. **Timeout Configuration**: Set appropriate Lambda timeout (15 minutes max)
4. **Memory Allocation**: Allocate sufficient memory for large datasets

#### Monitoring
1. **CloudWatch Logs**: Monitor Lambda execution logs for errors
2. **CloudWatch Metrics**: Set up custom metrics for success/failure rates
3. **SNS Alerts**: Configure SNS notifications for Lambda failures
4. **Cost Monitoring**: Track Lambda execution costs and optimize

#### Error Handling
1. **Retry Logic**: Implement exponential backoff for API calls
2. **Partial Failures**: Continue processing other accounts if one fails
3. **Error Notifications**: Send alert emails for critical failures
4. **Graceful Degradation**: Handle accounts with insufficient permissions

### Troubleshooting

#### Common Issues
1. **AssumeRole Failures**:
   - Check trust relationships in member accounts
   - Verify role ARN format
   - Ensure external ID matches if used

2. **API Throttling**:
   - Implement exponential backoff
   - Reduce batch sizes
   - Add delays between API calls

3. **No Data Retrieved**:
   - Verify EC2 instances exist in target regions
   - Check SSM agent installation on instances
   - Ensure patch baselines are configured

4. **Email Delivery Issues**:
   - Verify SES email addresses are verified
   - Check SES sending limits
   - Review email bounce/complaint rates

### Customization

#### Adding New Regions
```python
# Update the regions list in Lambda function
self.regions = ['us-east-1', 'us-west-2', 'eu-west-1', 'ap-southeast-1']
```

#### Custom Metrics
```python
# Add custom compliance metrics
def calculate_custom_metrics(self, compliance_data):
    # Implement custom business logic
    return custom_metrics
```

#### Report Formatting
```python
# Customize HTML email template
def generate_html_report(self, compliance_data):
    # Modify HTML template with company branding
    # Add custom charts or visualizations
    return html_content
```

### Testing

#### Unit Testing
```bash
# Run unit tests for Lambda function
python -m pytest tests/test_patch_compliance.py
```

#### Integration Testing
```bash
# Test cross-account role assumption
aws sts assume-role \
  --role-arn arn:aws:iam::ACCOUNT-ID:role/PatchComplianceRole \
  --role-session-name testing
```

#### End-to-End Testing
1. Trigger Lambda function manually
2. Verify email delivery
3. Check report accuracy
4. Test error scenarios

### Maintenance

#### Regular Tasks
1. **Update Lambda runtime**: Keep Python runtime up to date
2. **Review IAM permissions**: Ensure least privilege access
3. **Monitor costs**: Track and optimize Lambda execution costs
4. **Update email lists**: Keep recipient lists current

#### Scaling Considerations
1. **Large Organizations**: Consider breaking into multiple Lambda functions
2. **Parallel Processing**: Use Step Functions for orchestration
3. **Data Storage**: Store historical data in S3 or DynamoDB
4. **Reporting Dashboard**: Build QuickSight dashboard for visualization

### Security Considerations

#### Data Protection
1. **Encryption**: Encrypt data in transit and at rest
2. **Access Logging**: Enable CloudTrail for all API calls
3. **Data Retention**: Define retention policies for reports
4. **Compliance**: Ensure solution meets regulatory requirements

#### Network Security
1. **VPC Endpoints**: Use VPC endpoints for AWS service calls
2. **Network ACLs**: Restrict network access where possible
3. **Security Groups**: Configure appropriate security group rules
4. **NAT Gateways**: Route Lambda traffic through NAT gateways if required

### Cost Optimization

#### Lambda Optimization
1. **Memory Allocation**: Right-size memory allocation
2. **Execution Time**: Optimize code for faster execution
3. **Scheduling**: Adjust schedule based on business needs
4. **Reserved Capacity**: Consider reserved capacity for high-frequency execution

#### AWS Service Costs
1. **API Calls**: Minimize unnecessary API calls
2. **Data Transfer**: Optimize data transfer costs
3. **SES Usage**: Monitor email sending costs
4. **CloudWatch Logs**: Set appropriate log retention periods

### Disaster Recovery

#### Backup Strategy
1. **Code Backup**: Store Lambda code in version control
2. **Configuration Backup**: Export CloudFormation templates
3. **Data Backup**: Backup historical reports if stored
4. **Cross-Region**: Consider cross-region deployment for HA

#### Recovery Procedures
1. **Lambda Function**: Redeploy from CloudFormation templates
2. **IAM Roles**: Recreate roles using stored templates
3. **Configuration**: Restore environment variables and settings
4. **Testing**: Validate recovery procedures regularly

This deployment guide provides a comprehensive approach to implementing the AWS multi-account patch compliance reporting solution. Follow these steps and best practices to ensure a successful deployment and ongoing operation.
