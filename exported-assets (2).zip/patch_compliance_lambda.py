
import boto3
import json
import os
from datetime import datetime, timezone
from typing import Dict, List, Tuple, Any
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

class PatchComplianceReporter:
    def __init__(self):
        # Initialize AWS clients
        self.organizations_client = boto3.client('organizations')
        self.sts_client = boto3.client('sts')

        # Configuration
        self.regions = ['us-east-1', 'us-west-2']
        self.cross_account_role_name = os.environ.get('CROSS_ACCOUNT_ROLE_NAME', 'PatchComplianceRole')
        self.sender_email = os.environ.get('SENDER_EMAIL')
        self.recipient_emails = os.environ.get('RECIPIENT_EMAILS', '').split(',')

        # Initialize SES module (assuming it's imported)
        # from ses_module import send_email

    def lambda_handler(self, event, context):
        """Main Lambda handler function"""
        try:
            logger.info("Starting patch compliance report generation")

            # Get all organization accounts
            accounts = self.get_organization_accounts()
            logger.info(f"Found {len(accounts)} accounts in organization")

            # Collect compliance data from all accounts and regions
            compliance_data = self.collect_compliance_data(accounts)

            # Generate and send email report
            self.generate_and_send_report(compliance_data)

            return {
                'statusCode': 200,
                'body': json.dumps('Patch compliance report generated successfully')
            }

        except Exception as e:
            logger.error(f"Error in lambda_handler: {str(e)}")
            raise

    def get_organization_accounts(self) -> List[Dict]:
        """Get all accounts in the AWS Organization"""
        accounts = []
        paginator = self.organizations_client.get_paginator('list_accounts')

        for page in paginator.paginate():
            for account in page['Accounts']:
                if account['Status'] == 'ACTIVE':
                    accounts.append({
                        'Id': account['Id'],
                        'Name': account['Name'],
                        'Email': account['Email']
                    })

        return accounts

    def assume_cross_account_role(self, account_id: str, region: str) -> boto3.Session:
        """Assume role in target account"""
        role_arn = f"arn:aws:iam::{account_id}:role/{self.cross_account_role_name}"

        try:
            response = self.sts_client.assume_role(
                RoleArn=role_arn,
                RoleSessionName=f"PatchCompliance-{account_id}-{region}"
            )

            credentials = response['Credentials']

            session = boto3.Session(
                aws_access_key_id=credentials['AccessKeyId'],
                aws_secret_access_key=credentials['SecretAccessKey'],
                aws_session_token=credentials['SessionToken'],
                region_name=region
            )

            return session

        except Exception as e:
            logger.error(f"Failed to assume role in account {account_id}: {str(e)}")
            return None

    def get_ec2_instances(self, session: boto3.Session) -> List[str]:
        """Get list of EC2 instances in the account/region"""
        try:
            ec2_client = session.client('ec2')
            response = ec2_client.describe_instances(
                Filters=[
                    {'Name': 'instance-state-name', 'Values': ['running', 'stopped']}
                ]
            )

            instances = []
            for reservation in response['Reservations']:
                for instance in reservation['Instances']:
                    instances.append(instance['InstanceId'])

            return instances

        except Exception as e:
            logger.error(f"Error getting EC2 instances: {str(e)}")
            return []

    def get_ssm_managed_instances(self, session: boto3.Session) -> List[str]:
        """Get list of SSM managed instances"""
        try:
            ssm_client = session.client('ssm')
            paginator = ssm_client.get_paginator('describe_instance_information')

            managed_instances = []
            for page in paginator.paginate():
                for instance in page['InstanceInformationList']:
                    managed_instances.append(instance['InstanceId'])

            return managed_instances

        except Exception as e:
            logger.error(f"Error getting SSM managed instances: {str(e)}")
            return []

    def get_patch_compliance_summary(self, session: boto3.Session, instances: List[str]) -> Dict:
        """Get patch compliance summary for instances"""
        if not instances:
            return self.get_empty_compliance_summary()

        try:
            ssm_client = session.client('ssm')

            # Get patch states for all instances
            patch_states = []
            for i in range(0, len(instances), 50):  # Process in batches of 50
                batch = instances[i:i+50]
                response = ssm_client.describe_instance_patch_states(
                    InstanceIds=batch
                )
                patch_states.extend(response['InstancePatchStates'])

            # Aggregate compliance data
            compliance_summary = {
                'total_instances': len(instances),
                'compliant_count': 0,
                'critical_noncompliant_count': 0,
                'high_noncompliant_count': 0,
                'other_noncompliant_count': 0,
                'missing_patches_count': 0,
                'failed_patches_count': 0,
                'pending_reboot_count': 0,
                'security_updates_count': 0,
                'compliance_percentage': 0,
                'critical_noncompliant_percentage': 0,
                'high_noncompliant_percentage': 0,
                'other_noncompliant_percentage': 0
            }

            for state in patch_states:
                # Check overall compliance
                if (state['MissingCount'] == 0 and 
                    state['FailedCount'] == 0 and 
                    state['CriticalNonCompliantCount'] == 0 and
                    state['SecurityNonCompliantCount'] == 0):
                    compliance_summary['compliant_count'] += 1

                # Count different types of non-compliance
                compliance_summary['critical_noncompliant_count'] += state.get('CriticalNonCompliantCount', 0)
                compliance_summary['other_noncompliant_count'] += state.get('OtherNonCompliantCount', 0)
                compliance_summary['missing_patches_count'] += state.get('MissingCount', 0)
                compliance_summary['failed_patches_count'] += state.get('FailedCount', 0)
                compliance_summary['pending_reboot_count'] += state.get('InstalledPendingRebootCount', 0)
                compliance_summary['security_updates_count'] += state.get('SecurityNonCompliantCount', 0)

            # Calculate percentages
            total = compliance_summary['total_instances']
            if total > 0:
                compliance_summary['compliance_percentage'] = round(
                    (compliance_summary['compliant_count'] / total) * 100, 2
                )
                compliance_summary['critical_noncompliant_percentage'] = round(
                    (compliance_summary['critical_noncompliant_count'] / total) * 100, 2
                )
                compliance_summary['other_noncompliant_percentage'] = round(
                    (compliance_summary['other_noncompliant_count'] / total) * 100, 2
                )

            return compliance_summary

        except Exception as e:
            logger.error(f"Error getting patch compliance summary: {str(e)}")
            return self.get_empty_compliance_summary()

    def get_empty_compliance_summary(self) -> Dict:
        """Return empty compliance summary structure"""
        return {
            'total_instances': 0,
            'compliant_count': 0,
            'critical_noncompliant_count': 0,
            'high_noncompliant_count': 0,
            'other_noncompliant_count': 0,
            'missing_patches_count': 0,
            'failed_patches_count': 0,
            'pending_reboot_count': 0,
            'security_updates_count': 0,
            'compliance_percentage': 0,
            'critical_noncompliant_percentage': 0,
            'high_noncompliant_percentage': 0,
            'other_noncompliant_percentage': 0
        }

    def collect_compliance_data(self, accounts: List[Dict]) -> Dict:
        """Collect patch compliance data from all accounts and regions"""
        all_data = {
            'accounts': {},
            'organization_summary': self.get_empty_compliance_summary()
        }

        org_totals = {
            'total_instances': 0,
            'ssm_managed_instances': 0,
            'compliant_count': 0,
            'critical_noncompliant_count': 0,
            'high_noncompliant_count': 0,
            'other_noncompliant_count': 0,
            'missing_patches_count': 0,
            'failed_patches_count': 0,
            'pending_reboot_count': 0,
            'security_updates_count': 0
        }

        for account in accounts:
            account_id = account['Id']
            account_name = account['Name']

            logger.info(f"Processing account: {account_name} ({account_id})")

            account_data = {
                'account_name': account_name,
                'regions': {}
            }

            for region in self.regions:
                logger.info(f"Processing region: {region}")

                # Assume role in target account
                session = self.assume_cross_account_role(account_id, region)
                if not session:
                    continue

                # Get EC2 instances
                ec2_instances = self.get_ec2_instances(session)
                if not ec2_instances:
                    logger.info(f"No EC2 instances found in {account_name} - {region}")
                    continue

                # Get SSM managed instances
                ssm_instances = self.get_ssm_managed_instances(session)

                # Calculate SSM management statistics
                total_ec2 = len(ec2_instances)
                ssm_managed = len(ssm_instances)
                ssm_not_managed = total_ec2 - ssm_managed

                ssm_managed_percentage = round((ssm_managed / total_ec2) * 100, 2) if total_ec2 > 0 else 0
                ssm_not_managed_percentage = round((ssm_not_managed / total_ec2) * 100, 2) if total_ec2 > 0 else 0

                # Get patch compliance for SSM managed instances
                compliance_summary = self.get_patch_compliance_summary(session, ssm_instances)

                region_data = {
                    'total_ec2_instances': total_ec2,
                    'ssm_managed_count': ssm_managed,
                    'ssm_managed_percentage': ssm_managed_percentage,
                    'ssm_not_managed_count': ssm_not_managed,
                    'ssm_not_managed_percentage': ssm_not_managed_percentage,
                    'compliance_summary': compliance_summary
                }

                account_data['regions'][region] = region_data

                # Update organization totals
                org_totals['total_instances'] += total_ec2
                org_totals['ssm_managed_instances'] += ssm_managed
                org_totals['compliant_count'] += compliance_summary['compliant_count']
                org_totals['critical_noncompliant_count'] += compliance_summary['critical_noncompliant_count']
                org_totals['high_noncompliant_count'] += compliance_summary['high_noncompliant_count']
                org_totals['other_noncompliant_count'] += compliance_summary['other_noncompliant_count']
                org_totals['missing_patches_count'] += compliance_summary['missing_patches_count']
                org_totals['failed_patches_count'] += compliance_summary['failed_patches_count']
                org_totals['pending_reboot_count'] += compliance_summary['pending_reboot_count']
                org_totals['security_updates_count'] += compliance_summary['security_updates_count']

            # Only include accounts that have EC2 instances
            if account_data['regions']:
                all_data['accounts'][account_id] = account_data

        # Calculate organization-level percentages
        if org_totals['ssm_managed_instances'] > 0:
            all_data['organization_summary'] = {
                'total_instances': org_totals['total_instances'],
                'ssm_managed_instances': org_totals['ssm_managed_instances'],
                'ssm_managed_percentage': round((org_totals['ssm_managed_instances'] / org_totals['total_instances']) * 100, 2),
                'ssm_not_managed_count': org_totals['total_instances'] - org_totals['ssm_managed_instances'],
                'ssm_not_managed_percentage': round(((org_totals['total_instances'] - org_totals['ssm_managed_instances']) / org_totals['total_instances']) * 100, 2),
                'compliant_count': org_totals['compliant_count'],
                'compliance_percentage': round((org_totals['compliant_count'] / org_totals['ssm_managed_instances']) * 100, 2),
                'critical_noncompliant_count': org_totals['critical_noncompliant_count'],
                'critical_noncompliant_percentage': round((org_totals['critical_noncompliant_count'] / org_totals['ssm_managed_instances']) * 100, 2),
                'high_noncompliant_count': org_totals['high_noncompliant_count'],
                'high_noncompliant_percentage': round((org_totals['high_noncompliant_count'] / org_totals['ssm_managed_instances']) * 100, 2),
                'other_noncompliant_count': org_totals['other_noncompliant_count'],
                'other_noncompliant_percentage': round((org_totals['other_noncompliant_count'] / org_totals['ssm_managed_instances']) * 100, 2),
                'missing_patches_count': org_totals['missing_patches_count'],
                'failed_patches_count': org_totals['failed_patches_count'],
                'pending_reboot_count': org_totals['pending_reboot_count'],
                'security_updates_count': org_totals['security_updates_count']
            }

        return all_data

    def generate_html_report(self, compliance_data: Dict) -> str:
        """Generate HTML email report"""
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin-bottom: 20px; }}
                .summary {{ background-color: #e9ecef; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
                table {{ border-collapse: collapse; width: 100%; margin-bottom: 20px; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
                .compliant {{ color: #28a745; }}
                .critical {{ color: #dc3545; font-weight: bold; }}
                .high {{ color: #fd7e14; font-weight: bold; }}
                .warning {{ color: #ffc107; }}
                .section {{ margin-bottom: 30px; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>AWS Organization Patch Compliance Report</h1>
                <p>Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}</p>
                <p>Regions: {', '.join(self.regions)}</p>
            </div>
        """

        # Organization Summary
        org_summary = compliance_data['organization_summary']
        if org_summary['total_instances'] > 0:
            html += f"""
            <div class="section">
                <h2>Organization Summary</h2>
                <div class="summary">
                    <h3>Systems Manager Management</h3>
                    <p><strong>Total EC2 Instances:</strong> {org_summary['total_instances']}</p>
                    <p><strong>SSM Managed:</strong> {org_summary['ssm_managed_instances']} ({org_summary['ssm_managed_percentage']}%)</p>
                    <p><strong>Not SSM Managed:</strong> {org_summary['ssm_not_managed_count']} ({org_summary['ssm_not_managed_percentage']}%)</p>

                    <h3>Patch Compliance Summary</h3>
                    <p><strong class="compliant">Compliant:</strong> {org_summary['compliant_count']} ({org_summary['compliance_percentage']}%)</p>
                    <p><strong class="critical">Critical Non-compliant:</strong> {org_summary['critical_noncompliant_count']} ({org_summary['critical_noncompliant_percentage']}%)</p>
                    <p><strong class="high">High Non-compliant:</strong> {org_summary['high_noncompliant_count']} ({org_summary['high_noncompliant_percentage']}%)</p>
                    <p><strong class="warning">Other Non-compliant:</strong> {org_summary['other_noncompliant_count']} ({org_summary['other_noncompliant_percentage']}%)</p>

                    <h3>Non-compliance Details</h3>
                    <p><strong>Missing Patches:</strong> {org_summary['missing_patches_count']}</p>
                    <p><strong>Failed Patches:</strong> {org_summary['failed_patches_count']}</p>
                    <p><strong>Pending Reboot:</strong> {org_summary['pending_reboot_count']}</p>
                    <p><strong>Available Security Updates:</strong> {org_summary['security_updates_count']}</p>
                </div>
            </div>
            """

        # Account Details
        if compliance_data['accounts']:
            html += """
            <div class="section">
                <h2>Account Details</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Account</th>
                            <th>Region</th>
                            <th>Total EC2</th>
                            <th>SSM Managed</th>
                            <th>SSM %</th>
                            <th>Compliant</th>
                            <th>Compliant %</th>
                            <th>Critical NC</th>
                            <th>High NC</th>
                            <th>Other NC</th>
                            <th>Missing</th>
                            <th>Failed</th>
                            <th>Reboot</th>
                            <th>Security</th>
                        </tr>
                    </thead>
                    <tbody>
            """

            for account_id, account_data in compliance_data['accounts'].items():
                account_name = account_data['account_name']

                for region, region_data in account_data['regions'].items():
                    cs = region_data['compliance_summary']
                    html += f"""
                        <tr>
                            <td>{account_name}</td>
                            <td>{region}</td>
                            <td>{region_data['total_ec2_instances']}</td>
                            <td>{region_data['ssm_managed_count']}</td>
                            <td>{region_data['ssm_managed_percentage']}%</td>
                            <td class="compliant">{cs['compliant_count']}</td>
                            <td class="compliant">{cs['compliance_percentage']}%</td>
                            <td class="critical">{cs['critical_noncompliant_count']}</td>
                            <td class="high">{cs['high_noncompliant_count']}</td>
                            <td class="warning">{cs['other_noncompliant_count']}</td>
                            <td>{cs['missing_patches_count']}</td>
                            <td>{cs['failed_patches_count']}</td>
                            <td>{cs['pending_reboot_count']}</td>
                            <td>{cs['security_updates_count']}</td>
                        </tr>
                    """

            html += """
                    </tbody>
                </table>
            </div>
            """
        else:
            html += """
            <div class="section">
                <h2>No Data Available</h2>
                <p>No EC2 instances found in any accounts across the specified regions.</p>
            </div>
            """

        html += """
        </body>
        </html>
        """

        return html

    def generate_and_send_report(self, compliance_data: Dict):
        """Generate and send email report"""
        try:
            # Generate HTML report
            html_body = self.generate_html_report(compliance_data)

            # Prepare email subject
            org_summary = compliance_data['organization_summary']
            subject = f"AWS Patch Compliance Report - {org_summary['total_instances']} instances, {org_summary['compliance_percentage']}% compliant"

            # Send email using SES module
            # Assuming send_email function is available
            # send_email(
            #     sender_address=self.sender_email,
            #     receiver_addresses=self.recipient_emails,
            #     subject=subject,
            #     body=html_body
            # )

            logger.info(f"Email report sent successfully to {len(self.recipient_emails)} recipients")

        except Exception as e:
            logger.error(f"Error sending email report: {str(e)}")
            raise

# Lambda handler entry point
def lambda_handler(event, context):
    reporter = PatchComplianceReporter()
    return reporter.lambda_handler(event, context)
