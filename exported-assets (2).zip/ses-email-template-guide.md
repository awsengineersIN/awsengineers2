# SES Email Template Configuration for Patch Compliance Reports

## HTML Template for Patch Compliance Report

This document shows how to create a reusable SES email template for patch compliance reports.

### Create SES Template (AWS CLI)

```bash
aws ses create-template --region us-east-1 --template '{
  "TemplateName": "PatchComplianceReport",
  "TemplateData": {
    "Subject": "AWS Patch Compliance Report - {{reportDate}}",
    "HtmlPart": "<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #232F3E; color: white; padding: 20px; }
        .summary { background-color: #f8f9fa; padding: 15px; margin: 20px 0; }
        .critical { color: #dc3545; font-weight: bold; }
        .compliant { color: #28a745; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class="header">
        <h1>AWS Patch Compliance Report</h1>
        <p>Generated: {{reportDate}}</p>
        <p>Organization: {{organizationName}}</p>
    </div>

    <div class="summary">
        <h2>Executive Summary</h2>
        <p><strong>Total Instances:</strong> {{totalInstances}}</p>
        <p><strong>Compliant:</strong> <span class="compliant">{{compliantCount}} ({{compliantPercentage}}%)</span></p>
        <p><strong>Critical Non-compliant:</strong> <span class="critical">{{criticalCount}} ({{criticalPercentage}}%)</span></p>
    </div>

    <h2>Account Details</h2>
    {{#accountData}}
    <h3>{{accountName}} ({{accountId}})</h3>
    <table>
        <tr>
            <th>Region</th>
            <th>EC2 Instances</th>
            <th>SSM Managed</th>
            <th>Compliant</th>
            <th>Critical Issues</th>
        </tr>
        {{#regions}}
        <tr>
            <td>{{regionName}}</td>
            <td>{{totalEc2}}</td>
            <td>{{ssmManaged}}</td>
            <td class="compliant">{{compliantCount}}</td>
            <td class="critical">{{criticalCount}}</td>
        </tr>
        {{/regions}}
    </table>
    {{/accountData}}
</body>
</html>",
    "TextPart": "AWS Patch Compliance Report - {{reportDate}}

Executive Summary:
- Total Instances: {{totalInstances}}
- Compliant: {{compliantCount}} ({{compliantPercentage}}%)
- Critical Non-compliant: {{criticalCount}} ({{criticalPercentage}}%)

{{#accountData}}
Account: {{accountName}} ({{accountId}})
{{#regions}}
- {{regionName}}: {{totalEc2}} instances, {{ssmManaged}} managed, {{compliantCount}} compliant
{{/regions}}
{{/accountData}}"
  }
}'
```

### Using the Template in Lambda

```python
import boto3
import json
from datetime import datetime

def send_templated_email(compliance_data):
    ses_client = boto3.client('ses', region_name='us-east-1')

    # Prepare template data
    template_data = {
        "reportDate": datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC"),
        "organizationName": "Your Organization",
        "totalInstances": str(compliance_data['organization_summary']['total_instances']),
        "compliantCount": str(compliance_data['organization_summary']['compliant_count']),
        "compliantPercentage": str(compliance_data['organization_summary']['compliance_percentage']),
        "criticalCount": str(compliance_data['organization_summary']['critical_noncompliant_count']),
        "criticalPercentage": str(compliance_data['organization_summary']['critical_noncompliant_percentage']),
        "accountData": []
    }

    # Add account data
    for account_id, account_data in compliance_data['accounts'].items():
        account_info = {
            "accountName": account_data['account_name'],
            "accountId": account_id,
            "regions": []
        }

        for region, region_data in account_data['regions'].items():
            region_info = {
                "regionName": region,
                "totalEc2": str(region_data['total_ec2_instances']),
                "ssmManaged": str(region_data['ssm_managed_count']),
                "compliantCount": str(region_data['compliance_summary']['compliant_count']),
                "criticalCount": str(region_data['compliance_summary']['critical_noncompliant_count'])
            }
            account_info['regions'].append(region_info)

        template_data['accountData'].append(account_info)

    # Send templated email
    response = ses_client.send_templated_email(
        Source='reports@yourcompany.com',
        Destination={
            'ToAddresses': ['admin@yourcompany.com', 'security@yourcompany.com']
        },
        Template='PatchComplianceReport',
        TemplateData=json.dumps(template_data)
    )

    return response
```

### Managing Templates

#### Update Template
```bash
aws ses update-template --region us-east-1 --template '{
  "TemplateName": "PatchComplianceReport",
  "TemplateData": {
    "Subject": "Updated AWS Patch Compliance Report - {{reportDate}}",
    "HtmlPart": "<!-- Updated HTML content -->",
    "TextPart": "<!-- Updated text content -->"
  }
}'
```

#### Delete Template
```bash
aws ses delete-template --region us-east-1 --template-name PatchComplianceReport
```

#### List Templates
```bash
aws ses list-templates --region us-east-1
```

This approach provides a cleaner separation between code and email formatting, making it easier to maintain and update email templates without modifying the Lambda function code.
