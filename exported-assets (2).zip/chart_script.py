import plotly.graph_objects as go
import plotly.express as px
import numpy as np

# Create the figure
fig = go.Figure()

# Define colors for different accounts
colors = ['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F', '#D2BA4C']

# Management Account components (left side) - better organized
mgmt_components = {
    'EventBridge': (1.5, 9),
    'Lambda': (1.5, 7),
    'SES': (1.5, 5),
    'Organizations': (3.5, 7),
    'IAM Role': (1.5, 8)
}

# Plot Management Account components with better styling
for i, (component, pos) in enumerate(mgmt_components.items()):
    symbol = 'square' if component == 'Lambda' else 'diamond' if component == 'IAM Role' else 'circle'
    size = 30 if component == 'Lambda' else 25
    
    fig.add_trace(go.Scatter(
        x=[pos[0]],
        y=[pos[1]],
        mode='markers+text',
        marker=dict(
            size=size,
            color=colors[0],
            symbol=symbol,
            line=dict(width=2, color='white')
        ),
        text=component.replace(' ', '<br>') if len(component) > 8 else component,
        textposition='middle center',
        textfont=dict(size=9, color='white'),
        name='Mgmt Account' if i == 0 else '',
        showlegend=(i==0),
        hovertemplate='<b>%{text}</b><br>Management Account<extra></extra>'
    ))

# Member Account components - better spaced
member_accounts = [
    {'name': 'Member 1', 'x_offset': 7, 'color': colors[1]},
    {'name': 'Member 2', 'x_offset': 11, 'color': colors[2]}, 
    {'name': 'Member N', 'x_offset': 15, 'color': colors[3]}
]

for idx, account in enumerate(member_accounts):
    x_base = account['x_offset']
    
    # us-east-1 region components
    fig.add_trace(go.Scatter(
        x=[x_base - 0.5, x_base + 0.5],
        y=[9.5, 9.5],
        mode='markers+text',
        marker=dict(
            size=22,
            color=account['color'],
            symbol='circle',
            line=dict(width=2, color='white')
        ),
        text=['EC2', 'SSM'],
        textposition='middle center',
        textfont=dict(size=8, color='white'),
        name=account['name'] if idx == 0 else '',
        showlegend=(idx==0),
        hovertemplate='<b>%{text}</b><br>' + account['name'] + ' (us-east-1)<extra></extra>'
    ))
    
    # Cross-account role (centered)
    fig.add_trace(go.Scatter(
        x=[x_base],
        y=[7],
        mode='markers+text',
        marker=dict(
            size=28,
            color=account['color'],
            symbol='diamond',
            line=dict(width=2, color='white')
        ),
        text='Cross<br>Role',
        textposition='middle center',
        textfont=dict(size=7, color='white'),
        showlegend=False,
        hovertemplate='<b>Cross-Account Role</b><br>' + account['name'] + '<extra></extra>'
    ))
    
    # us-west-2 region components
    fig.add_trace(go.Scatter(
        x=[x_base - 0.5, x_base + 0.5],
        y=[4.5, 4.5],
        mode='markers+text',
        marker=dict(
            size=22,
            color=account['color'],
            symbol='circle',
            line=dict(width=2, color='white')
        ),
        text=['EC2', 'SSM'],
        textposition='middle center',
        textfont=dict(size=8, color='white'),
        showlegend=False,
        hovertemplate='<b>%{text}</b><br>' + account['name'] + ' (us-west-2)<extra></extra>'
    ))

# Add flow arrows with annotations
# 1. EventBridge triggers Lambda
fig.add_annotation(
    x=1.5, y=8.5, ax=1.5, ay=8.8,
    arrowhead=2, arrowsize=1, arrowwidth=2, arrowcolor='#333333'
)
fig.add_annotation(
    x=1.5, y=8.3, text="Scheduled<br>Trigger", showarrow=False,
    font=dict(size=8, color='#333333'), bgcolor='white'
)

# 2. Lambda to Organizations
fig.add_annotation(
    x=3.5, y=7, ax=2.0, ay=7,
    arrowhead=2, arrowsize=1, arrowwidth=2, arrowcolor='#333333'
)
fig.add_annotation(
    x=2.7, y=7.3, text="List<br>Accounts", showarrow=False,
    font=dict(size=8, color='#333333'), bgcolor='white'
)

# 3. Lambda to Cross-Account Roles
for account in member_accounts:
    x_base = account['x_offset']
    fig.add_annotation(
        x=x_base, y=7, ax=2.0, ay=7,
        arrowhead=2, arrowsize=1, arrowwidth=2, arrowcolor='#333333'
    )

# Label for assume role flow
fig.add_annotation(
    x=5.5, y=7.5, text="Assume<br>Roles", showarrow=False,
    font=dict(size=8, color='#333333'), bgcolor='white'
)

# 4. Roles to EC2/SSM services in both regions
for account in member_accounts:
    x_base = account['x_offset']
    # To us-east-1 services
    fig.add_annotation(
        x=x_base - 0.5, y=9.5, ax=x_base, ay=7.5,
        arrowhead=2, arrowsize=1, arrowwidth=1.5, arrowcolor='#666666'
    )
    fig.add_annotation(
        x=x_base + 0.5, y=9.5, ax=x_base, ay=7.5,
        arrowhead=2, arrowsize=1, arrowwidth=1.5, arrowcolor='#666666'
    )
    # To us-west-2 services
    fig.add_annotation(
        x=x_base - 0.5, y=4.5, ax=x_base, ay=6.5,
        arrowhead=2, arrowsize=1, arrowwidth=1.5, arrowcolor='#666666'
    )
    fig.add_annotation(
        x=x_base + 0.5, y=4.5, ax=x_base, ay=6.5,
        arrowhead=2, arrowsize=1, arrowwidth=1.5, arrowcolor='#666666'
    )

# Label for data collection
fig.add_annotation(
    x=11, y=8.2, text="Collect Patch<br>Data", showarrow=False,
    font=dict(size=8, color='#333333'), bgcolor='white'
)

# 5. Lambda to SES
fig.add_annotation(
    x=1.5, y=5.5, ax=1.5, ay=6.5,
    arrowhead=2, arrowsize=1, arrowwidth=2, arrowcolor='#333333'
)
fig.add_annotation(
    x=1.5, y=6, text="Send Email<br>Report", showarrow=False,
    font=dict(size=8, color='#333333'), bgcolor='white'
)

# Add region background rectangles
fig.add_shape(
    type="rect",
    x0=5.5, y0=9, x1=17, y1=10,
    line=dict(color="#87CEEB", width=2),
    fillcolor="rgba(135,206,235,0.1)"
)

fig.add_shape(
    type="rect", 
    x0=5.5, y0=4, x1=17, y1=5,
    line=dict(color="#FFB6C1", width=2),
    fillcolor="rgba(255,182,193,0.1)"
)

# Add region labels
fig.add_annotation(
    x=16.5, y=9.7, text="us-east-1", showarrow=False,
    font=dict(size=12, color='#4682B4', weight='bold'),
    bgcolor='white', bordercolor='#87CEEB', borderwidth=1
)

fig.add_annotation(
    x=16.5, y=4.3, text="us-west-2", showarrow=False,
    font=dict(size=12, color='#CD5C5C', weight='bold'),
    bgcolor='white', bordercolor='#FFB6C1', borderwidth=1
)

# Add account group backgrounds
fig.add_shape(
    type="rect",
    x0=0.5, y0=4, x1=4.5, y1=10,
    line=dict(color=colors[0], width=2),
    fillcolor="rgba(31,184,205,0.05)"
)

fig.add_shape(
    type="rect",
    x0=5.5, y0=3.5, x1=17, y1=10.5,
    line=dict(color="#999999", width=2),
    fillcolor="rgba(200,200,200,0.05)"
)

# Add account group labels
fig.add_annotation(
    x=2.5, y=3.5, text="Management Account", showarrow=False,
    font=dict(size=14, color=colors[0], weight='bold'),
    bgcolor='white', bordercolor=colors[0], borderwidth=1
)

fig.add_annotation(
    x=11.25, y=3, text="Member Accounts", showarrow=False,
    font=dict(size=14, color='#333333', weight='bold'),
    bgcolor='white', bordercolor='#999999', borderwidth=1
)

# Update layout
fig.update_layout(
    title="AWS Multi-Acct Patch Compliance",
    xaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[0, 18]
    ),
    yaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[2.5, 10.8]
    ),
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.02,
        xanchor='center',
        x=0.5
    ),
    plot_bgcolor='white',
    showlegend=True
)

# Save the chart
fig.write_image("aws_architecture.png")