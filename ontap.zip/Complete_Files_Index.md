# Complete FSx ONTAP Volume Expansion - All Files Index

## 📁 **Complete File Structure**

```
fsx-expansion/
├── lambda/
│   ├── config.py                    (code_file:111) ✓
│   ├── bedrock_analyzer.py          (code_file:112) ✓ [GenAI Integration]
│   ├── parameter_store.py           (code_file:113) ✓
│   ├── metrics.py                   (code_file:114) ✓
│   ├── expansion_logic.py           (code_file:115) ✓
│   ├── notifications.py             (code_file:116) ✓
│   ├── index.py                     (code_file:117) ✓
│   └── requirements.txt             (code_file:118) ✓
├── tests/
│   └── test_expansion_logic.py      (code_file:119) ✓
├── Architecture_Overview.md         (code_file:110) ✓
└── README_Index.md                  (code_file:99) ✓
```

---

## 📋 **File Descriptions**

### **1. lambda/config.py** (code_file:111)
**Configuration and Constants Management**
- Environment variables setup
- Bedrock configuration flags
- Expansion defaults (thresholds, percentages)
- CloudWatch metrics constants
- Logging configuration
- Cost/pricing information

**Key Features:**
- `ENABLE_BEDROCK_ANALYSIS` - Toggle GenAI on/off
- `BEDROCK_MODEL_ID` - Claude 3.5 Sonnet
- Default thresholds: 80% usage, 20% min expansion, 30-day buffer

**Usage:**
```python
from config import ENABLE_BEDROCK_ANALYSIS, DEFAULT_USAGE_THRESHOLD
```

---

### **2. lambda/bedrock_analyzer.py** (code_file:112) ⭐
**GenAI-Powered Storage Trend Analysis - WHERE BEDROCK IS USED**
- Calls Amazon Bedrock Claude API
- Analyzes storage trends with AI
- Detects anomalies and cleanup events
- Provides AI recommendations with reasoning
- Falls back to linear regression if disabled

**Key Classes:**
- `BedrockTrendAnalyzer` - Main analysis class
  - `analyze_storage_trends()` - Get AI recommendations
  - `_invoke_bedrock()` - Call Claude API
  - `_parse_claude_response()` - Parse AI output
  - `get_cost_estimate()` - Calculate Bedrock costs

**GenAI Features:**
- Uses Claude 3.5 Sonnet model
- Cost: ~$0.003 per analysis
- Confidence scoring (0-100%)
- Extracts growth patterns, alerts, recommendations
- Falls back gracefully if disabled

**Usage:**
```python
from bedrock_analyzer import BedrockTrendAnalyzer

analyzer = BedrockTrendAnalyzer()
if ENABLE_BEDROCK_ANALYSIS:
    recommendation = analyzer.analyze_storage_trends(...)
```

---

### **3. lambda/parameter_store.py** (code_file:113)
**Parameter Store Management**
- Load/save volume configurations
- Initialize from FSx inventory
- Update volume metadata
- Single JSON parameter: `/fsx/volumes/config`

**Key Classes:**
- `ParameterStoreManager`
  - `load_config()` - Load all volumes
  - `save_config()` - Persist updates
  - `initialize_from_fsx()` - Discover volumes
  - `update_volume_metadata()` - Update single volume

**Usage:**
```python
from parameter_store import ParameterStoreManager

manager = ParameterStoreManager()
config = manager.load_config()
```

---

### **4. lambda/metrics.py** (code_file:114)
**CloudWatch Metrics Collection**
- Retrieve volume metrics from CloudWatch
- Calculate usage percentages
- Get latest usage

**Key Classes:**
- `MetricsCollector`
  - `get_volume_metrics()` - 14-day history
  - `get_latest_usage()` - Current usage
  - `calculate_usage_percent()` - Usage percentage

**Usage:**
```python
from metrics import MetricsCollector

collector = MetricsCollector()
metrics = collector.get_volume_metrics('fsvol-1', days=14)
```

---

### **5. lambda/expansion_logic.py** (code_file:115)
**Core Volume Expansion Decision Logic**
- Linear regression growth calculation
- Expansion decision logic
- FSx API integration
- Cleanup detection

**Key Classes:**
- `ExpansionDecider`
  - `decide_expansion()` - Main decision logic
  - `_calculate_growth_rate()` - Linear regression
  - `expand_volume()` - Call FSx API

**Decision Flow:**
1. Check usage threshold (80%)
2. Calculate growth rate (linear regression)
3. Detect cleanup (negative slope)
4. Project days to full
5. Decide expansion

**Usage:**
```python
from expansion_logic import ExpansionDecider

decider = ExpansionDecider()
result = decider.decide_expansion(volume, metrics, config)
```

---

### **6. lambda/notifications.py** (code_file:116)
**SNS Notification Manager**
- Send expansion alerts
- Send error notifications
- Format messages

**Key Classes:**
- `NotificationManager`
  - `send_expansion_alert()` - Expansion event
  - `send_error_alert()` - Error notification

**Usage:**
```python
from notifications import NotificationManager

notifier = NotificationManager()
notifier.send_expansion_alert(expanded_volumes)
```

---

### **7. lambda/index.py** (code_file:117)
**Lambda Handler - Main Entry Point**
- Orchestrates all components
- Processes all volumes
- Integrates GenAI (Bedrock)
- Handles errors

**Key Functions:**
- `lambda_handler(event, context)` - Lambda entry point

**Flow:**
1. Load configuration from Parameter Store
2. For each volume:
   - Get CloudWatch metrics
   - Decide expansion
   - Optionally get Bedrock recommendation
   - Execute expansion if needed
3. Save updated config
4. Send notifications

**Usage:**
```python
# Triggered by EventBridge every 6 hours
# No manual invocation needed
```

---

### **8. lambda/requirements.txt** (code_file:118)
**Python Dependencies**
```
boto3>=1.26.0        # AWS SDK
scipy>=1.9.0         # Linear regression
python-dateutil>=2.8.0
```

---

### **9. tests/test_expansion_logic.py** (code_file:119)
**Unit Tests**
- Growth rate calculation
- Expansion decision logic
- Cleanup detection
- Low usage handling

**Test Classes:**
- `TestExpansionLogic`
  - `test_growth_rate_calculation()` ✓
  - `test_no_expansion_low_usage()` ✓
  - `test_cleanup_detection()` ✓
  - `test_expansion_decision()` ✓

**Run Tests:**
```bash
python -m pytest tests/test_expansion_logic.py
```

---

### **10. Architecture_Overview.md** (code_file:110)
**Architecture and GenAI Integration Guide**
- File structure overview
- GenAI/Bedrock usage details
- Cost comparison
- When to use Bedrock
- Integration flow

---

### **11. README_Index.md** (code_file:99)
**Quick Reference and Index**
- File summary
- Quick start guide
- Key features
- Testing status

---

## 🚀 **Quick Start - Deploy All Files**

### **Step 1: Download All Files**
```bash
# All files are provided above
# Copy to your lambda/ and tests/ directories
```

### **Step 2: Install Dependencies**
```bash
pip install -r lambda/requirements.txt
```

### **Step 3: Run Tests**
```bash
python -m pytest tests/test_expansion_logic.py -v
```

### **Step 4: Initialize Parameter Store**
```bash
python -c "from lambda.parameter_store import ParameterStoreManager; \
           ParameterStoreManager().initialize_from_fsx()"
```

### **Step 5: Deploy to Lambda**
```bash
cd lambda/
zip -r ../lambda-deployment.zip .
aws lambda update-function-code \
  --function-name fsx-volume-expansion \
  --zip-file fileb://../lambda-deployment.zip
```

### **Step 6: Enable Bedrock (Optional)**
```bash
aws lambda update-function-configuration \
  --function-name fsx-volume-expansion \
  --environment "Variables={ENABLE_BEDROCK=true}"
```

---

## 📊 **File Dependencies**

```
index.py (Lambda handler)
├── config.py (configuration)
├── parameter_store.py (load/save config)
├── metrics.py (get CloudWatch data)
├── expansion_logic.py (decide expansion)
├── bedrock_analyzer.py (optional GenAI) ⭐
└── notifications.py (send alerts)
```

---

## ✅ **File Status**

| File | Status | Type | Purpose |
|------|--------|------|---------|
| config.py | ✓ Complete | Config | Settings & constants |
| bedrock_analyzer.py | ✓ Complete | GenAI | Claude AI analysis |
| parameter_store.py | ✓ Complete | AWS | Volume config mgmt |
| metrics.py | ✓ Complete | AWS | CloudWatch integration |
| expansion_logic.py | ✓ Complete | Logic | Decision algorithm |
| notifications.py | ✓ Complete | AWS | SNS alerts |
| index.py | ✓ Complete | Lambda | Main handler |
| requirements.txt | ✓ Complete | Config | Dependencies |
| test_expansion_logic.py | ✓ Complete | Tests | Unit tests |
| Architecture_Overview.md | ✓ Complete | Doc | Architecture |

---

## 🎯 **What Each File Does**

1. **config.py** - Sets all configuration options
2. **bedrock_analyzer.py** - ⭐ Uses GenAI/Bedrock for intelligent analysis
3. **parameter_store.py** - Manages Parameter Store (single source of truth)
4. **metrics.py** - Gets CloudWatch data
5. **expansion_logic.py** - Calculates if expansion needed (linear regression)
6. **notifications.py** - Sends SNS alerts
7. **index.py** - Orchestrates everything
8. **requirements.txt** - Lists dependencies
9. **test_expansion_logic.py** - Tests the logic
10. **Architecture_Overview.md** - Explains the design

---

## 🔑 **Key Integration Points**

### **Bedrock GenAI Integration (bedrock_analyzer.py)**
- Enabled via `ENABLE_BEDROCK=true` environment variable
- Optional fallback to linear regression if disabled
- Provides intelligent recommendations with reasoning
- Cost: ~$0.003 per analysis (~$0.18/month)

### **Parameter Store Integration**
- Single JSON parameter: `/fsx/volumes/config`
- All volumes tracked in one place
- CDK can reference it for drift prevention

### **Lambda Orchestration (index.py)**
- Loads config from Parameter Store
- Gets metrics from CloudWatch
- Decides expansion (linear regression)
- Optionally gets Bedrock recommendation
- Expands via FSx API
- Saves updated config
- Sends notifications

---

## 📞 **All Files Now Available**

✅ All 10+ files provided and documented
✅ Complete implementation ready to deploy
✅ All dependencies listed
✅ Tests included
✅ GenAI/Bedrock integration documented

**Start with index.py** - it orchestrates everything!
