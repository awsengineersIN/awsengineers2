# cloudwatch/alarms.py
"""
CloudWatch Alarms for FSx Volume Expansion Monitoring

Creates alarms for:
- Lambda execution failures
- Volume approaching capacity
- Expansion events
- FSx health
"""

import boto3
import logging
from config import AWS_REGION, SNS_TOPIC_ARN

logger = logging.getLogger(__name__)
cloudwatch = boto3.client('cloudwatch', region_name=AWS_REGION)


class CloudWatchAlarmManager:
    """Manage CloudWatch alarms for FSx expansion automation"""
    
    def __init__(self, sns_topic_arn: str = SNS_TOPIC_ARN):
        self.sns_topic_arn = sns_topic_arn
        self.cloudwatch = cloudwatch
    
    def create_lambda_error_alarm(self, function_name: str) -> str:
        """
        Alarm: Lambda function errors
        
        Triggers when:
        - Lambda execution fails
        - Lambda timeout
        - Lambda invocation errors
        """
        alarm_name = f'{function_name}-errors'
        
        self.cloudwatch.put_metric_alarm(
            AlarmName=alarm_name,
            MetricName='Errors',
            Namespace='AWS/Lambda',
            Statistic='Sum',
            Period=3600,  # 1 hour
            EvaluationPeriods=1,
            Threshold=1,
            ComparisonOperator='GreaterThanOrEqualToThreshold',
            Dimensions=[
                {'Name': 'FunctionName', 'Value': function_name}
            ],
            AlarmActions=[self.sns_topic_arn],
            AlarmDescription='Alert when FSx expansion Lambda has errors',
            TreatMissingData='notBreaching'
        )
        
        logger.info(f"Created alarm: {alarm_name}")
        return alarm_name
    
    def create_lambda_duration_alarm(self, function_name: str) -> str:
        """
        Alarm: Lambda execution duration too long
        
        Triggers when Lambda takes > 30 seconds
        """
        alarm_name = f'{function_name}-duration'
        
        self.cloudwatch.put_metric_alarm(
            AlarmName=alarm_name,
            MetricName='Duration',
            Namespace='AWS/Lambda',
            Statistic='Average',
            Period=3600,
            EvaluationPeriods=1,
            Threshold=30000,  # 30 seconds in ms
            ComparisonOperator='GreaterThanThreshold',
            Dimensions=[
                {'Name': 'FunctionName', 'Value': function_name}
            ],
            AlarmActions=[self.sns_topic_arn],
            AlarmDescription='Alert when FSx expansion Lambda takes too long',
            TreatMissingData='notBreaching'
        )
        
        logger.info(f"Created alarm: {alarm_name}")
        return alarm_name
    
    def create_volume_capacity_alarm(
        self,
        volume_id: str,
        usage_threshold_gb: int = 900
    ) -> str:
        """
        Alarm: FSx volume approaching capacity
        
        Triggers when volume usage exceeds threshold (default 900 GB)
        """
        alarm_name = f'fsx-volume-{volume_id}-capacity'
        
        self.cloudwatch.put_metric_alarm(
            AlarmName=alarm_name,
            MetricName='VolumeLogicalUsedSize',
            Namespace='AWS/FSx',
            Statistic='Average',
            Period=3600,  # 1 hour
            EvaluationPeriods=2,
            Threshold=usage_threshold_gb * 1024 * 1024,  # Convert GB to bytes
            ComparisonOperator='GreaterThanThreshold',
            Dimensions=[
                {'Name': 'VolumeId', 'Value': volume_id}
            ],
            AlarmActions=[self.sns_topic_arn],
            AlarmDescription=f'Alert when volume {volume_id} usage exceeds {usage_threshold_gb} GB',
            TreatMissingData='notBreaching'
        )
        
        logger.info(f"Created alarm: {alarm_name}")
        return alarm_name
    
    def create_parameter_store_update_alarm(self, parameter_name: str) -> str:
        """
        Alarm: Parameter Store updates
        
        Tracks when volume configurations are updated
        """
        alarm_name = f'param-store-{parameter_name.replace("/", "-")}-updates'
        
        self.cloudwatch.put_metric_alarm(
            AlarmName=alarm_name,
            MetricName='PutParameter',
            Namespace='AWS/SystemsManager',
            Statistic='Sum',
            Period=3600,
            EvaluationPeriods=1,
            Threshold=1,
            ComparisonOperator='GreaterThanOrEqualToThreshold',
            AlarmActions=[self.sns_topic_arn],
            AlarmDescription=f'Alert when {parameter_name} is updated',
            TreatMissingData='notBreaching'
        )
        
        logger.info(f"Created alarm: {alarm_name}")
        return alarm_name
    
    def delete_alarm(self, alarm_name: str) -> None:
        """Delete a CloudWatch alarm"""
        try:
            self.cloudwatch.delete_alarms(AlarmNames=[alarm_name])
            logger.info(f"Deleted alarm: {alarm_name}")
        except Exception as e:
            logger.error(f"Error deleting alarm: {str(e)}")
