# lambda/parameter_store.py
"""
AWS Systems Manager Parameter Store Manager

Handles all Parameter Store operations for FSx volume configuration management.
"""

import json
import logging
import boto3
from typing import Dict, Any, List, Optional
from datetime import datetime
from config import PARAMETER_NAME, AWS_REGION

logger = logging.getLogger(__name__)
ssm_client = boto3.client('ssm', region_name=AWS_REGION)


class ParameterStoreManager:
    """Manage FSx volume configuration in Parameter Store"""
    
    def __init__(self, parameter_name: str = PARAMETER_NAME):
        self.parameter_name = parameter_name
        self.fsx_client = boto3.client('fsx', region_name=AWS_REGION)
    
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from Parameter Store"""
        try:
            response = ssm_client.get_parameter(Name=self.parameter_name)
            config = json.loads(response['Parameter']['Value'])
            logger.info(f"Loaded config for {len(config.get('volumes', []))} volumes")
            return config
        except ssm_client.exceptions.ParameterNotFound:
            logger.error(f"Parameter {self.parameter_name} not found")
            raise
        except Exception as e:
            logger.error(f"Error loading config: {str(e)}")
            raise
    
    def save_config(self, config: Dict[str, Any]) -> None:
        """Save configuration to Parameter Store"""
        try:
            config['last_updated'] = datetime.utcnow().isoformat() + 'Z'
            ssm_client.put_parameter(
                Name=self.parameter_name,
                Value=json.dumps(config, indent=2),
                Type='String',
                Overwrite=True,
                Description='FSx ONTAP volume configuration and expansion tracking'
            )
            logger.info("Configuration saved to Parameter Store")
        except Exception as e:
            logger.error(f"Error saving config: {str(e)}")
            raise
    
    def initialize_from_fsx(self, file_system_id: Optional[str] = None) -> Dict[str, Any]:
        """Initialize Parameter Store from FSx inventory"""
        try:
            logger.info("Initializing Parameter Store from FSx")
            
            # Get file systems
            fs_response = self.fsx_client.describe_file_systems()
            ontap_fs = [
                fs for fs in fs_response.get('FileSystems', [])
                if fs.get('FileSystemType') == 'ONTAP'
            ]
            
            if not ontap_fs:
                raise ValueError("No FSx ONTAP file systems found")
            
            if file_system_id:
                fs = next((fs for fs in ontap_fs if fs['FileSystemId'] == file_system_id), None)
                if not fs:
                    raise ValueError(f"File system {file_system_id} not found")
            else:
                fs = ontap_fs[0]
            
            # Get volumes
            volumes_response = self.fsx_client.describe_volumes(
                Filters=[{'Name': 'file-system-id', 'Values': [fs['FileSystemId']]}]
            )
            volumes = volumes_response.get('Volumes', [])
            
            # Build config
            now = datetime.utcnow()
            config = {
                "file_system_id": fs['FileSystemId'],
                "region": fs.get('AvailabilityZone', 'us-east-1a').rsplit('-', 1)[0],
                "last_updated": now.isoformat() + 'Z',
                "created_at": now.isoformat() + 'Z',
                "volumes": [
                    {
                        "volume_id": vol['VolumeId'],
                        "volume_name": vol.get('Name', vol['VolumeId']),
                        "svm_id": vol.get('OntapConfiguration', {}).get('StorageVirtualMachineId', ''),
                        "current_size_mb": vol['SizeInMegabytes'],
                        "previous_size_mb": vol['SizeInMegabytes'],
                        "expansion_percent": 0,
                        "last_expansion_time": None,
                        "last_expansion_reason": "Initial configuration",
                        "days_until_full": None,
                        "growth_rate_mb_per_day": 0.0,
                        "current_usage_percent": 0.0,
                        "expansion_enabled": True,
                        "min_expansion_percent": 20,
                        "usage_threshold_percent": 80,
                        "days_to_full_target": 30
                    }
                    for vol in volumes
                ],
                "global_config": {
                    "min_expansion_percent": 20,
                    "usage_threshold_percent": 80,
                    "days_to_full_target": 30,
                    "historical_window_days": 14,
                    "metric_collection_interval_hours": 6,
                    "enable_bedrock_analysis": False,
                    "sns_topic_arn": "arn:aws:sns:us-east-1:123456789012:fsx-expansion-alerts"
                }
            }
            
            self.save_config(config)
            logger.info(f"Initialized {len(volumes)} volumes in Parameter Store")
            return config
        
        except Exception as e:
            logger.error(f"Error initializing from FSx: {str(e)}")
            raise
    
    def update_volume_metadata(
        self,
        volume_id: str,
        update_data: Dict[str, Any]
    ) -> None:
        """Update metadata for a specific volume"""
        try:
            config = self.load_config()
            
            for volume in config['volumes']:
                if volume['volume_id'] == volume_id:
                    volume.update(update_data)
                    break
            
            self.save_config(config)
            logger.info(f"Updated metadata for {volume_id}")
        
        except Exception as e:
            logger.error(f"Error updating volume metadata: {str(e)}")
            raise
