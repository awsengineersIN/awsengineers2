# lambda/index.py
"""
Lambda Handler - Main Entry Point

Orchestrates all components for FSx ONTAP volume expansion.
"""

import json
import logging
import sys
import traceback
from config import (
    LOG_LEVEL,
    LOG_FORMAT,
    ENABLE_BEDROCK_ANALYSIS
)
from parameter_store import ParameterStoreManager
from metrics import MetricsCollector
from expansion_logic import ExpansionDecider
from notifications import NotificationManager
from bedrock_analyzer import BedrockTrendAnalyzer

# Setup logging
logging.basicConfig(
    level=LOG_LEVEL,
    format=LOG_FORMAT,
    stream=sys.stdout
)
logger = logging.getLogger(__name__)


def lambda_handler(event, context):
    """
    Lambda handler for FSx volume expansion automation
    
    Triggered by EventBridge every 6 hours
    """
    
    try:
        logger.info("FSx expansion Lambda starting")
        logger.info(f"Bedrock enabled: {ENABLE_BEDROCK_ANALYSIS}")
        
        # Initialize components
        param_manager = ParameterStoreManager()
        metrics_collector = MetricsCollector()
        expansion_decider = ExpansionDecider()
        notification_manager = NotificationManager()
        bedrock_analyzer = BedrockTrendAnalyzer() if ENABLE_BEDROCK_ANALYSIS else None
        
        # Load configuration
        config = param_manager.load_config()
        global_config = config['global_config']
        
        # Process each volume
        expanded_volumes = []
        total_volumes = len(config['volumes'])
        
        for volume in config['volumes']:
            if not volume.get('expansion_enabled', True):
                logger.info(f"Volume {volume['volume_id']} expansion disabled")
                continue
            
            try:
                # Get metrics
                metrics = metrics_collector.get_volume_metrics(
                    volume['volume_id'],
                    global_config['historical_window_days']
                )
                
                # Decide expansion
                decision = expansion_decider.decide_expansion(
                    volume,
                    metrics,
                    global_config
                )
                
                # Get Bedrock analysis if enabled
                bedrock_recommendation = None
                if ENABLE_BEDROCK_ANALYSIS and decision['expansion_triggered'] and bedrock_analyzer:
                    try:
                        bedrock_recommendation = bedrock_analyzer.analyze_storage_trends(
                            volume['volume_id'],
                            volume['current_size_mb'],
                            metrics[-1]['usage_mb'],
                            metrics,
                            decision['update_data'].get('growth_rate_mb_per_day', 0)
                        )
                        
                        # Use Bedrock's recommendation if available and confident
                        if bedrock_recommendation and bedrock_recommendation.get('confidence', 0) > 75:
                            new_size_factor = 1 + (bedrock_recommendation.get('recommendation_percent', 20) / 100)
                            decision['new_size_mb'] = int(volume['current_size_mb'] * new_size_factor)
                            decision['update_data']['bedrock_analysis'] = bedrock_recommendation
                            logger.info(f"Using Bedrock recommendation: {bedrock_recommendation.get('recommendation_percent')}%")
                    except Exception as e:
                        logger.warning(f"Bedrock analysis failed: {str(e)}, using linear regression")
                
                # Execute expansion if triggered
                if decision['expansion_triggered']:
                    try:
                        expansion_decider.expand_volume(
                            volume['volume_id'],
                            decision['new_size_mb']
                        )
                        expanded_volumes.append(decision)
                    except Exception as e:
                        logger.error(f"Expansion failed: {str(e)}")
                        decision['error'] = str(e)
                
                # Update volume config
                volume.update(decision['update_data'])
            
            except Exception as e:
                logger.error(f"Error processing volume {volume['volume_id']}: {str(e)}")
                logger.error(traceback.format_exc())
        
        # Save updated config
        param_manager.save_config(config)
        logger.info("Configuration updated in Parameter Store")
        
        # Send notifications
        if expanded_volumes:
            notification_manager.send_expansion_alert(expanded_volumes)
        
        response = {
            'statusCode': 200,
            'body': json.dumps({
                'message': f'Processed {total_volumes} volumes; {len(expanded_volumes)} expanded',
                'expanded_volumes': [v['volume_id'] for v in expanded_volumes]
            })
        }
        
        logger.info(f"Lambda completed: {response['body']}")
        return response
    
    except Exception as e:
        logger.error(f"Lambda error: {str(e)}")
        logger.error(traceback.format_exc())
        
        notification_manager = NotificationManager()
        notification_manager.send_error_alert(
            f"FSx Expansion Lambda Error\n\n{str(e)}\n\n{traceback.format_exc()}"
        )
        
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
