# infrastructure/complete_deployment.sh
#!/bin/bash

# Complete FSx ONTAP Volume Expansion Deployment Script
# Sets up all infrastructure components

set -e

echo "=============================================="
echo "FSx Expansion - Complete Infrastructure Setup"
echo "=============================================="

FUNCTION_NAME="fsx-volume-expansion"
REGION="${AWS_REGION:-us-east-1}"
TOPIC_NAME="fsx-expansion-alerts"
RULE_NAME="fsx-expansion-schedule"

echo ""
echo "Configuration:"
echo "  Function: $FUNCTION_NAME"
echo "  Topic: $TOPIC_NAME"
echo "  Rule: $RULE_NAME"
echo "  Region: $REGION"
echo ""

# Step 1: Create SNS Topic
echo "Step 1: Creating SNS topic..."
TOPIC_ARN=$(aws sns create-topic \
  --name $TOPIC_NAME \
  --region $REGION \
  --query 'TopicArn' \
  --output text)

echo "✓ SNS Topic ARN: $TOPIC_ARN"

# Step 2: Subscribe email (if provided)
if [ ! -z "$ALERT_EMAIL" ]; then
  echo ""
  echo "Step 2: Subscribing email to SNS topic..."
  aws sns subscribe \
    --topic-arn $TOPIC_ARN \
    --protocol email \
    --notification-endpoint $ALERT_EMAIL \
    --region $REGION
  
  echo "✓ Email subscription created (requires confirmation)"
fi

# Step 3: Create Parameter Store entry
echo ""
echo "Step 3: Creating Parameter Store configuration..."
PARAM_VALUE='{
  "file_system_id": "",
  "volumes": [],
  "global_config": {
    "usage_threshold_percent": 80,
    "min_expansion_percent": 20,
    "days_to_full_target": 30,
    "sns_topic_arn": "'$TOPIC_ARN'"
  }
}'

aws ssm put-parameter \
  --name /fsx/volumes/config \
  --value "$PARAM_VALUE" \
  --type String \
  --region $REGION \
  --overwrite || true

echo "✓ Parameter Store configured"

# Step 4: Create Lambda function
echo ""
echo "Step 4: Building Lambda package..."
cd lambda
rm -f ../fsx-lambda.zip
pip install -r requirements.txt -t . --quiet
zip -r ../fsx-lambda.zip . -q
cd ..

echo "✓ Lambda package created"

# Step 5: Create IAM Role
echo ""
echo "Step 5: Creating IAM role..."
ROLE_NAME="FSxExpansionLambdaRole"

TRUST_POLICY='{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "lambda.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}'

aws iam create-role \
  --role-name $ROLE_NAME \
  --assume-role-policy-document "$TRUST_POLICY" \
  --region $REGION 2>/dev/null || true

ROLE_ARN=$(aws iam get-role \
  --role-name $ROLE_NAME \
  --query 'Role.Arn' \
  --output text)

echo "✓ IAM Role ARN: $ROLE_ARN"

# Step 6: Attach policies
echo ""
echo "Step 6: Attaching policies..."
aws iam attach-role-policy \
  --role-name $ROLE_NAME \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole \
  --region $REGION

# Custom policy
POLICY_NAME="FSxExpansionPolicy"
POLICY_DOC='{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["fsx:UpdateVolume", "fsx:DescribeVolumes", "fsx:DescribeFileSystems"],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": ["ssm:GetParameter", "ssm:PutParameter"],
      "Resource": "arn:aws:ssm:*:*:parameter/fsx/volumes/config"
    },
    {
      "Effect": "Allow",
      "Action": ["cloudwatch:GetMetricStatistics"],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": ["sns:Publish"],
      "Resource": "'$TOPIC_ARN'"
    },
    {
      "Effect": "Allow",
      "Action": ["bedrock:InvokeModel"],
      "Resource": "arn:aws:bedrock:*:*:foundation-model/anthropic.claude-3-5-sonnet*"
    }
  ]
}'

aws iam put-role-policy \
  --role-name $ROLE_NAME \
  --policy-name $POLICY_NAME \
  --policy-document "$POLICY_DOC" \
  --region $REGION

echo "✓ Policies attached"

# Wait for role to be available
sleep 2

# Step 7: Create Lambda function
echo ""
echo "Step 7: Creating Lambda function..."
aws lambda create-function \
  --function-name $FUNCTION_NAME \
  --runtime python3.11 \
  --role $ROLE_ARN \
  --handler index.lambda_handler \
  --zip-file fileb://fsx-lambda.zip \
  --timeout 60 \
  --memory-size 256 \
  --environment "Variables={SNS_TOPIC_ARN=$TOPIC_ARN,ENABLE_BEDROCK=false}" \
  --region $REGION 2>/dev/null || {
    echo "Updating existing function..."
    aws lambda update-function-code \
      --function-name $FUNCTION_NAME \
      --zip-file fileb://fsx-lambda.zip \
      --region $REGION
    
    aws lambda update-function-configuration \
      --function-name $FUNCTION_NAME \
      --timeout 60 \
      --memory-size 256 \
      --environment "Variables={SNS_TOPIC_ARN=$TOPIC_ARN,ENABLE_BEDROCK=false}" \
      --region $REGION
  }

LAMBDA_ARN=$(aws lambda get-function \
  --function-name $FUNCTION_NAME \
  --region $REGION \
  --query 'Configuration.FunctionArn' \
  --output text)

echo "✓ Lambda Function ARN: $LAMBDA_ARN"

# Step 8: Create EventBridge rule
echo ""
echo "Step 8: Creating EventBridge rule..."
aws events put-rule \
  --name $RULE_NAME \
  --schedule-expression 'rate(6 hours)' \
  --state ENABLED \
  --region $REGION

RULE_ARN=$(aws events describe-rule \
  --name $RULE_NAME \
  --region $REGION \
  --query 'Arn' \
  --output text)

echo "✓ EventBridge Rule ARN: $RULE_ARN"

# Step 9: Add Lambda permission
echo ""
echo "Step 9: Adding Lambda permission..."
aws lambda add-permission \
  --function-name $FUNCTION_NAME \
  --statement-id AllowEventBridgeInvoke \
  --action lambda:InvokeFunction \
  --principal events.amazonaws.com \
  --source-arn $RULE_ARN \
  --region $REGION 2>/dev/null || true

echo "✓ Permission added"

# Step 10: Add EventBridge target
echo ""
echo "Step 10: Adding Lambda as EventBridge target..."
aws events put-targets \
  --rule $RULE_NAME \
  --targets "Id"="1","Arn"="$LAMBDA_ARN" \
  --region $REGION

echo "✓ Target added"

# Step 11: Create CloudWatch alarms
echo ""
echo "Step 11: Creating CloudWatch alarms..."

aws cloudwatch put-metric-alarm \
  --alarm-name "$FUNCTION_NAME-errors" \
  --alarm-description "Alert on FSx expansion Lambda errors" \
  --metric-name Errors \
  --namespace AWS/Lambda \
  --statistic Sum \
  --period 3600 \
  --evaluation-periods 1 \
  --threshold 1 \
  --comparison-operator GreaterThanOrEqualToThreshold \
  --dimensions Name=FunctionName,Value=$FUNCTION_NAME \
  --alarm-actions $TOPIC_ARN \
  --region $REGION

echo "✓ CloudWatch alarms created"

# Cleanup
echo ""
echo "Step 12: Cleanup..."
rm -f fsx-lambda.zip
rm -rf lambda/.zip
echo "✓ Temporary files removed"

# Final summary
echo ""
echo "=============================================="
echo "✓ Deployment Complete!"
echo "=============================================="
echo ""
echo "Components Created:"
echo "  • SNS Topic: $TOPIC_NAME"
echo "  • Lambda Function: $FUNCTION_NAME"
echo "  • EventBridge Rule: $RULE_NAME (every 6 hours)"
echo "  • CloudWatch Alarms"
echo "  • Parameter Store config"
echo "  • IAM Role & Policies"
echo ""
echo "Next Steps:"
echo "  1. Initialize Parameter Store with FSx volumes:"
echo "     python -c \"from parameter_store import ParameterStoreManager; \\"
echo "                ParameterStoreManager().initialize_from_fsx()\""
echo ""
echo "  2. Enable Bedrock (optional):"
echo "     aws lambda update-function-configuration \\"
echo "       --function-name $FUNCTION_NAME \\"
echo "       --environment Variables={ENABLE_BEDROCK=true}"
echo ""
echo "  3. Monitor logs:"
echo "     aws logs tail /aws/lambda/$FUNCTION_NAME --follow"
echo ""
