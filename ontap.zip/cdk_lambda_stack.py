# infrastructure/cdk_lambda_stack.py
"""
AWS CDK Stack for Lambda Function and EventBridge Integration

This stack creates:
- Lambda function
- EventBridge rule (triggers every 6 hours)
- CloudWatch alarms
- SNS topic
- IAM roles and policies
"""

from aws_cdk import (
    aws_lambda as lambda_,
    aws_events as events,
    aws_events_targets as targets,
    aws_sns as sns,
    aws_iam as iam,
    aws_cloudwatch as cloudwatch,
    core
)
import json


class FSxExpansionLambdaStack(core.Stack):
    """CDK Stack for FSx expansion Lambda and EventBridge"""
    
    def __init__(self, scope: core.Construct, id: str, **kwargs):
        super().__init__(scope, id, **kwargs)
        
        # SNS Topic for notifications
        sns_topic = sns.Topic(
            self, 'FSxExpansionAlerts',
            display_name='FSx ONTAP Volume Expansion Alerts',
            topic_name='fsx-expansion-alerts'
        )
        
        # Lambda IAM Role
        lambda_role = iam.Role(
            self, 'FSxExpansionLambdaRole',
            assumed_by=iam.ServicePrincipal('lambda.amazonaws.com'),
            description='Role for FSx expansion Lambda function'
        )
        
        # Add inline policies
        lambda_role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    'logs:CreateLogGroup',
                    'logs:CreateLogStream',
                    'logs:PutLogEvents'
                ],
                resources=['arn:aws:logs:*:*:*']
            )
        )
        
        lambda_role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    'fsx:UpdateVolume',
                    'fsx:DescribeVolumes',
                    'fsx:DescribeFileSystems'
                ],
                resources=['*']
            )
        )
        
        lambda_role.add_to_policy(
            iam.PolicyStatement(
                actions=[
                    'ssm:GetParameter',
                    'ssm:PutParameter'
                ],
                resources=['arn:aws:ssm:*:*:parameter/fsx/volumes/config']
            )
        )
        
        lambda_role.add_to_policy(
            iam.PolicyStatement(
                actions=['cloudwatch:GetMetricStatistics'],
                resources=['*']
            )
        )
        
        sns_topic.grant_publish(lambda_role)
        
        # Bedrock permission (optional)
        lambda_role.add_to_policy(
            iam.PolicyStatement(
                actions=['bedrock:InvokeModel'],
                resources=['arn:aws:bedrock:*:*:foundation-model/anthropic.claude-3-5-sonnet*']
            )
        )
        
        # Lambda Function
        lambda_function = lambda_.Function(
            self, 'FSxExpansionLambda',
            runtime=lambda_.Runtime.PYTHON_3_11,
            handler='index.lambda_handler',
            code=lambda_.Code.from_asset('lambda'),
            timeout=core.Duration.seconds(60),
            memory_size=256,
            role=lambda_role,
            environment={
                'SNS_TOPIC_ARN': sns_topic.topic_arn,
                'PARAMETER_NAME': '/fsx/volumes/config',
                'ENABLE_BEDROCK': 'false'
            },
            description='Automated FSx ONTAP volume expansion'
        )
        
        # EventBridge Rule (every 6 hours)
        rule = events.Rule(
            self, 'FSxExpansionSchedule',
            schedule=events.Schedule.rate(core.Duration.hours(6)),
            description='Trigger FSx volume expansion check every 6 hours'
        )
        
        rule.add_target(targets.LambdaFunction(lambda_function))
        
        # CloudWatch Alarms
        lambda_function.metric_errors().create_alarm(
            self, 'LambdaErrorAlarm',
            threshold=1,
            evaluation_periods=1,
            alarm_description='Alert on Lambda errors',
            alarm_name='fsx-expansion-lambda-errors'
        )
        
        lambda_function.metric_duration().create_alarm(
            self, 'LambdaDurationAlarm',
            threshold=core.Duration.seconds(30),
            evaluation_periods=2,
            alarm_description='Alert when Lambda exceeds 30 seconds',
            alarm_name='fsx-expansion-lambda-duration'
        )
        
        # Output
        core.CfnOutput(
            self, 'LambdaFunctionArn',
            value=lambda_function.function_arn,
            description='ARN of FSx expansion Lambda function'
        )
        
        core.CfnOutput(
            self, 'SNSTopicArn',
            value=sns_topic.topic_arn,
            description='ARN of SNS topic for notifications'
        )
        
        core.CfnOutput(
            self, 'EventBridgeRuleArn',
            value=rule.rule_arn,
            description='ARN of EventBridge rule'
        )


if __name__ == '__main__':
    app = core.App()
    stack = FSxExpansionLambdaStack(app, 'FSxExpansionLambdaStack')
    app.synth()
