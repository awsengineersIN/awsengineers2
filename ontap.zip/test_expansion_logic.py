# tests/test_expansion_logic.py
"""
Unit Tests for Expansion Logic

Tests growth rate calculation, expansion decisions, and cleanup detection.
"""

import unittest
from datetime import datetime, timedelta
from expansion_logic import ExpansionDecider


class TestExpansionLogic(unittest.TestCase):
    """Test expansion decision logic"""
    
    def setUp(self):
        self.decider = ExpansionDecider()
        self.base_config = {
            'usage_threshold_percent': 80,
            'min_expansion_percent': 20,
            'days_to_full_target': 30,
            'historical_window_days': 14
        }
    
    def test_growth_rate_calculation(self):
        """Test linear regression growth calculation"""
        # Create 14 days of metrics with 25 MB/day growth
        metrics = [
            {
                'timestamp': datetime.utcnow() + timedelta(days=i),
                'usage_mb': 1000.0 + (i * 25.0)
            }
            for i in range(14)
        ]
        
        growth_rate, r_squared = self.decider._calculate_growth_rate(metrics)
        
        self.assertAlmostEqual(growth_rate, 25.0, delta=2.0)
        self.assertGreater(r_squared, 0.99)
    
    def test_no_expansion_low_usage(self):
        """Test no expansion when usage < threshold"""
        metrics = [
            {
                'timestamp': datetime.utcnow() + timedelta(days=i),
                'usage_mb': 500.0 + (i * 10.0)
            }
            for i in range(14)
        ]
        
        volume_config = {
            'volume_id': 'test-vol',
            'current_size_mb': 1000
        }
        
        result = self.decider.decide_expansion(volume_config, metrics, self.base_config)
        
        self.assertFalse(result['expansion_triggered'])
    
    def test_cleanup_detection(self):
        """Test cleanup event detection"""
        metrics = []
        base_time = datetime.utcnow()
        
        for i in range(14):
            usage = 1000.0 + (i * 20.0)
            if i == 7:
                usage -= 200.0  # Cleanup
            metrics.append({
                'timestamp': base_time + timedelta(days=i),
                'usage_mb': usage
            })
        
        growth_rate, r_squared = self.decider._calculate_growth_rate(metrics)
        
        # Should detect negative or reduced growth
        self.assertLess(growth_rate, 20.0)
    
    def test_expansion_decision(self):
        """Test expansion when threshold met"""
        metrics = [
            {
                'timestamp': datetime.utcnow() + timedelta(days=i),
                'usage_mb': 800.0 + (i * 30.0)
            }
            for i in range(14)
        ]
        
        volume_config = {
            'volume_id': 'test-vol',
            'current_size_mb': 1000,
            'expansion_enabled': True
        }
        
        result = self.decider.decide_expansion(volume_config, metrics, self.base_config)
        
        self.assertTrue(result['expansion_triggered'])
        self.assertIn('new_size_mb', result)


if __name__ == '__main__':
    unittest.main()
