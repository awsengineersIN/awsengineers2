# lambda/expansion_logic.py
"""
Core Volume Expansion Decision Logic

Calculates growth rates and makes expansion decisions using linear regression.
"""

import logging
from datetime import datetime
from typing import Dict, List, Any, Tuple
from scipy import stats

logger = logging.getLogger(__name__)


class ExpansionDecider:
    """Make FSx volume expansion decisions"""
    
    def __init__(self):
        self.fsx_client = None  # Set in index.py
    
    def decide_expansion(
        self,
        volume_config: Dict[str, Any],
        metrics: List[Dict[str, Any]],
        global_config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Decide if volume should be expanded
        
        Args:
            volume_config: Volume configuration from Parameter Store
            metrics: List of {timestamp, usage_mb} dicts
            global_config: Global configuration settings
        
        Returns:
            Decision dict with expansion details
        """
        
        volume_id = volume_config['volume_id']
        current_size_mb = volume_config['current_size_mb']
        
        result = {
            'volume_id': volume_id,
            'expansion_triggered': False,
            'update_data': {},
            'error': None
        }
        
        try:
            if not metrics:
                logger.warning(f"No metrics for {volume_id}")
                result['update_data'] = {'last_expansion_reason': 'Insufficient metrics'}
                return result
            
            # Get latest usage
            latest_usage_mb = metrics[-1]['usage_mb']
            current_usage_percent = (latest_usage_mb / current_size_mb) * 100
            
            logger.info(f"{volume_id}: Usage {current_usage_percent:.1f}%")
            
            # Check threshold
            threshold = global_config['usage_threshold_percent']
            if current_usage_percent < threshold:
                logger.info(f"{volume_id}: Usage below {threshold}% threshold")
                result['update_data'] = {
                    'current_usage_percent': current_usage_percent,
                    'last_expansion_reason': f'Usage below {threshold}% threshold'
                }
                return result
            
            # Calculate growth rate
            growth_rate, r_squared = self._calculate_growth_rate(metrics)
            
            logger.info(f"{volume_id}: Growth rate {growth_rate:.2f} MB/day")
            
            # Detect cleanup (negative slope)
            if growth_rate < 0:
                logger.info(f"{volume_id}: Cleanup detected")
                result['update_data'] = {
                    'growth_rate_mb_per_day': growth_rate,
                    'current_usage_percent': current_usage_percent,
                    'last_expansion_reason': 'Cleanup event detected'
                }
                return result
            
            # Calculate days to full
            available_space = current_size_mb - latest_usage_mb
            days_to_full = available_space / growth_rate if growth_rate > 0 else float('inf')
            
            logger.info(f"{volume_id}: Days to full {days_to_full:.1f}")
            
            # Check if expansion needed
            target_days = global_config['days_to_full_target']
            if days_to_full >= target_days:
                logger.info(f"{volume_id}: Sufficient buffer, no expansion needed")
                result['update_data'] = {
                    'growth_rate_mb_per_day': growth_rate,
                    'days_until_full': days_to_full,
                    'current_usage_percent': current_usage_percent,
                    'last_expansion_reason': f'Days to full {days_to_full:.1f} > target {target_days}'
                }
                return result
            
            # EXPANSION DECISION: YES
            expansion_factor = max(
                1 + (global_config['min_expansion_percent'] / 100),
                1 + (growth_rate * target_days / current_size_mb)
            )
            
            new_size_mb = int(current_size_mb * expansion_factor)
            expansion_percent = ((new_size_mb - current_size_mb) / current_size_mb) * 100
            
            logger.info(f"{volume_id}: EXPAND {current_size_mb} → {new_size_mb} MB ({expansion_percent:.1f}%)")
            
            result['expansion_triggered'] = True
            result['update_data'] = {
                'previous_size_mb': current_size_mb,
                'current_size_mb': new_size_mb,
                'expansion_percent': expansion_percent,
                'last_expansion_time': datetime.utcnow().isoformat() + 'Z',
                'last_expansion_reason': f'Growth {growth_rate:.1f} MB/day; days to full {days_to_full:.1f}',
                'growth_rate_mb_per_day': growth_rate,
                'days_until_full': days_to_full,
                'current_usage_percent': current_usage_percent
            }
            result['new_size_mb'] = new_size_mb
        
        except Exception as e:
            logger.error(f"Error deciding expansion: {str(e)}")
            result['error'] = str(e)
        
        return result
    
    def _calculate_growth_rate(
        self,
        metrics: List[Dict[str, Any]]
    ) -> Tuple[float, float]:
        """
        Calculate growth rate using linear regression
        
        Returns:
            (growth_rate_mb_per_day, r_squared)
        """
        try:
            if len(metrics) < 2:
                logger.warning("Insufficient data points for regression")
                return 0.0, 0.0
            
            # Convert to arrays
            times = [m['timestamp'].timestamp() for m in metrics]
            usages = [m['usage_mb'] for m in metrics]
            
            start_time = times[0]
            days_elapsed = [(t - start_time) / 86400 for t in times]
            
            # Linear regression
            slope, intercept, r_value, p_value, std_err = stats.linregress(
                days_elapsed, usages
            )
            
            r_squared = r_value ** 2
            
            return slope, r_squared
        
        except Exception as e:
            logger.error(f"Error calculating growth rate: {str(e)}")
            return 0.0, 0.0
    
    def expand_volume(self, volume_id: str, new_size_mb: int) -> bool:
        """Expand volume via FSx API"""
        try:
            import boto3
            fsx = boto3.client('fsx')
            
            fsx.update_volume(
                VolumeId=volume_id,
                OntapConfiguration={
                    'SizeInMegabytes': new_size_mb
                }
            )
            
            logger.info(f"Volume {volume_id} expanded to {new_size_mb} MB")
            return True
        
        except Exception as e:
            logger.error(f"Error expanding volume: {str(e)}")
            raise
