# lambda/notifications.py
"""
SNS Notification Manager

Sends alerts for expansion events and errors.
"""

import json
import logging
import boto3
from typing import List, Dict, Any
from config import SNS_TOPIC_ARN, AWS_REGION

logger = logging.getLogger(__name__)
sns_client = boto3.client('sns', region_name=AWS_REGION)


class NotificationManager:
    """Manage SNS notifications"""
    
    def __init__(self, sns_topic_arn: str = SNS_TOPIC_ARN):
        self.sns_topic_arn = sns_topic_arn
    
    def send_expansion_alert(
        self,
        expanded_volumes: List[Dict[str, Any]]
    ) -> bool:
        """Send notification for expanded volumes"""
        try:
            if not expanded_volumes:
                return True
            
            message = self._format_expansion_message(expanded_volumes)
            
            sns_client.publish(
                TopicArn=self.sns_topic_arn,
                Subject=f'FSx Volume Expansion: {len(expanded_volumes)} volumes',
                Message=message
            )
            
            logger.info(f"Sent expansion notification for {len(expanded_volumes)} volumes")
            return True
        
        except Exception as e:
            logger.error(f"Error sending notification: {str(e)}")
            return False
    
    def send_error_alert(self, error_message: str) -> bool:
        """Send error notification"""
        try:
            sns_client.publish(
                TopicArn=self.sns_topic_arn,
                Subject='FSx Expansion Lambda Error',
                Message=error_message
            )
            
            logger.info("Sent error notification")
            return True
        
        except Exception as e:
            logger.error(f"Error sending error notification: {str(e)}")
            return False
    
    def _format_expansion_message(self, volumes: List[Dict[str, Any]]) -> str:
        """Format expansion notification message"""
        message = "FSx ONTAP Volumes Expanded\n\n"
        message += "=" * 60 + "\n\n"
        
        for vol in volumes:
            update = vol['update_data']
            message += f"Volume ID: {vol['volume_id']}\n"
            message += f"  Previous Size: {update.get('previous_size_mb', 'N/A')} MB\n"
            message += f"  New Size: {update.get('current_size_mb', 'N/A')} MB\n"
            message += f"  Expansion: {update.get('expansion_percent', 0):.1f}%\n"
            message += f"  Growth Rate: {update.get('growth_rate_mb_per_day', 0):.2f} MB/day\n"
            message += f"  Reason: {update.get('last_expansion_reason', 'N/A')}\n\n"
        
        return message
