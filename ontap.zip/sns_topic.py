# infrastructure/sns_topic.py
"""
SNS Topic Configuration

Creates and manages SNS topics for FSx expansion alerts.
"""

import boto3
import json
import logging
from config import AWS_REGION

logger = logging.getLogger(__name__)
sns_client = boto3.client('sns', region_name=AWS_REGION)


class SNSTopicManager:
    """Manage SNS topics for notifications"""
    
    def __init__(self):
        self.sns = sns_client
    
    def create_topic(
        self,
        topic_name: str = 'fsx-expansion-alerts'
    ) -> str:
        """
        Create SNS topic for expansion alerts
        
        Returns:
            Topic ARN
        """
        try:
            response = self.sns.create_topic(Name=topic_name)
            topic_arn = response['TopicArn']
            
            logger.info(f"Created SNS topic: {topic_name}")
            logger.info(f"Topic ARN: {topic_arn}")
            
            # Set topic attributes
            self.sns.set_topic_attributes(
                TopicArn=topic_arn,
                AttributeName='DisplayName',
                AttributeValue='FSx ONTAP Volume Expansion Alerts'
            )
            
            return topic_arn
        
        except self.sns.exceptions.TopicLimitExceededException:
            # Topic already exists
            response = self.sns.get_topic_attributes(
                TopicArn=f"arn:aws:sns:{AWS_REGION}:*:fsx-expansion-alerts"
            )
            return response['Attributes']['TopicArn']
        
        except Exception as e:
            logger.error(f"Error creating topic: {str(e)}")
            raise
    
    def subscribe_email(
        self,
        topic_arn: str,
        email_address: str
    ) -> str:
        """Subscribe email to topic"""
        try:
            response = self.sns.subscribe(
                TopicArn=topic_arn,
                Protocol='email',
                Endpoint=email_address
            )
            
            subscription_arn = response['SubscriptionArn']
            logger.info(f"Subscribed {email_address} to {topic_arn}")
            logger.info(f"Subscription ARN: {subscription_arn}")
            
            return subscription_arn
        
        except Exception as e:
            logger.error(f"Error subscribing email: {str(e)}")
            raise
    
    def subscribe_slack(
        self,
        topic_arn: str,
        slack_webhook_url: str
    ) -> str:
        """Subscribe Slack webhook to topic"""
        try:
            # Note: Requires Lambda for SNS -> Slack integration
            logger.warning("Slack integration requires Lambda transformation")
            return None
        
        except Exception as e:
            logger.error(f"Error subscribing Slack: {str(e)}")
    
    def publish_message(
        self,
        topic_arn: str,
        subject: str,
        message: str
    ) -> str:
        """Publish message to topic"""
        try:
            response = self.sns.publish(
                TopicArn=topic_arn,
                Subject=subject,
                Message=message
            )
            
            message_id = response['MessageId']
            logger.info(f"Published message: {message_id}")
            
            return message_id
        
        except Exception as e:
            logger.error(f"Error publishing message: {str(e)}")
            raise
    
    def delete_topic(self, topic_arn: str) -> None:
        """Delete SNS topic"""
        try:
            self.sns.delete_topic(TopicArn=topic_arn)
            logger.info(f"Deleted topic: {topic_arn}")
        except Exception as e:
            logger.error(f"Error deleting topic: {str(e)}")


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    
    manager = SNSTopicManager()
    
    # Create topic
    topic_arn = manager.create_topic()
    print(f"Topic ARN: {topic_arn}")
    
    # Subscribe email
    manager.subscribe_email(topic_arn, 'admin@example.com')
