# Infrastructure Components - Complete Index

## 📋 All Infrastructure Files

code_file:121 - CloudWatch Alarms Manager
code_file:122 - IAM Policies (JSON)
code_file:123 - EventBridge Rule Manager  
code_file:124 - SNS Topic Manager
code_file:125 - CDK Lambda Stack
code_file:126 - Complete Deployment Script

---

## 📁 **Infrastructure Directory Structure**

```
infrastructure/
├── cloudwatch_alarms.py         (code_file:121)
├── eventbridge_rule.py          (code_file:123)
├── sns_topic.py                 (code_file:124)
├── iam_policies.json            (code_file:122)
├── cdk_lambda_stack.py          (code_file:125)
└── complete_deployment.sh       (code_file:126)
```

---

## 🔧 **Component Descriptions**

### **1. CloudWatch Alarms** (code_file:121)

**Purpose:** Monitor Lambda and FSx health

**Alarms Created:**
- `lambda-errors` - Triggers on Lambda failures
- `lambda-duration` - Alerts if execution takes > 30 seconds
- `volume-{id}-capacity` - Triggers when volume exceeds 900 GB
- `parameter-store-updates` - Tracks config changes

**Usage:**
```python
from cloudwatch_alarms import CloudWatchAlarmManager

manager = CloudWatchAlarmManager()
manager.create_lambda_error_alarm('fsx-volume-expansion')
manager.create_volume_capacity_alarm('fsvol-1', usage_threshold_gb=900)
```

---

### **2. EventBridge Rule Manager** (code_file:123)

**Purpose:** Trigger Lambda every 6 hours

**Capabilities:**
- Create EventBridge rules with cron/rate expressions
- Add Lambda as target
- Manage rule lifecycle (enable/disable/delete)
- Create required IAM roles

**Schedule:** `rate(6 hours)` - runs every 6 hours

**Usage:**
```python
from eventbridge_rule import EventBridgeManager

manager = EventBridgeManager()
arn = manager.create_expansion_schedule()
manager.disable_rule('fsx-expansion-schedule')  # Pause automation
manager.enable_rule('fsx-expansion-schedule')   # Resume automation
```

---

### **3. SNS Topic Manager** (code_file:124)

**Purpose:** Create and manage SNS topics for notifications

**Capabilities:**
- Create SNS topic
- Subscribe email addresses
- Publish messages
- Delete topics

**Topic Name:** `fsx-expansion-alerts`

**Usage:**
```python
from sns_topic import SNSTopicManager

manager = SNSTopicManager()
topic_arn = manager.create_topic()
manager.subscribe_email(topic_arn, 'admin@example.com')
```

---

### **4. IAM Policies** (code_file:122)

**Purpose:** Define least-privilege permissions

**Policies Included:**

1. **LambdaExecutionPolicy** - Lambda permissions
   - CloudWatch Logs (create, write)
   - FSx (update volumes, describe)
   - Parameter Store (get, put)
   - CloudWatch Metrics
   - SNS Publish
   - Bedrock Invoke (optional)

2. **EventBridgeExecutionRole** - EventBridge permissions
   - Lambda InvokeFunction

---

### **5. CDK Lambda Stack** (code_file:125)

**Purpose:** Infrastructure-as-Code stack for all components

**Creates:**
- Lambda function
- EventBridge rule
- SNS topic
- CloudWatch alarms
- IAM roles & policies

**Deploy:**
```bash
cdk deploy FSxExpansionLambdaStack
```

**Features:**
- Fully typed CDK code
- Proper role separation
- Automatic alarm creation
- CloudFormation outputs

---

### **6. Complete Deployment Script** (code_file:126)

**Purpose:** One-command deployment of entire solution

**Steps:**
1. Create SNS topic
2. Subscribe email alerts
3. Create Parameter Store config
4. Build Lambda package
5. Create IAM role
6. Attach policies
7. Create Lambda function
8. Create EventBridge rule
9. Add Lambda permission
10. Add EventBridge target
11. Create CloudWatch alarms
12. Cleanup

**Run:**
```bash
bash infrastructure/complete_deployment.sh
```

**With email alerts:**
```bash
export ALERT_EMAIL="admin@example.com"
bash infrastructure/complete_deployment.sh
```

---

## 🔗 **Component Integration**

```
┌─────────────────────────────────────────────────┐
│ EventBridge Rule (Triggers every 6 hours)      │
│ (code_file:123)                                │
└────────────────┬────────────────────────────────┘
                 │
                 ↓
┌─────────────────────────────────────────────────┐
│ Lambda Function                                 │
│ (index.py) - Orchestrates all modules          │
└────────────────┬────────────────────────────────┘
                 │
        ┌────────┴────────┬─────────┐
        ↓                 ↓         ↓
    Parameter      CloudWatch    Bedrock
    Store          Metrics       (Optional)
    (SSM)          (metrics.py)  (GenAI)
                 
        ↓                 
┌─────────────────────────────────────────────────┐
│ FSx ONTAP API                                   │
│ update_volume()                                 │
└─────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────┐
│ SNS Topic (notifications.py)                    │
│ - Expansion alerts                              │
│ - Error notifications                           │
└─────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────┐
│ CloudWatch Alarms                               │
│ - Monitor Lambda health                         │
│ - Track volume capacity                         │
└─────────────────────────────────────────────────┘
```

---

## 📊 **Infrastructure Cost**

| Component | Cost | Notes |
|-----------|------|-------|
| Lambda | ~$2/month | 240 executions × 5 sec |
| EventBridge | $0.35/month | 4 executions/day |
| CloudWatch Logs | $1.50/month | ~100 MB logs |
| CloudWatch Alarms | $0.10/month | 4 alarms |
| SNS | $0.50/month | ~100 notifications |
| Parameter Store | $0.40/month | 1 get + 1 put per exec |
| FSx (capacity check) | Free | No additional cost |
| **TOTAL** | **~$5/month** | **Without Bedrock** |
| + Bedrock | ~$0.18/month | Optional GenAI |

---

## ✅ **What Gets Deployed**

### **AWS Services Used**
✓ Lambda
✓ EventBridge
✓ Systems Manager (Parameter Store)
✓ CloudWatch (Metrics, Logs, Alarms)
✓ SNS
✓ IAM (Roles, Policies)
✓ FSx (update_volume API)
✓ Bedrock (optional)

### **Monitoring & Alerts**
✓ Lambda error monitoring
✓ Lambda duration monitoring
✓ Volume capacity tracking
✓ Parameter Store change tracking
✓ SNS email notifications
✓ CloudWatch Logs aggregation

### **Security**
✓ Least-privilege IAM roles
✓ Bedrock API protection
✓ Parameter Store encryption (optional)
✓ SNS topic permissions

---

## 🚀 **Quick Deployment**

### **Option 1: Automated (Recommended)**
```bash
# One command deploys everything
bash infrastructure/complete_deployment.sh

# With email alerts
export ALERT_EMAIL="admin@example.com"
bash infrastructure/complete_deployment.sh
```

### **Option 2: Using CDK**
```bash
# Install CDK
npm install -g aws-cdk

# Deploy
cdk deploy FSxExpansionLambdaStack

# Destroy (cleanup)
cdk destroy
```

### **Option 3: Manual (AWS CLI)**
```bash
# Create SNS topic
aws sns create-topic --name fsx-expansion-alerts

# Create Lambda
aws lambda create-function \
  --function-name fsx-volume-expansion \
  --zip-file fileb://fsx-lambda.zip \
  ...

# Create EventBridge rule
aws events put-rule \
  --name fsx-expansion-schedule \
  --schedule-expression 'rate(6 hours)'

# Create alarms
aws cloudwatch put-metric-alarm ...
```

---

## 📋 **Deployment Checklist**

- [ ] SNS topic created
- [ ] Email subscribed to SNS
- [ ] Parameter Store configured
- [ ] Lambda IAM role created
- [ ] Lambda policies attached
- [ ] Lambda function deployed
- [ ] EventBridge rule created
- [ ] Lambda permission added
- [ ] EventBridge target added
- [ ] CloudWatch alarms created
- [ ] Lambda environment vars set
- [ ] Bedrock permission added (if enabled)

---

## 🔐 **IAM Permissions Required**

To run complete_deployment.sh, you need:
- `sns:CreateTopic`
- `sns:Subscribe`
- `ssm:PutParameter`
- `lambda:CreateFunction`
- `lambda:UpdateFunctionCode`
- `lambda:UpdateFunctionConfiguration`
- `lambda:AddPermission`
- `iam:CreateRole`
- `iam:PutRolePolicy`
- `iam:AttachRolePolicy`
- `iam:GetRole`
- `events:PutRule`
- `events:PutTargets`
- `events:DescribeRule`
- `cloudwatch:PutMetricAlarm`

---

## 🔄 **Lifecycle Operations**

### **Disable Automation (Pause)**
```bash
aws events disable-rule --name fsx-expansion-schedule
```

### **Enable Automation (Resume)**
```bash
aws events enable-rule --name fsx-expansion-schedule
```

### **Change Schedule** 
```bash
aws events put-rule \
  --name fsx-expansion-schedule \
  --schedule-expression 'rate(12 hours)'
```

### **Update Lambda**
```bash
zip -r fsx-lambda.zip lambda/
aws lambda update-function-code \
  --function-name fsx-volume-expansion \
  --zip-file fileb://fsx-lambda.zip
```

### **Clean Up**
```bash
cdk destroy FSxExpansionLambdaStack
# OR
aws cloudformation delete-stack --stack-name FSxExpansionLambdaStack
```

---

## 📞 **All Infrastructure Files Ready**

✅ CloudWatch Alarms (code_file:121)
✅ EventBridge Rules (code_file:123)
✅ SNS Topics (code_file:124)
✅ IAM Policies (code_file:122)
✅ CDK Stack (code_file:125)
✅ Deployment Script (code_file:126)

**All 16+ total files now complete!**
- 8 Lambda files (lambda/ directory)
- 1 Test file (tests/ directory)
- 6 Infrastructure files (infrastructure/ directory)
- 3 Documentation files

**Total: 18 complete, production-ready files**
