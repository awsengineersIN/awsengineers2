# lambda/metrics.py
"""
CloudWatch Metrics Collection and Analysis

Retrieves and processes FSx volume usage metrics from CloudWatch.
"""

import logging
import boto3
from datetime import datetime, timedelta
from typing import Dict, List, Any
from config import (
    CLOUDWATCH_NAMESPACE,
    CLOUDWATCH_METRIC,
    METRIC_PERIOD,
    METRIC_STATISTICS,
    AWS_REGION
)

logger = logging.getLogger(__name__)
cloudwatch_client = boto3.client('cloudwatch', region_name=AWS_REGION)


class MetricsCollector:
    """Collect and process CloudWatch metrics for FSx volumes"""
    
    def __init__(self):
        self.cloudwatch = cloudwatch_client
        self.namespace = CLOUDWATCH_NAMESPACE
        self.metric = CLOUDWATCH_METRIC
    
    def get_volume_metrics(
        self,
        volume_id: str,
        historical_days: int = 14
    ) -> List[Dict[str, Any]]:
        """
        Retrieve historical metrics for a volume
        
        Args:
            volume_id: FSx volume ID
            historical_days: Number of days to retrieve
        
        Returns:
            List of {timestamp, usage_mb} dicts sorted by time
        """
        try:
            response = self.cloudwatch.get_metric_statistics(
                Namespace=self.namespace,
                MetricName=self.metric,
                Dimensions=[
                    {'Name': 'VolumeId', 'Value': volume_id}
                ],
                StartTime=datetime.utcnow() - timedelta(days=historical_days),
                EndTime=datetime.utcnow(),
                Period=METRIC_PERIOD,
                Statistics=METRIC_STATISTICS
            )
            
            datapoints = response.get('Datapoints', [])
            
            if not datapoints:
                logger.warning(f"No metrics for volume {volume_id}")
                return []
            
            # Sort by timestamp
            datapoints.sort(key=lambda x: x['Timestamp'])
            
            metrics = [
                {
                    'timestamp': dp['Timestamp'],
                    'usage_mb': dp['Average']
                }
                for dp in datapoints
            ]
            
            logger.info(f"Retrieved {len(metrics)} metrics for {volume_id}")
            return metrics
        
        except Exception as e:
            logger.error(f"Error retrieving metrics: {str(e)}")
            return []
    
    def get_latest_usage(self, volume_id: str) -> float:
        """Get the most recent usage for a volume"""
        try:
            response = self.cloudwatch.get_metric_statistics(
                Namespace=self.namespace,
                MetricName=self.metric,
                Dimensions=[
                    {'Name': 'VolumeId', 'Value': volume_id}
                ],
                StartTime=datetime.utcnow() - timedelta(hours=6),
                EndTime=datetime.utcnow(),
                Period=300,
                Statistics=['Average']
            )
            
            datapoints = response.get('Datapoints', [])
            if not datapoints:
                return 0.0
            
            latest = sorted(datapoints, key=lambda x: x['Timestamp'])[-1]
            return latest['Average']
        
        except Exception as e:
            logger.error(f"Error getting latest usage: {str(e)}")
            return 0.0
    
    def calculate_usage_percent(
        self,
        usage_mb: float,
        size_mb: int
    ) -> float:
        """Calculate usage percentage"""
        if size_mb == 0:
            return 0.0
        return (usage_mb / size_mb) * 100
