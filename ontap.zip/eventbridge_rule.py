# infrastructure/eventbridge_rule.py
"""
EventBridge Rule Configuration

Creates and manages EventBridge rules to trigger Lambda every 6 hours.
"""

import boto3
import json
import logging
from config import AWS_REGION

logger = logging.getLogger(__name__)
events_client = boto3.client('events', region_name=AWS_REGION)
lambda_client = boto3.client('lambda', region_name=AWS_REGION)


class EventBridgeManager:
    """Manage EventBridge rules for FSx expansion"""
    
    def __init__(self):
        self.events = events_client
        self.lambda_client = lambda_client
    
    def create_expansion_schedule(
        self,
        rule_name: str = 'fsx-expansion-schedule',
        lambda_function_name: str = 'fsx-volume-expansion',
        schedule_expression: str = 'rate(6 hours)'
    ) -> str:
        """
        Create EventBridge rule to trigger Lambda every 6 hours
        
        Args:
            rule_name: Name of the EventBridge rule
            lambda_function_name: Lambda function to invoke
            schedule_expression: Cron or rate expression
        
        Returns:
            Rule ARN
        """
        try:
            # Create rule
            response = self.events.put_rule(
                Name=rule_name,
                ScheduleExpression=schedule_expression,
                State='ENABLED',
                Description='Trigger FSx volume expansion check every 6 hours'
            )
            
            rule_arn = response['RuleArn']
            logger.info(f"Created EventBridge rule: {rule_name}")
            logger.info(f"Schedule: {schedule_expression}")
            
            # Add Lambda as target
            self._add_lambda_target(rule_name, lambda_function_name)
            
            return rule_arn
        
        except Exception as e:
            logger.error(f"Error creating EventBridge rule: {str(e)}")
            raise
    
    def _add_lambda_target(
        self,
        rule_name: str,
        lambda_function_name: str
    ) -> None:
        """Add Lambda function as target for EventBridge rule"""
        try:
            # Get Lambda function ARN
            lambda_response = self.lambda_client.get_function(
                FunctionName=lambda_function_name
            )
            lambda_arn = lambda_response['Configuration']['FunctionArn']
            
            # Add permission for EventBridge to invoke Lambda
            try:
                self.lambda_client.add_permission(
                    FunctionName=lambda_function_name,
                    StatementId='AllowEventBridgeInvoke',
                    Action='lambda:InvokeFunction',
                    Principal='events.amazonaws.com',
                    SourceArn=f"arn:aws:events:*:*:rule/{rule_name}"
                )
                logger.info(f"Added EventBridge permission to {lambda_function_name}")
            except self.lambda_client.exceptions.ResourceConflictException:
                logger.info("Permission already exists")
            
            # Add Lambda as target
            self.events.put_targets(
                Rule=rule_name,
                Targets=[
                    {
                        'Id': '1',
                        'Arn': lambda_arn,
                        'RoleArn': self._get_eventbridge_role_arn()
                    }
                ]
            )
            
            logger.info(f"Added {lambda_function_name} as target for {rule_name}")
        
        except Exception as e:
            logger.error(f"Error adding Lambda target: {str(e)}")
            raise
    
    def _get_eventbridge_role_arn(self) -> str:
        """Get or create IAM role for EventBridge"""
        iam_client = boto3.client('iam')
        role_name = 'EventBridgeLambdaRole'
        
        try:
            response = iam_client.get_role(RoleName=role_name)
            return response['Role']['Arn']
        except iam_client.exceptions.NoSuchEntityException:
            # Create role
            assume_role_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Principal": {
                            "Service": "events.amazonaws.com"
                        },
                        "Action": "sts:AssumeRole"
                    }
                ]
            }
            
            response = iam_client.create_role(
                RoleName=role_name,
                AssumeRolePolicyDocument=json.dumps(assume_role_policy),
                Description='Role for EventBridge to invoke Lambda'
            )
            
            logger.info(f"Created IAM role: {role_name}")
            return response['Role']['Arn']
    
    def delete_rule(self, rule_name: str) -> None:
        """Delete EventBridge rule"""
        try:
            # Remove targets
            try:
                targets = self.events.list_targets_by_rule(Rule=rule_name)
                if targets['Targets']:
                    target_ids = [t['Id'] for t in targets['Targets']]
                    self.events.remove_targets(Rule=rule_name, Ids=target_ids)
            except:
                pass
            
            # Delete rule
            self.events.delete_rule(Name=rule_name, Force=True)
            logger.info(f"Deleted EventBridge rule: {rule_name}")
        
        except Exception as e:
            logger.error(f"Error deleting rule: {str(e)}")
    
    def update_schedule(
        self,
        rule_name: str,
        new_schedule: str
    ) -> None:
        """Update the schedule expression for a rule"""
        try:
            self.events.put_rule(
                Name=rule_name,
                ScheduleExpression=new_schedule,
                State='ENABLED'
            )
            logger.info(f"Updated {rule_name} schedule to: {new_schedule}")
        except Exception as e:
            logger.error(f"Error updating schedule: {str(e)}")
            raise
    
    def disable_rule(self, rule_name: str) -> None:
        """Disable EventBridge rule (pause automation)"""
        try:
            self.events.disable_rule(Name=rule_name)
            logger.info(f"Disabled EventBridge rule: {rule_name}")
        except Exception as e:
            logger.error(f"Error disabling rule: {str(e)}")
    
    def enable_rule(self, rule_name: str) -> None:
        """Enable EventBridge rule (resume automation)"""
        try:
            self.events.enable_rule(Name=rule_name)
            logger.info(f"Enabled EventBridge rule: {rule_name}")
        except Exception as e:
            logger.error(f"Error enabling rule: {str(e)}")


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    
    manager = EventBridgeManager()
    
    # Create rule
    arn = manager.create_expansion_schedule()
    print(f"Created rule with ARN: {arn}")
